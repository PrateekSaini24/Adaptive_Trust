"""
cache.py
--------
Chapter 13: "AdaptiveTrust caches both the computed risk score and the
resulting policy decision in Redis, keyed by a short time-to-live (TTL)."

This has TWO fully working backends, chosen by an environment variable —
not a stub:

  USE_REAL_REDIS=false (default)  -> in-memory dict, zero setup, used so
                                      the demo runs with no external services
  USE_REAL_REDIS=true             -> a real Redis server over redis-py

To actually use real Redis:
    pip install redis
    docker compose up redis        # or point REDIS_URL at any Redis you have
    export USE_REAL_REDIS=true
    export REDIS_URL=redis://localhost:6379
    python app.py

If USE_REAL_REDIS=true but the server can't be reached, this class raises
on the first call rather than silently pretending to work — a caching
layer that lies about whether it cached something is worse than no cache.
"""

import time
import json
import os
import threading


class Cache:
    def __init__(self, use_real_redis: bool = None, redis_url: str = None):
        self.use_real_redis = (
            use_real_redis if use_real_redis is not None
            else os.environ.get("USE_REAL_REDIS", "false").lower() == "true"
        )
        self._lock = threading.Lock()

        if self.use_real_redis:
            # --- REAL BACKEND ---
            import redis  # pip install redis
            url = redis_url or os.environ.get("REDIS_URL", "redis://localhost:6379")
            self._redis = redis.Redis.from_url(url, decode_responses=True)
            self._redis.ping()  # fail fast at startup if Redis isn't reachable
        else:
            # In-memory fallback: {key: (value, expires_at_unix_time)}
            self._store = {}

    def set(self, key: str, value, ttl_seconds: int) -> None:
        if self.use_real_redis:
            self._redis.set(key, json.dumps(value), ex=ttl_seconds)
            return
        with self._lock:
            expires_at = time.time() + ttl_seconds
            self._store[key] = (value, expires_at)

    def get(self, key: str):
        """Returns the cached value, or None if missing/expired."""
        if self.use_real_redis:
            raw = self._redis.get(key)
            return json.loads(raw) if raw else None
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            value, expires_at = entry
            if time.time() > expires_at:
                del self._store[key]  # expired -> clean it up, TTL behaving correctly
                return None
            return value

    def delete(self, key: str) -> None:
        """Chapter 13's cache-invalidation idea: clear an entry immediately
        on a known state change (e.g. a forced password reset), instead of
        waiting for the TTL to expire. Wired up in app.py's
        /demo/force-password-reset endpoint."""
        if self.use_real_redis:
            self._redis.delete(key)
            return
        with self._lock:
            self._store.pop(key, None)

    def delete_prefix(self, prefix: str) -> int:
        """Deletes every key starting with `prefix`. Used when a single
        state change (like a password reset) should invalidate several
        cached decisions for the same user at once, not just one exact
        key. Returns the number of keys removed."""
        if self.use_real_redis:
            keys = list(self._redis.scan_iter(match=f"{prefix}*"))
            if keys:
                self._redis.delete(*keys)
            return len(keys)
        with self._lock:
            matching = [k for k in self._store if k.startswith(prefix)]
            for k in matching:
                del self._store[k]
            return len(matching)

    def clear_all(self) -> None:
        """Used by the chaos-test demo endpoint (Chapter 15.3 / 20.4) to
        simulate 'the cache container just died'."""
        if self.use_real_redis:
            self._redis.flushdb()
            return
        with self._lock:
            self._store.clear()

    def size(self) -> int:
        if self.use_real_redis:
            return self._redis.dbsize()
        with self._lock:
            return len(self._store)
