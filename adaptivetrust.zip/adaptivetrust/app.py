"""
app.py
--------
The monolith core described in Chapter 5: Auth, Risk Engine, Policy Engine,
and Decision logic all live in this one Flask process because they're all
on the synchronous path a user is waiting on (Chapter 5.1).

Read this file top to bottom and you're reading Chapter 11's numbered
request flow, step by step — each step below is labeled with its chapter
step number in a comment. Every dependency (auth, cache, graph, event bus,
audit DB, policy engine) can run on either its real backend or its
in-memory fallback — see the top-of-file comment in each of those modules
for how to flip the switch.
"""

import io
import os
import csv
import time
import uuid
import copy
from flask import Flask, request, jsonify, send_from_directory, Response, send_file

from config import Config, check_secret_is_safe
from models import AccessRequest
from cache import Cache
from graph_engine import IdentityGraph
from risk_engine import RiskEngine
import policy_engine
from circuit_breaker import CircuitBreaker
from event_bus import EventBus
from explainability import explain
from metrics import Metrics
import auth
from resilience import retry, with_timeout, TimeoutError_
from session_tracker import SessionTracker
from seed_data import build_seeded_graph, USER_BASELINES as SEED_USER_BASELINES, KNOWN_VPN_IPS, KNOWN_BAD_IPS
from consumers.audit_consumer import AuditConsumer
from consumers.alert_consumer import AlertConsumer
from consumers.analytics_consumer import AnalyticsConsumer
from compliance_report import generate_compliance_pdf
from dashboard_broadcaster import DashboardBroadcaster
import geo
from soc.routes import soc_bp, init_soc


# ---------------------------------------------------------------------------
# Startup: wire up every component once, at import time.
# ---------------------------------------------------------------------------

config = Config()
check_secret_is_safe(config)  # Chapter 18: refuse to start with a placeholder secret in prod

app = Flask(__name__, static_folder=None)
app.config["SECRET_KEY"] = config.SECRET_KEY

cache = Cache()                                 # Chapter 13 (real Redis or in-memory)
graph = build_seeded_graph()                    # Chapter 7.1 (real Neo4j or in-memory)
session_tracker = SessionTracker()              # Chapter 8, Factor 7

# A deep copy, not the seed_data module's own dict: seed_data.USER_BASELINES
# is a module-level object that Python only imports ONCE per process, so
# every part of the app that did `from seed_data import USER_BASELINES`
# would otherwise share and mutate the SAME dict — including across a
# test-suite's reloads of THIS module, since seed_data itself never gets
# reloaded. Runtime identity additions/removals (see /demo/identities
# below) should be this running instance's own state, not permanently
# pollute the original seed data for every future run/test.
USER_BASELINES = copy.deepcopy(SEED_USER_BASELINES)
risk_engine = RiskEngine(graph, USER_BASELINES, session_tracker,
                          known_vpn_ips=KNOWN_VPN_IPS, known_bad_ips=KNOWN_BAD_IPS)  # Chapters 8-9

# Chapter 15.2's "use the last cached value" fallback for the graph query
# specifically — see the graph_fallback() closure in access_decide() below.
# Keyed by "user_id:device_id", holds the last (points, reason) tuple that
# a successful graph query produced for that pair.
_last_known_graph_signal = {}
event_bus = EventBus()                          # Chapter 14 (real Kafka or in-process)
metrics = Metrics()                             # Chapter 12/17/20.1

# Chapter 15: wrap the two dependencies most likely to fail — the cache and
# the graph — each in their own breaker, so one dying doesn't take the
# other down with it.
cache_breaker = CircuitBreaker("cache", config.CIRCUIT_FAILURE_THRESHOLD, config.CIRCUIT_COOLDOWN_SECONDS)
graph_breaker = CircuitBreaker("graph", config.CIRCUIT_FAILURE_THRESHOLD, config.CIRCUIT_COOLDOWN_SECONDS)

# Chapter 14's three async consumers, wired to the event bus. Each gets its
# own subscription, so each independently sees every decision event
# (real Kafka: each gets its own consumer group — see event_bus.py).
audit_consumer = AuditConsumer(db_path=os.path.join(config.DATA_DIR, "audit_log.db"))
alert_consumer = AlertConsumer()
analytics_consumer = AnalyticsConsumer()
event_bus.subscribe("decisions", audit_consumer.handle_event)
event_bus.subscribe("decisions", alert_consumer.handle_event)
event_bus.subscribe("decisions", analytics_consumer.handle_event)

# Real-time dashboard push (Chapter 28.4's pub/sub mitigation) — every
# finalized decision is broadcast to any connected browser immediately,
# instead of the dashboard having to poll for it.
broadcaster = DashboardBroadcaster(cache)
event_bus.subscribe("decisions", broadcaster.publish)

# ---------------------------------------------------------------------------
# SOC platform (a large, separate feature set — see soc/) — its own SSE
# broadcaster, its own SQLite store, wired in here.
#
# By default every data source is REAL, not simulated: init_soc() starts
# a real host/process monitor (soc/real_host_monitor.py, via psutil) and a
# real file-integrity monitor (soc/real_fim.py) watching this project's
# own source tree. The old fake event generator (soc/demo_generator.py)
# is still available but is explicitly NOT started here — it's opt-in
# only, via POST /soc/api/demo/start, for load-testing the UI with
# volume, and everything it creates is tagged detection_engine=
# "demo-generator" so it's never confused with a real finding.
# ---------------------------------------------------------------------------
soc_broadcaster = DashboardBroadcaster(cache=None)  # in-memory; separate channel from the risk-engine feed
soc_store, soc_generator = init_soc(
    config.DATA_DIR, config.SECRET_KEY, event_bus_publish=soc_broadcaster.publish,
    project_root=os.path.dirname(os.path.abspath(__file__)),
)
app.register_blueprint(soc_bp, url_prefix="/soc/api")

# Very small in-process rate limiter for the audience-submission endpoint
# (Chapter 24.1 item 8: "Scope it to the demo network and apply a basic
# rate limit so it cannot be abused in the room."). Not meant to survive
# multiple app instances — a real deployment would do this at the API
# gateway/load balancer layer instead.
_audience_submission_times = []
AUDIENCE_RATE_LIMIT_PER_MINUTE = 20


# ---------------------------------------------------------------------------
# Auth helpers (Chapter 11 Step 2 / Chapter 18)
# ---------------------------------------------------------------------------

@retry(max_attempts=2, delay_seconds=0.02)
def _cache_get_with_retry(key):
    return cache.get(key)


def _resolve_identity(body: dict):
    """
    Chapter 11, Step 2 / Chapter 18: "tokens are verified (signature and
    expiry) before any other logic runs; a request with an invalid token
    never reaches the risk engine."

    Two ways to identify the caller, checked in this order:
      1. body["token"]   -> a real JWT, verified here with auth.verify_token.
                             The user_id comes from the token's "sub" claim,
                             not from anything else the caller sent — this
                             is the real, secure path. The token's real
                             "iat" (issued-at) claim also gives us the real
                             token age for the identity-confidence factor.
      2. body["user_id"] + body["skip_auth"] == True -> an explicit,
         clearly-opt-in bypass for quick manual testing (e.g. a bare curl
         command without first minting a token). Never the default.

    Returns (user_id, token_age_minutes, error_response_or_None).
    """
    token = body.get("token")
    if token:
        try:
            payload = auth.verify_token(token, config.SECRET_KEY)
        except auth.InvalidTokenError as exc:
            return None, 0.0, (jsonify({"outcome": "DENY", "reason": str(exc)}), 401)

        real_age_minutes = max(0.0, (time.time() - payload["iat"]) / 60.0)

        # The /login "simulate" screen lets someone test what an old,
        # still-valid token looks like to the risk engine WITHOUT actually
        # waiting that long — this override only affects the simulated
        # score, it can never make an actually-expired token pass
        # verification (that already happened above).
        simulated_age = body.get("simulate_token_age_minutes")
        age_minutes = float(simulated_age) if simulated_age is not None else real_age_minutes

        return payload["sub"], age_minutes, None

    if body.get("skip_auth") is True and body.get("user_id"):
        return body["user_id"], float(body.get("simulate_token_age_minutes", 0.0)), None

    return None, 0.0, (jsonify({
        "outcome": "DENY",
        "reason": "no token provided — call POST /auth/token first, or pass "
                   "skip_auth=true for manual testing",
    }), 401)


# ---------------------------------------------------------------------------
# The core request flow (Chapter 11)
# ---------------------------------------------------------------------------

@app.route("/auth/token", methods=["POST"])
def issue_token():
    """Stands in for a real IdP login (Chapter 27.5 says AdaptiveTrust
    should sit AFTER a real SSO/IdP, not replace it) — mints a real, signed
    JWT so the rest of the demo has something genuine to verify."""
    body = request.get_json(force=True) or {}
    user_id = body.get("user_id")
    if not user_id:
        return jsonify({"error": "user_id is required"}), 400
    token = auth.issue_token(user_id, config.SECRET_KEY, expires_in_seconds=3600)
    return jsonify({"token": token, "expires_in_seconds": 3600})


@app.route("/access/decide", methods=["POST"])
def access_decide():
    request_start = time.monotonic()
    stage_timings = {}  # Chapter 20.6's "subway map" — real per-stage times

    def _mark(stage_name, stage_start):
        stage_timings[stage_name] = round((time.monotonic() - stage_start) * 1000, 3)

    body = request.get_json(force=True) or {}

    # ---- Step 1: "A request arrives at the Flask application." ------------
    step1_start = time.monotonic()
    _mark("1_request_received", step1_start)

    # ---- Step 2: "The Auth module verifies the JWT." -----------------------
    step2_start = time.monotonic()
    user_id, token_age_minutes, auth_error = _resolve_identity(body)
    _mark("2_auth", step2_start)
    if auth_error:
        return auth_error

    access_request = AccessRequest(
        user_id=user_id,
        device_id=body.get("device_id", "unknown-device"),
        location=body.get("location", "unknown"),
        resource=body.get("resource", "unspecified"),
        api_calls_last_minute=float(body.get("api_calls_last_minute", 0)),
        hour_of_day=int(body.get("hour_of_day", 12)),
        token_valid=True,  # we only got here because auth already passed
        network_ip=body.get("network_ip", "0.0.0.0"),
        mfa_verified=bool(body.get("mfa_verified", True)),
        token_age_minutes=token_age_minutes,
        device_fingerprint=body.get("device_fingerprint", ""),
        password_hash_sha1=body.get("password_hash_sha1", ""),
    )
    access_request.request_id = str(uuid.uuid4())

    # Chapter 13: check the cache first, wrapped in a circuit breaker (dead
    # cache -> compute fresh) AND a retry (one transient blip -> retry
    # once before giving up) — Chapter 15.1 and 15.2 respectively.
    # Chapter 13's cache key must cover every input the risk engine
    # actually looks at — an earlier version of this only keyed on
    # user/device/location, so changing resource, MFA status, network, or
    # hour-of-day while keeping the same device silently returned a STALE
    # cached decision instead of recomputing. Session anomaly (which reads
    # session history, not just this key) is the one factor that
    # deliberately still varies even on a cache hit — see below.
    cache_key = (
        f"decision:{access_request.user_id}:{access_request.device_id}:"
        f"{access_request.location}:{access_request.resource}:{access_request.hour_of_day}:"
        f"{round(access_request.api_calls_last_minute)}:{access_request.mfa_verified}:"
        f"{access_request.network_ip}:{round(access_request.token_age_minutes / 5) * 5}:"
        f"{access_request.device_fingerprint}:{bool(access_request.password_hash_sha1)}"
    )

    cache_stage_start = time.monotonic()
    cached_decision = cache_breaker.call(
        lambda: _cache_get_with_retry(cache_key), lambda: None
    )
    _mark("3_cache_lookup", cache_stage_start)

    if cached_decision is not None:
        metrics.record_cache_hit()
        cached_decision = dict(cached_decision)
        cached_decision["request_id"] = access_request.request_id
        cached_decision["from_cache"] = True
        cached_decision["stage_timings_ms"] = stage_timings
        total_ms = round((time.monotonic() - request_start) * 1000, 3)
        metrics.record_request(total_ms, cached_decision["outcome"])
        return jsonify(cached_decision)
    metrics.record_cache_miss()

    # ---- Step 3: "The Risk Engine computes the 8-factor score." -----------
    # Timed separately from Step 4 (the graph query below) so the Chapter
    # 20.6 "subway map" shows Risk Engine and Neo4j as the two distinct
    # stations the design doc actually names, not one merged number.
    risk_stage_start = time.monotonic()
    factors = risk_engine.score_factors_only(access_request)
    _mark("4_risk_engine", risk_stage_start)

    # ---- Step 4: "The Neo4j identity graph is queried for a relationship- -
    # based signal, which feeds into the same score."
    # Chapter 15.2: "explicit timeout... prevents any single slow call from
    # tying up resources indefinitely" AND "a documented fallback path
    # (typically: use the last cached value) ensures the system degrades
    # gracefully rather than failing outright." An earlier draft's fallback
    # just zeroed the graph signal out — that's A fallback, but not the
    # specific one the chapter names. _last_known_graph_signal below is
    # exactly that: the last successfully computed graph result for this
    # user+device pair, reused (and clearly labeled as stale) when the
    # graph is unreachable.
    graph_stage_start = time.monotonic()
    graph_cache_key = f"{access_request.user_id}:{access_request.device_id}"

    @with_timeout(config.GRAPH_QUERY_TIMEOUT_SECONDS)
    def query_graph():
        result = graph.relationship_risk_signal(access_request.user_id, access_request.device_id)
        _last_known_graph_signal[graph_cache_key] = result  # remember it for next time, on success
        return result

    def graph_fallback():
        cached = _last_known_graph_signal.get(graph_cache_key)
        if cached is not None:
            points, reason = cached
            return points, f"{reason} (stale — graph unreachable, using last known value)"
        return 0, "graph unavailable — circuit breaker open, no prior cached value to fall back to"

    graph_points, graph_reason = graph_breaker.call(query_graph, graph_fallback)
    _mark("5_neo4j_graph", graph_stage_start)

    risk_result = risk_engine.combine_with_graph(factors, graph_points, graph_reason, access_request)

    # ---- Step 5: "The Policy Engine sends the risk score... to OPA" -------
    policy_stage_start = time.monotonic()
    outcome = policy_engine.evaluate(risk_result.total_score, config)
    _mark("6_policy_engine", policy_stage_start)

    # ---- Step 6: "The Decision logic... finalizes the response." ----------
    decision_stage_start = time.monotonic()
    explanation = explain(risk_result, outcome)

    decision_payload = {
        "request_id": access_request.request_id,
        "user_id": access_request.user_id,
        "device_id": access_request.device_id,
        "location": access_request.location,
        "resource": access_request.resource,
        "risk_score": risk_result.total_score,
        "outcome": outcome,
        "explanation": explanation,
        "received_at": access_request.received_at,
        "from_cache": False,
        # Chapter 20.1: "a per-request chart breaking down the 8-factor
        # risk score" — the raw numbers the dashboard's chart is built from.
        "factors": [
            {"name": f.name, "points": f.points, "max_points": f.max_points, "reason": f.reason}
            for f in risk_result.factors
        ] + [{
            "name": "graph_relationship", "points": risk_result.graph_signal_points,
            "max_points": 10, "reason": risk_result.graph_signal_reason,
        }],
    }
    _mark("7_decision_finalized", decision_stage_start)

    # Cache the decision for next time (Chapter 13), same breaker as above.
    cache_breaker.call(lambda: cache.set(cache_key, decision_payload, config.CACHE_TTL_SECONDS),
                        lambda: None)

    # ---- Step 7: "The response is returned to the caller." ----------------
    total_ms = round((time.monotonic() - request_start) * 1000, 3)
    stage_timings["8_response_sent"] = round(total_ms - sum(stage_timings.values()), 3)
    decision_payload["stage_timings_ms"] = stage_timings
    decision_payload["total_latency_ms"] = total_ms

    metrics.record_request(total_ms, outcome)

    # ---- Step 8+9: async audit write + event publish ----------------------
    # "Asynchronously... an audit event is written... a Kafka event is
    # published, which alert, analytics, and future ML-training consumers
    # can independently subscribe to." Happens AFTER the response above is
    # already prepared — the caller never waits on this.
    nonzero_factors = [f.name for f in risk_result.factors if f.points > 0]
    event_bus.publish("decisions", {**decision_payload, "nonzero_factors": nonzero_factors})

    return jsonify(decision_payload)


@app.route("/health", methods=["GET"])
def health():
    """Chapter 22 / Appendix B: the endpoint Kubernetes' livenessProbe would
    call periodically in a real deployment."""
    return jsonify({"status": "ok"})


@app.route("/metrics", methods=["GET"])
def prometheus_metrics():
    """Chapter 12: real Prometheus text-exposition output — point a real
    Prometheus server at this (see prometheus.yml / docker-compose.yml)."""
    return Response(metrics.as_prometheus_text(), mimetype="text/plain")


# ---------------------------------------------------------------------------
# Chapter 13: explicit cache invalidation on a known state change
# ---------------------------------------------------------------------------

@app.route("/demo/force-password-reset/<user_id>", methods=["POST"])
def force_password_reset(user_id):
    """
    Chapter 13: "The mitigation is to keep the TTL short and to build
    explicit cache-invalidation logic... so that known state changes -
    such as a forced password reset - clear the relevant cache entries
    immediately rather than waiting for the TTL to expire."

    Also flags the identity in the graph (Chapter 7.1's example: "an
    account that was later flagged as compromised"), so the NEXT request
    for this user picks up the extra graph-signal risk points too.
    """
    removed = cache.delete_prefix(f"decision:{user_id}:")
    graph.flag_account_compromised(user_id)
    return jsonify({
        "user_id": user_id,
        "cache_entries_invalidated": removed,
        "graph_flagged_compromised": True,
    })


# ---------------------------------------------------------------------------
# Dashboard-support endpoints (Chapter 20)
# ---------------------------------------------------------------------------

@app.route("/")
def serve_dashboard():
    return send_from_directory("dashboard", "index.html")


@app.route("/login")
def serve_login():
    """The 'test it yourself' screen: log in as any user, then hand-tune
    location/time/device/behavior and watch the real risk engine react."""
    return send_from_directory("dashboard", "login.html")


@app.route("/soc")
def serve_soc_dashboard():
    """The full SOC platform (alerts, incidents, threat intel, endpoints,
    network monitoring, attack map, MITRE ATT&CK, etc.) — see soc/."""
    return send_from_directory("dashboard", "soc.html")


@app.route("/soc/api/stream")
def soc_stream():
    """Real-time SSE push for the SOC platform's own alert feed — a
    separate channel from the main risk-engine dashboard's /demo/stream,
    since these are two different data sets."""
    return Response(soc_broadcaster.subscribe_stream(), mimetype="text/event-stream",
                     headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.route("/demo/feed", methods=["GET"])
def demo_feed():
    """Chapter 20.1: 'a live request feed showing risk score and decision
    per request in real time.'"""
    return jsonify(audit_consumer.recent(limit=30))


@app.route("/demo/alerts", methods=["GET"])
def demo_alerts():
    """Chapter 20.5, Signature Moment D: live incident alerts."""
    return jsonify(alert_consumer.recent(limit=20))


@app.route("/demo/stats", methods=["GET"])
def demo_stats():
    """Feeds the dashboard's summary + metrics panel: totals, breaker
    states, cache size, and the real latency/hit-rate/req-per-sec numbers
    from metrics.py — Chapter 20.1's 'live system-metrics panel... driven
    by real measurements, not placeholder numbers.'"""
    return jsonify({
        "audit_summary": audit_consumer.summary_counts(),
        "analytics": analytics_consumer.snapshot(),
        "cache_size": cache.size(),
        "active_sessions": session_tracker.session_count(),
        "circuit_breakers": [cache_breaker.status(), graph_breaker.status()],
        "metrics": metrics.snapshot(),
        "backends": {
            "redis": "real" if cache.use_real_redis else "in-memory",
            "neo4j": "real" if graph.use_real_neo4j else "in-memory",
            "kafka": "real" if event_bus.use_real_kafka else "in-process",
            "postgres": "real" if audit_consumer.use_real_postgres else "sqlite",
            "opa": "real" if os.environ.get("USE_REAL_OPA", "false").lower() == "true" else "python",
        },
    })


@app.route("/demo/graph/<user_id>", methods=["GET"])
def demo_graph(user_id):
    """Chapter 20.3, Signature Moment B: the animated attack-path graph
    reveal. Returns the lateral-movement paths found for this user so the
    dashboard can draw them."""
    paths = graph.find_lateral_movement_paths(user_id, max_hops=2)
    return jsonify({"user_id": user_id, "paths": paths})


@app.route("/demo/chaos/<component>", methods=["POST"])
def demo_chaos(component):
    """Chapter 20.4, Signature Moment C: the live chaos test. Forces a
    circuit breaker open on demand so you can watch the system keep serving
    decisions (via the fallback paths above) instead of failing."""
    breaker = {"cache": cache_breaker, "graph": graph_breaker}.get(component)
    if breaker is None:
        return jsonify({"error": f"unknown component '{component}'"}), 404
    breaker.force_open()
    return jsonify(breaker.status())


@app.route("/demo/recover/<component>", methods=["POST"])
def demo_recover(component):
    """Undoes demo_chaos — closes the breaker again."""
    breaker = {"cache": cache_breaker, "graph": graph_breaker}.get(component)
    if breaker is None:
        return jsonify({"error": f"unknown component '{component}'"}), 404
    breaker.force_closed()
    return jsonify(breaker.status())


@app.route("/demo/compliance-report", methods=["GET"])
def demo_compliance_report():
    """Chapter 20.8: 'the dashboard includes a button that generates a PDF
    summary directly from the audit log.' Real PDF, built with reportlab
    from the live audit_consumer/alert_consumer data — see
    compliance_report.py."""
    output_path = os.path.join(config.DATA_DIR, "compliance_report.pdf")
    generate_compliance_pdf(audit_consumer, alert_consumer, output_path)
    return send_file(output_path, as_attachment=True, download_name="adaptivetrust_compliance_report.pdf")


@app.route("/demo/export.csv", methods=["GET"])
def demo_export_csv():
    """Plain, practical export of the audit trail — the kind of thing an
    analyst actually wants alongside the PDF summary (Chapter 20.8),
    since a PDF is for reading and a CSV is for pivoting/filtering in a
    spreadsheet or feeding into another tool."""
    rows = audit_consumer.recent(limit=5000)
    buffer = io.StringIO()
    if rows:
        writer = csv.DictWriter(buffer, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    csv_bytes = buffer.getvalue().encode("utf-8")
    return Response(
        csv_bytes, mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=adaptivetrust_audit_export.csv"},
    )


# ---------------------------------------------------------------------------
# Real-time push (Chapter 28.4's pub/sub idea, implemented for real)
# ---------------------------------------------------------------------------

@app.route("/demo/stream")
def demo_stream():
    """Server-Sent Events: the dashboard opens ONE connection here and
    gets every new decision pushed the instant it happens, instead of
    polling /demo/feed every couple of seconds. See
    dashboard_broadcaster.py for the real-Redis-pub/sub-vs-in-memory
    split."""
    return Response(broadcaster.subscribe_stream(), mimetype="text/event-stream",
                     headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ---------------------------------------------------------------------------
# Identity management (Chapter 3.3, limitation 1: "Identity Sprawl" — the
# graph makes relationships queryable; this makes them manageable, not
# just hard-coded in seed_data.py)
# ---------------------------------------------------------------------------

@app.route("/demo/cities", methods=["GET"])
def demo_cities():
    """Real coordinates from geo.py's reference table (the same data the
    Location Anomaly factor computes real distances from) — powers the
    dashboard's geo activity map so it never drifts out of sync with what
    the risk engine actually uses."""
    return jsonify({name: {"lat": lat, "lon": lon} for name, (lat, lon) in geo.CITY_COORDINATES.items()})


@app.route("/demo/identities", methods=["GET"])
def list_identities():
    """Every known identity and its baseline, plus how many devices the
    graph knows about for each — this is the 'map of how identities and
    devices relate' Chapter 3.3 says naive Zero Trust rollouts lack."""
    identities = []
    for user_id, baseline in USER_BASELINES.items():
        identities.append({
            "user_id": user_id,
            "usual_location": baseline.get("usual_location"),
            "usual_hours": list(baseline.get("usual_hours", (0, 24))),
            "usual_devices": sorted(baseline.get("usual_devices", [])),
            "avg_calls_per_minute": baseline.get("avg_calls_per_minute"),
            "leaked_credential": baseline.get("leaked_credential", False),
        })
    return jsonify(identities)


@app.route("/demo/identities", methods=["POST"])
def add_identity():
    """
    Adds a new identity's baseline AND its device relationships to the
    live graph — both structures a real onboarding workflow would touch
    (Chapter 28.6: 'Integrate device and expected-location pre-registration
    into the HR/IT onboarding workflow'). Mutates the SAME dict/graph
    objects risk_engine already holds a reference to, so it's visible on
    the very next request — no restart needed.
    """
    body = request.get_json(force=True) or {}
    user_id = body.get("user_id", "").strip()
    if not user_id:
        return jsonify({"error": "user_id is required"}), 400
    if user_id in USER_BASELINES:
        return jsonify({"error": f"identity '{user_id}' already exists"}), 409

    usual_devices = set(body.get("usual_devices", []))
    usual_hours = tuple(body.get("usual_hours", [9, 17]))

    USER_BASELINES[user_id] = {
        "usual_location": body.get("usual_location", "Unknown"),
        "usual_hours": usual_hours,
        "usual_devices": usual_devices,
        "device_fingerprints": {},
        "avg_calls_per_minute": float(body.get("avg_calls_per_minute", 2)),
        "leaked_credential": bool(body.get("leaked_credential", False)),
    }

    graph.add_node(user_id, "User")
    for device_id in usual_devices:
        graph.add_node(device_id, "Device")
        graph.add_relationship(user_id, "LOGGED_IN_FROM", device_id)

    return jsonify({"status": "created", "user_id": user_id}), 201


@app.route("/demo/identities/<user_id>", methods=["DELETE"])
def remove_identity(user_id):
    """Removes the baseline (so the identity goes back to cold-start
    treatment). Deliberately does NOT touch past audit records — Chapter
    18's append-only rule applies to history regardless of whether the
    identity itself still exists."""
    if user_id not in USER_BASELINES:
        return jsonify({"error": f"identity '{user_id}' not found"}), 404
    del USER_BASELINES[user_id]
    session_tracker.clear_session(f"{user_id}:*")  # best-effort; sessions are per-device anyway
    return jsonify({"status": "removed", "user_id": user_id})


# ---------------------------------------------------------------------------
# Chapter 20.7, Signature Moment F: QR code audience participation
# ---------------------------------------------------------------------------

@app.route("/audience")
def audience_page():
    """The page a QR code would point at. Chapter 20.7: 'a member of the
    audience... can send a request from their own phone. That request is
    then processed by the real pipeline and appears on the dashboard
    exactly like any other request.'

    This build doesn't have a QR-code image library available, so the
    dashboard displays this page's URL as large text instead of a scanned
    code — the substance of the feature (an open endpoint that feeds a
    real request into the real pipeline) is fully implemented either way.
    Generating an actual scannable image is a 3-line addition once the
    `qrcode` package is installed — see the commented example in
    dashboard/index.html.
    """
    return send_from_directory("dashboard", "audience.html")


@app.route("/audience/submit", methods=["POST"])
def audience_submit():
    """
    Open, unauthenticated-by-design endpoint (Chapter 20.7's whole point is
    that ANYONE in the room can trigger it) — but Chapter 24.1 item 8 says
    this needs a rate limit precisely because it's open. Enforced here with
    a minimal in-process limiter.
    """
    now = time.time()
    global _audience_submission_times
    _audience_submission_times = [t for t in _audience_submission_times if now - t < 60]
    if len(_audience_submission_times) >= AUDIENCE_RATE_LIMIT_PER_MINUTE:
        return jsonify({"error": "rate limit reached for this demo — try again shortly"}), 429
    _audience_submission_times.append(now)

    body = request.get_json(force=True) or {}
    # The audience member doesn't mint a real JWT — issue one server-side
    # for whatever name they typed, so their request still goes through
    # the same real Step 2 verification as every other request.
    display_name = (body.get("display_name") or "audience-guest")[:40]
    token = auth.issue_token(display_name, config.SECRET_KEY, expires_in_seconds=60)

    # Re-post into the real pipeline (not a shortcut — this hits the exact
    # same /access/decide logic, over HTTP, like any other client).
    with app.test_client() as test_client:
        response = test_client.post("/access/decide", json={
            "token": token,
            "device_id": "audience-phone",
            "location": body.get("location", "Unknown (audience device)"),
            "resource": "internal-dashboard",
            "api_calls_last_minute": 1,
            "hour_of_day": 12,
        })
        return jsonify(response.get_json()), response.status_code


if __name__ == "__main__":
    app.run(debug=True, port=5000)
