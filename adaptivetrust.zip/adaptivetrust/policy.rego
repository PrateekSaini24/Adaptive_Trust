# policy.rego
# -------------
# Chapter 10: "AdaptiveTrust uses the Open Policy Agent (OPA)... together
# with its policy language, Rego."
#
# This is the real policy — not a simulation of it. policy_engine.py
# implements the identical logic in plain Python so the demo build doesn't
# need the OPA binary installed to run, but if you DO have OPA, you can
# evaluate this file directly and get the same answer:
#
#   opa eval -i input.json -d policy.rego "data.adaptivetrust.access.decision"
#
# where input.json looks like:
#   { "risk_score": 82 }
#
# Chapter 10.2's table, encoded as rules:
#   score <  30  -> ALLOW
#   score <  60  -> VERIFY
#   score <  80  -> RESTRICT
#   score >= 80  -> DENY

package adaptivetrust.access

default decision = "ALLOW"

decision = "DENY" {
    input.risk_score >= 80
}

decision = "RESTRICT" {
    input.risk_score >= 60
    input.risk_score < 80
}

decision = "VERIFY" {
    input.risk_score >= 30
    input.risk_score < 60
}

decision = "ALLOW" {
    input.risk_score < 30
}
