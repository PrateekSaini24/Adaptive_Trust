# AdaptiveTrust — reference build (Chapters 1–20)

A runnable implementation of the AdaptiveTrust design document, Chapters
1–20. Every major feature named in those chapters is implemented — not
just the core risk engine, but the supply-chain security tooling,
Prometheus metrics, real JWT auth, a real PDF compliance report, and all
six of the Chapter 20 demo "signature moments."

**Every infrastructure dependency (Redis, Neo4j, Kafka, PostgreSQL, OPA)
has a fully-implemented REAL backend, not a stub.** By default the app
runs on in-memory fallbacks so it works with zero setup; flip one
environment variable per service to point it at the real thing. See
"Running with real infrastructure" below.

## What's implemented, by chapter

| Chapter | Feature | File |
|---|---|---|
| 7.1 | Identity graph | `graph_engine.py` (real Neo4j + Cypher, or in-memory) |
| 7.4 | Explainability | `explainability.py` |
| 7.5 | Supply chain: SBOM + image signing | `supply_chain/generate_sbom.py`, `supply_chain/sign_artifact.py` |
| 8–9 | 8-factor risk engine + worked example — real token-age/MFA (Factor 1), real device fingerprints (Factor 2), real haversine distance (Factor 3), real per-session tracking (Factor 7), real HIBP breach check (Factor 8) | `risk_engine.py`, `session_tracker.py`, `geo.py`, `credential_check.py`, `auth.py` |
| 10 | Policy engine | `policy_engine.py` (real OPA over HTTP, or Python) + `policy.rego` |
| 11 | Full request flow, step by step | `app.py` (`/access/decide`) |
| 12 | Tech stack: Docker, K8s, Prometheus | `Dockerfile`, `docker-compose.yml`, `k8s-*.yaml`, `metrics.py` |
| 13 | Caching + invalidation | `cache.py` (real Redis or in-memory), `/demo/force-password-reset` |
| 14 | Async audit/alert/analytics consumers | `event_bus.py` (real Kafka or in-process) + `consumers/` |
| 15.1 | Circuit breaker | `circuit_breaker.py` |
| 15.2 | Timeouts + retries | `resilience.py` |
| 15.3 | Chaos testing — software-simulated AND a real Docker-container-kill script | `/demo/chaos/<component>`, `chaos_test.sh` |
| 16.1–16.2 | Unit + integration tests | `tests/` |
| 16.3 | Load testing | `locustfile.py` |
| 17 | Performance targets | tracked live in `/demo/stats` → `metrics`, validated honestly by `check_performance_targets.py` |
| 18 | Real JWT auth, audit immutability | `auth.py`, `consumers/audit_consumer.py` |
| 20 | "Try it yourself" login + simulate screen | `dashboard/login.html` — log in as any identity, hand-tune location/time/device/behavior/MFA/network, see the real 8-factor breakdown with plain-language explanations |
| 20.1 | Dashboard: feed, per-request chart, metrics panel | `dashboard/index.html` |
| 20.2 | Signature Moment A: live custom input | dashboard scenario form + the login/simulate screen |
| 20.3 | Signature Moment B: animated graph reveal | dashboard SVG graph panel |
| 20.4 | Signature Moment C: live chaos test | dashboard chaos buttons + `chaos_test.sh` |
| 20.5 | Signature Moment D: live incident alert — real Slack webhook / real SMTP email, optional | `consumers/alert_consumer.py` + dashboard |
| 20.6 | Signature Moment E: request "subway map" | real per-stage timing in `app.py`, rendered in dashboard |
| 20.7 | Signature Moment F: QR audience participation | `dashboard/audience.html`, `/audience/submit` |
| 20.8 | Auto-generated compliance report | `compliance_report.py` (real PDF via reportlab) |

Chapters 21+ (ML model, PAM, data-scaling/sharding, mTLS/Istio,
multi-region) are explicitly future work in the design document itself and
are not built here, matching where the doc says the *current* build
actually is.

## The main dashboard — what's new

The SOC dashboard (`/`) now pushes updates in real time instead of
polling, and has several new panels:

- **Real-time push (SSE), not polling.** `/demo/stream` (Server-Sent
  Events) — a new decision appears the instant it happens. This is a real
  implementation of Chapter 28.4's own proposed fix ("use the existing
  Redis layer as a pub/sub channel... every dashboard-serving pod
  subscribes and forwards to its connected clients") — see
  `dashboard_broadcaster.py`, which uses real Redis pub/sub when
  `USE_REAL_REDIS=true`, and an honest in-memory fallback (correct for one
  process, and by design NOT correct across multiple replicas, exactly as
  Chapter 28.4 describes) otherwise.
- **Geo activity map.** A real equirectangular scatter plot (not a
  fabricated world outline — no coastline data was available offline, so
  this stays honest about being a grid + labeled city markers) built from
  `geo.py`'s actual coordinate table. Every new request pulses at its real
  location, colored by outcome.
- **Risk score trend chart.** A live line chart of the last 30 scores,
  with the ALLOW/VERIFY/RESTRICT/DENY threshold bands from `config.py`
  drawn in as background bands.
- **"Replay Chapter 4's story."** A guided walkthrough that narrates and
  then actually runs Alice's two logins from Chapter 4 — the exact same
  `/access/decide` calls as everything else, not a scripted fake.
- **DENY alert flash + sound.** A brief screen flash and a synthesized
  beep (Web Audio API — no audio file needed) on every DENY, toggleable
  (off by default so repeated testing doesn't get grating).
- **Identity management.** Chapter 3.3, limitation 1 ("Identity Sprawl")
  is solved in the design doc by making the graph queryable — this makes
  it *manageable*: add or remove an identity live, and the running risk
  engine picks it up on the very next request, no restart.
- **CSV export** alongside the existing PDF compliance report.
- **Side-by-side comparison.** Select any two rows in the live feed to
  see a factor-by-factor diff — useful for exactly the ambiguity Chapter
  26.2 describes (two requests that look similar in context, different
  outcomes).

## The full SOC platform (`/soc`)

A large second application alongside AdaptiveTrust itself: a full SOC
analyst dashboard — alert triage, incident management, threat intel, IP
investigation, network monitoring, a live Leaflet/OpenStreetMap attack
map, authentication-anomaly heuristics, endpoint/process/file-integrity
monitoring, malware and vulnerability tracking, a real MITRE ATT&CK
browser, notifications, and a full analyst audit log — all driven by a
continuous demo-event generator so it's fully usable with zero real
security infrastructure connected.

**Log in at `/soc`** (a separate login from AdaptiveTrust's own — this
one authenticates *you as an analyst*, not an end user being risk-scored)
and pick a role:
- **viewer** — read-only access to every page
- **analyst** — viewer + can assign/resolve/escalate alerts, manage
  incidents, add threat-intel IOCs
- **admin** — analyst + audit log access + demo-generator control

Roles are enforced server-side via a real signed JWT (`soc/auth.py`) —
picking "admin" at login doesn't let you do admin things if the token's
role claim says otherwise; every write endpoint checks the verified
token, never a client-supplied role.

**What's real vs. simulated, explicitly:**
- The demo generator (`soc/demo_generator.py`) invents alerts, auth
  events, processes, connections, etc. — clearly, since that's what "Demo
  Mode" was asked for. Every alert it creates is tagged
  `detection_engine="demo-generator"` so it's always distinguishable from
  a real detection source.
- **MITRE ATT&CK data is real** — actual tactic/technique IDs from the
  public matrix (`soc/mitre_data.py`), not invented ones.
- **IP investigation is a real lookup** (ipapi.co, free, no key) with an
  honest `"External reputation data unavailable."` fallback — no
  paid API, and no fabricated reputation score, ever.
- **CVE data is real** — a small set of actual, publicly disclosed CVEs
  with correct CVSS scores, cached locally (`soc/nvd_lookup.py`) so the
  Vulnerability Dashboard works offline; a live NVD lookup is attempted
  on a cache miss when network access is available.
- **Brute force / password spray / impossible travel are real
  heuristics** (`soc/detectors.py`) run against whatever's actually in
  the auth_events table — labeled "heuristic, not a confirmed detection"
  everywhere they appear, per the brief's own requirement.
- The attack map explicitly says its locations are city-level reference
  coordinates, not pinpoint geography — it never claims more precision
  than the underlying data has.

Nothing here needed API keys or WebSockets: the IP/CVE lookups use free,
keyless REST APIs, and the live feed reuses the same Server-Sent-Events
broadcaster pattern as the main dashboard (one-directional server→client
push is all this needs — a WebSocket's extra bidirectional complexity
wouldn't buy anything here).

One dependency that DOES need internet: the Attack Map loads Leaflet's
JS/CSS and OpenStreetMap tiles from public CDNs
(unpkg.com, tile.openstreetmap.org) — this wasn't reachable in the
offline sandbox this was built in either, so the map's structural code
was verified (it correctly builds and renders the polylines/markers from
real `/soc/api/attack-map` data) but the tile imagery itself needs your
own internet connection to actually paint.

## Two more real bugs found and fixed while building this

1. **Network Reputation was dead code.** `score_network_reputation()` was
   written to accept `known_vpn_ips`/`known_bad_ips` as optional
   arguments, but no call site ever actually passed them — every request,
   regardless of network, fell into the generic "unfamiliar" bucket. The
   Corporate-VPN and Known-bad-network options on the `/login` screen were
   cosmetically present but functionally inert. Fixed by giving
   `RiskEngine` these sets at construction time instead of expecting them
   per-call.
2. **`USER_BASELINES` leaked across test runs.** Adding an identity
   through `/demo/identities` mutated the SAME dict object every reload of
   `app.py` shared (Python only imports a module once per process, so
   `seed_data.USER_BASELINES` was never actually fresh). Fixed with a deep
   copy at startup, so runtime identity changes are this instance's own
   state and don't bleed into other test runs or pollute the original seed
   data.

## The "try it yourself" screen

Open `http://localhost:5000/login`. This is the answer to "how do I test
this myself without curl": log in as any name (this box doesn't really
check the password — a real deployment sits behind a real IdP per Chapter
27.5, this is just for picking who you are in the simulation), then a
control panel lets you hand-tune:

- **Location** — compared against that identity's usual city
- **Device** — your usual device vs. an unrecognized one vs. one that
  *claims* to be your device but presents the wrong fingerprint (a real
  spoofing-style check, not just an ID lookup)
- **Hour of day** and **API calls/minute** — sliders, with quick presets
- **Resource** you're accessing — feeds the session-anomaly factor
- **Network** — corporate VPN / unfamiliar / known-bad
- **MFA confirmed** — toggle it off and watch identity-confidence react
- **Simulated token age** — see what an old-but-still-valid token looks
  like to the risk engine, without waiting that long for real
- **Real breach check (optional)** — your Step-1 password is hashed
  *in your browser* (Web Crypto, never sent as plaintext) and checked
  against the real Have I Been Pwned database

Hit "Check access" and you get the real outcome (ALLOW/VERIFY/RESTRICT/
DENY), the real score, and — for every one of the 9 factors — both a
plain-English description of *what that factor measures* and the actual
computed reason for *this specific request*. It's meant to double as a
walkthrough of Chapter 8, not just a form. Every request you send here also
shows up on the main dashboard's live feed in real time, since it goes
through the exact same `/access/decide` endpoint as everything else.

## Two real bugs found and fixed on the last pass

Worth naming, since they're the kind of thing that only shows up under
real conditions:

1. **Cache key was incomplete.** The Chapter 13 cache key only covered
   user/device/location — changing MFA status, network, resource, or
   token age while keeping the same device silently returned a STALE
   cached decision instead of recomputing. Fixed by including every field
   the risk engine actually reads in the key.
2. **Compliance-report path mismatch.** `compliance_report.pdf` was
   written relative to the process's current working directory, but
   Flask's `send_file()` resolves relative paths against the *app's own
   root directory* instead — two different things that only diverge when
   the app isn't started from its own folder (which is normal for
   systemd, Docker, supervisor, etc.). Reproduced it by running the app
   from an unrelated directory — `/demo/compliance-report` returned a 404
   even though the PDF was correctly generated at a different path. Fixed
   with a `Config.DATA_DIR` anchored to `os.path.abspath(__file__)`,
   used consistently for both the SQLite audit log and the generated PDF.

## Docker: what's actually a real image vs. what to double-check

Every service in `docker-compose.yml` uses a real, standard published
image — `redis:7-alpine`, `postgres:16-alpine`, `neo4j:5-community`,
`confluentinc/cp-kafka` + `cp-zookeeper`, `openpolicyagent/opa`,
`prom/prometheus`, `grafana/grafana`. Two things worth knowing before you
run it:

- **Grafana comes pre-wired, not blank.** `grafana/provisioning/` auto-configures
  Prometheus as a data source and loads a starter dashboard
  (requests/sec, cache hit rate, outcome breakdown, p50/p99 latency) on
  first boot — open `http://localhost:3000` (admin/admin) and it's
  already there, no manual data-source setup required.
- **Real healthchecks, not just `depends_on`.** Every dependency has an
  actual readiness check (`pg_isready`, `redis-cli ping`, a real Cypher
  query for Neo4j, `kafka-broker-api-versions` for Kafka), and `app`
  waits on `service_healthy` for all of them. Without this, `app` can
  start before Postgres/Neo4j/Kafka are actually ready to accept
  connections — a very common Compose race condition that looks like a
  flaky app when it's really just a timing issue.
- **Kafka has two listeners on purpose.** If you run the app inside
  Compose, it reaches Kafka at `kafka:9092`. If you run `python app.py`
  directly on your host (with only the dependencies in Docker), point
  `KAFKA_BOOTSTRAP_SERVERS` at `localhost:29092` instead, not `9092` —
  Kafka's own broker protocol tells clients "the real address is
  kafka:9092" on the first connection, which only resolves inside the
  Compose network. The `29092` listener is specifically for host-side
  clients. This is one of the most common real-world Kafka-in-Docker
  mistakes, so it's fixed here rather than left as a surprise.

## The one honest limitation

**The environment this was built in has no network access**, so the real
Redis/Neo4j/Kafka/PostgreSQL/OPA client libraries and Docker images could
not be installed or pulled to test against here. What that means
concretely:

- Every real-backend code path (`cache.py`'s Redis branch, `graph_engine.py`'s
  Neo4j branch, `event_bus.py`'s Kafka branch, `audit_consumer.py`'s
  Postgres branch, `policy_engine.py`'s OPA branch) is **fully written,
  using the real client libraries' real APIs** — not placeholders — but
  was not run end-to-end against live servers in this sandbox.
- The in-memory fallback for every one of those was tested end-to-end (see
  "What was actually verified" below) and is what the demo runs on by
  default.
- `docker-compose.yml` and `k8s-*.yaml` use real, standard images
  (`redis:7-alpine`, `neo4j:5-community`, `confluentinc/cp-kafka`,
  `postgres:16-alpine`, `openpolicyagent/opa`) — pulling and running them
  requires Docker + internet access on your machine, which this sandbox
  doesn't have.

This is exactly the situation Chapter 27.4 describes as a real constraint
for a small team: bring in the full infrastructure incrementally, on real
hardware, once you can actually test against it — not before.

## Running with real infrastructure

**The one-command way:**
```bash
chmod +x go_real.sh
./go_real.sh
```
This starts every real backend via Docker, waits for each to actually
pass its healthcheck, installs the real client libraries, and launches
the app with every `USE_REAL_*` flag on. Needs Docker + internet on
*your* machine — see "The one honest limitation" above for why this
couldn't be run or verified inside the sandbox this project was built in.

**The manual, step-by-step way** (same result, more control):
```bash
cp .env.example .env
# uncomment redis / neo4j / kafka-python / psycopg2-binary in requirements.txt
pip install -r requirements.txt

docker compose up -d redis neo4j kafka zookeeper postgres opa prometheus grafana

export $(cat .env | xargs)
# then flip whichever USE_REAL_* flags you want to true, e.g.:
export USE_REAL_REDIS=true
export USE_REAL_NEO4J=true
export USE_REAL_KAFKA=true
export USE_REAL_POSTGRES=true
export USE_REAL_OPA=true

python app.py
```

Each `USE_REAL_*` flag is independent — turn on just Redis and leave the
rest in-memory if that's all you want to test.

**Kubernetes** (Appendix B): `k8s-deployment.yaml` + `k8s-service.yaml`
give you the full stack in-cluster:
```bash
minikube start
eval $(minikube docker-env)
docker build -t adaptivetrust:local .
kubectl apply -f k8s-service.yaml
kubectl apply -f k8s-deployment.yaml
```

## Running the zero-setup demo (no external services)

```bash
pip install -r requirements.txt     # Flask, PyJWT, reportlab, cryptography, pytest
python app.py
```

Open `http://localhost:5000/` for the dashboard. On another device on the
same network, open `http://<your-ip>:5000/audience` to try Signature
Moment F.

Try it by hand:
```bash
# Chapter 18: get a real, signed JWT first
TOKEN=$(curl -s -X POST http://localhost:5000/auth/token -H "Content-Type: application/json" \
  -d '{"user_id": "alice"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['token'])")

curl -X POST http://localhost:5000/access/decide -H "Content-Type: application/json" -d "{
  \"token\": \"$TOKEN\",
  \"device_id\": \"alice-laptop\", \"location\": \"Bangalore\", \"resource\": \"internal-dashboard\",
  \"api_calls_last_minute\": 2, \"hour_of_day\": 10
}"
```
Then try the same with `"device_id": "unknown-device", "location": "Tokyo",
"api_calls_last_minute": 500, "hour_of_day": 3` and watch the score/decision
flip — this reproduces Alice's two logins from Chapter 4.

(There's also a `skip_auth: true` + `user_id` shortcut in the request body
for quick manual testing without minting a token first — see the comment
in `app.py`'s `_resolve_identity`.)

## Running the tests

```bash
pytest tests/ -v
```
(pytest wasn't installable in the sandbox this was built in — every test
was instead run manually via Flask's test client, matching pytest's own
logic line for line; see the inline comments in `tests/`.)

## Load testing (Chapter 16.3)

```bash
pip install locust
python app.py                                            # terminal 1
locust -f locustfile.py --host http://localhost:5000      # terminal 2
```
Open `http://localhost:8089` to set concurrent users and watch real
throughput/P99 latency — this is what would actually validate (or
invalidate) Chapter 17's targets.

## Supply chain security (Chapter 7.5)

```bash
python supply_chain/generate_sbom.py          # writes sbom.json
python supply_chain/sign_artifact.py generate-keys
python supply_chain/sign_artifact.py sign app.py
python supply_chain/sign_artifact.py verify app.py app.py.sig
```
Tamper with `app.py` after signing and re-run `verify` — it correctly
reports the mismatch. (Real cosign signs a container image digest instead
of a file; the cryptographic property demonstrated is identical.)

## Project layout

```
adaptivetrust/
  config.py                settings + secret-key safety check (Ch 18) + DATA_DIR
  data/                     generated at runtime: SQLite audit log, compliance PDFs (not in the zip)
  models.py                  AccessRequest, RiskResult, Decision
  auth.py                      real JWT issue/verify (Ch 18)
  cache.py                      real Redis or in-memory (Ch 13)
  graph_engine.py                real Neo4j (Cypher) or in-memory (Ch 7.1)
  event_bus.py                    real Kafka or in-process (Ch 14)
  risk_engine.py                   8-factor scorer (Ch 8-9)
  session_tracker.py                real per-session behavior for Factor 7 (Ch 8)
  dashboard_broadcaster.py           real-time SSE push (Ch 28.4 pattern, implemented early)
  geo.py                             real haversine distance for Factor 3 (Ch 8)
  credential_check.py                 real Have I Been Pwned check for Factor 8 (Ch 8)
  policy_engine.py                   real OPA (HTTP) or Python (Ch 10)
  policy.rego                         the real Rego policy
  circuit_breaker.py                   Closed/Open/Half-Open (Ch 15.1)
  resilience.py                         timeouts + retries (Ch 15.2)
  metrics.py                             Prometheus text format (Ch 12/17/20.1)
  explainability.py                       plain-English reasoning (Ch 7.4)
  compliance_report.py                     real PDF via reportlab (Ch 20.8)
  check_performance_targets.py              validates live metrics vs Ch 17 targets
  seed_data.py                               demo users/devices/graph seed
  supply_chain/
    generate_sbom.py                          SBOM (Ch 7.5)
    sign_artifact.py                           image-signing stand-in (Ch 7.5)
  consumers/
    audit_consumer.py                           real Postgres or SQLite, append-only (Ch 14/18)
    alert_consumer.py                            real Slack/email or console (Ch 14/20.5)
    analytics_consumer.py                         future-ML data collection (Ch 14)
  app.py                                          the Flask monolith
  soc/                                              the full SOC analyst platform
    store.py                                          SQLite data layer (alerts/incidents/hosts/etc)
    auth.py                                            SOC RBAC (viewer/analyst/admin, real JWT)
    mitre_data.py                                       real MITRE ATT&CK reference data
    ip_lookup.py                                         real free IP geolocation, honest fallback
    nvd_lookup.py                                         real NVD CVE lookup + local cache
    detectors.py                                           brute force / spray / impossible travel
    demo_generator.py                                       continuous simulated event generator
    routes.py                                                every /soc/api/* endpoint
  dashboard/
    index.html                                    the Ch 20 SOC dashboard
    login.html                                     "try it yourself" login + simulate screen
    audience.html                                   the Ch 20.7 audience page
    soc.html                                         the full SOC analyst platform UI
  tests/                                            pytest suite (Ch 16), including tests/test_soc.py
  Dockerfile, docker-compose.yml, prometheus.yml     (Ch 12)
  k8s-deployment.yaml, k8s-service.yaml               (Appendix B)
  locustfile.py, chaos_test.sh                         (Ch 16.3, Ch 15.3)
  .env.example                                          every real-backend toggle
```
