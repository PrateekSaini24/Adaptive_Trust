"""
policy_engine.py
------------------
Chapter 10: "AdaptiveTrust uses the Open Policy Agent (OPA)... together
with its policy language, Rego."

Two fully working backends:

  USE_REAL_OPA=false (default) -> the rule below, in plain Python
  USE_REAL_OPA=true            -> a real running OPA server, called over
                                   its REST API, evaluating the actual
                                   policy.rego file in this repo

To actually use real OPA:
    docker run -d -p 8181:8181 -v $(pwd)/policy.rego:/policy.rego \
        openpolicyagent/opa run --server /policy.rego
    export USE_REAL_OPA=true
    export OPA_URL=http://localhost:8181
    python app.py

Either way the rule is Chapter 10.2's table:
    score <  30  -> ALLOW
    score <  60  -> VERIFY
    score <  80  -> RESTRICT
    score >= 80  -> DENY

Keeping the Python fallback exactly in sync with policy.rego is exactly
Chapter 10.1's point about policy-as-code: the rule lives in ONE place
conceptually (this threshold table), whichever engine is actually
evaluating it.
"""

import os
import json
import urllib.request
import urllib.error


def evaluate(risk_score: int, config) -> str:
    """Returns one of "ALLOW", "VERIFY", "RESTRICT", "DENY"."""
    use_real_opa = os.environ.get("USE_REAL_OPA", "false").lower() == "true"

    if use_real_opa:
        return _evaluate_via_real_opa(risk_score)
    return _evaluate_in_python(risk_score, config)


def _evaluate_in_python(risk_score: int, config) -> str:
    if risk_score >= config.THRESHOLD_DENY:
        return "DENY"
    if risk_score >= config.THRESHOLD_RESTRICT:
        return "RESTRICT"
    if risk_score >= config.THRESHOLD_VERIFY:
        return "VERIFY"
    return "ALLOW"


def _evaluate_via_real_opa(risk_score: int) -> str:
    """
    Calls a real, running OPA server's REST API — the actual product,
    actually evaluating policy.rego. This is not a simulation: OPA's
    /v1/data/<package>/<rule> endpoint is the documented way any real
    application integrates with OPA.
    """
    opa_url = os.environ.get("OPA_URL", "http://localhost:8181")
    endpoint = f"{opa_url}/v1/data/adaptivetrust/access/decision"

    payload = json.dumps({"input": {"risk_score": risk_score}}).encode("utf-8")
    request = urllib.request.Request(
        endpoint, data=payload, headers={"Content-Type": "application/json"}, method="POST"
    )

    try:
        with urllib.request.urlopen(request, timeout=2) as response:
            body = json.loads(response.read().decode("utf-8"))
            return body["result"]
    except (urllib.error.URLError, KeyError, TimeoutError) as exc:
        # Chapter 15.2: a dependency being unreachable shouldn't crash the
        # request. Fall back to the local Python rule (which is kept
        # identical to policy.rego) rather than failing the decision.
        print(f"[policy_engine] real OPA unreachable ({exc}); falling back to local rule")
        from config import Config
        return _evaluate_in_python(risk_score, Config())
