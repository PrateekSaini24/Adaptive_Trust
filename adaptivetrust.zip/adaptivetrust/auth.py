"""
auth.py
---------
Chapter 18: "JWT handling: tokens are verified (signature and expiry)
before any other logic runs; a request with an invalid token never
reaches the risk engine."

Earlier drafts of this build just trusted a `token_valid: true/false` flag
from the caller, which isn't real verification. This module does the real
thing using PyJWT: issue signed tokens, and verify a token's signature and
expiry before the request is allowed anywhere near the risk engine.

This is still "Auth", not "Identity Provider" — Chapter 27.5's mitigation
says AdaptiveTrust should sit *after* an existing SSO/IdP and consume its
authentication result, not replace it. In a real deployment, `issue_token`
below would be Okta/Azure AD/etc, not this file. It's included here only so
the demo can generate a valid signed token to test against without needing
a real IdP.
"""

import jwt
import time


class InvalidTokenError(Exception):
    """Raised when a token fails signature or expiry verification."""
    pass


def issue_token(user_id: str, secret_key: str, expires_in_seconds: int = 3600) -> str:
    """Issues a signed JWT for `user_id`. Stands in for 'log in through the
    real IdP' in this demo build."""
    now = int(time.time())
    payload = {
        "sub": user_id,
        "iat": now,
        "exp": now + expires_in_seconds,
    }
    return jwt.encode(payload, secret_key, algorithm="HS256")


def verify_token(token: str, secret_key: str) -> dict:
    """
    Chapter 11, Step 2: "The Auth module verifies the JWT attached to the
    request." Checks the signature (was this issued by us, unmodified?)
    and the expiry (is it still valid?) — exactly the two checks Chapter 18
    names. Raises InvalidTokenError on any failure; callers must not
    proceed to risk scoring if this raises.
    """
    try:
        payload = jwt.decode(token, secret_key, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        raise InvalidTokenError("token has expired")
    except jwt.InvalidSignatureError:
        raise InvalidTokenError("token signature does not match — possibly tampered")
    except jwt.InvalidTokenError as exc:
        raise InvalidTokenError(f"token is malformed: {exc}")
    return payload
