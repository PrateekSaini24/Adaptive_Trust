"""
check_performance_targets.py
-------------------------------
Chapter 17: "The following numbers are stated as targets to be validated,
not results already achieved... Honest note: Precision/false-positive
numbers in particular require a labeled dataset of confirmed-good and
confirmed-bad requests to measure meaningfully."

This script is the validation step Chapter 17 describes — it reads the
app's real, live metrics (from metrics.py, via /demo/stats) and reports
target vs. actual, honestly, including saying "not enough data yet" rather
than a false pass/fail when that's the truth.

Run this AFTER generating some load (e.g. locustfile.py), not on a
freshly-started, empty app — an idle app will correctly report "no data".

Usage:
    python app.py                                  # terminal 1
    locust -f locustfile.py --host http://localhost:5000 --headless \\
        -u 50 -r 10 -t 30s                         # terminal 2: generate load
    python check_performance_targets.py            # terminal 3
"""

import sys
import urllib.request
import json


TARGETS = {
    "Throughput": {"target": "10,000+ requests/second", "metric": "requests_per_second",
                   "check": lambda v: v >= 10000},
    "Latency P99": {"target": "< 200ms", "metric": "latency_ms_p99",
                    "check": lambda v: v < 200},
}


def fetch_stats(app_url: str) -> dict:
    with urllib.request.urlopen(f"{app_url}/demo/stats", timeout=5) as response:
        return json.loads(response.read().decode("utf-8"))


def main():
    app_url = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:5000"

    try:
        stats = fetch_stats(app_url)
    except Exception as exc:
        print(f"Could not reach {app_url} ({exc}). Is the app running?")
        sys.exit(1)

    metrics = stats["metrics"]
    total_requests = metrics["requests_total"]

    print("AdaptiveTrust — Chapter 17 performance target validation")
    print("=" * 60)

    if total_requests < 20:
        print(f"Only {total_requests} requests recorded so far — not enough")
        print("data to validate anything meaningfully. Generate real load first:")
        print("  locust -f locustfile.py --host " + app_url +
              " --headless -u 50 -r 10 -t 30s")
        print()
        print("This message itself is the honest answer Chapter 17 asks for:")
        print('"no load testing has been performed yet" should not be hidden')
        print("behind a fake PASS.")
        return

    print(f"(based on {total_requests} requests recorded)\n")
    for name, spec in TARGETS.items():
        actual = metrics[spec["metric"]]
        passed = spec["check"](actual)
        status = "PASS" if passed else "NOT MET"
        print(f"{name:<15} target: {spec['target']:<22} actual: {actual:<10} [{status}]")

    print()
    print("Detection precision / false-positive rate: cannot be validated by")
    print("this script — Chapter 17 is explicit that this needs a labeled")
    print("dataset of confirmed-good and confirmed-bad requests, which this")
    print("demo build does not have (no real incident history exists yet).")


if __name__ == "__main__":
    main()
