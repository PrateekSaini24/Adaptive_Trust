#!/usr/bin/env bash
# chaos_test.sh
# ---------------
# Chapter 15.3: "deliberately killing a dependency (for example, stopping
# the Redis container) while the system is running, and confirming that it
# degrades as designed instead of crashing outright."
#
# The dashboard's "Kill cache" / "Kill graph" buttons (via /demo/chaos/...)
# simulate this instantly for the zero-setup, no-Docker demo. THIS script
# does the literal thing the chapter describes — actually stopping a real
# container — for when you're running the app against docker-compose.yml's
# real backends (see .env.example / README "Running with real
# infrastructure").
#
# Usage:
#   ./chaos_test.sh redis      # or: neo4j, kafka, postgres, opa
#
# Requires: docker compose already running (`docker compose up -d`), and
# the app running with the matching USE_REAL_* flag turned on so there's
# actually a real dependency for this to kill.

set -euo pipefail

COMPONENT="${1:-}"
APP_URL="${APP_URL:-http://localhost:5000}"

if [[ -z "$COMPONENT" ]]; then
  echo "Usage: $0 <redis|neo4j|kafka|postgres|opa>"
  exit 1
fi

echo "== Before: confirming the app answers normally =="
curl -s "$APP_URL/health" | python3 -m json.tool

echo
echo "== Stopping the real '$COMPONENT' container =="
docker compose stop "$COMPONENT"

echo
echo "== While it's down: the app should still answer (fallback path) =="
sleep 1
TOKEN=$(curl -s -X POST "$APP_URL/auth/token" -H "Content-Type: application/json" \
  -d '{"user_id": "alice"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['token'])")

curl -s -X POST "$APP_URL/access/decide" -H "Content-Type: application/json" -d "{
  \"token\": \"$TOKEN\", \"device_id\": \"alice-laptop\", \"location\": \"Bangalore\",
  \"resource\": \"internal-dashboard\", \"api_calls_last_minute\": 2, \"hour_of_day\": 10
}" | python3 -m json.tool

echo
echo "== Restoring '$COMPONENT' =="
docker compose start "$COMPONENT"
sleep 2

echo
echo "== After: confirming normal operation resumed =="
curl -s "$APP_URL/health" | python3 -m json.tool

echo
echo "Chaos test complete. Check /demo/stats on the dashboard to see the"
echo "circuit breaker's state transition through this whole sequence."
