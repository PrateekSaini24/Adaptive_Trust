"""
event_bus.py
--------------
Chapter 14: "After a decision is made and returned to the caller,
AdaptiveTrust publishes an event... consumed independently by three
background services" (audit, alert/response, analytics).

Two fully working backends, chosen by an environment variable:

  USE_REAL_KAFKA=false (default) -> in-process queue + threads, zero setup
  USE_REAL_KAFKA=true            -> a real Kafka broker over kafka-python

To actually use real Kafka:
    pip install kafka-python
    docker compose up kafka zookeeper
    export USE_REAL_KAFKA=true
    export KAFKA_BOOTSTRAP_SERVERS=localhost:9092
    python app.py

Each subscriber gets its OWN Kafka consumer group, so every handler sees
every event independently — this is exactly Chapter 14's "audit, alert,
analytics... independently subscribe" behavior. If they all shared one
group, Kafka would load-balance messages *between* them instead (each
message going to only one), which is not what the design doc describes.
"""

import os
import json
import queue
import threading


class EventBus:
    def __init__(self, use_real_kafka: bool = None, bootstrap_servers: str = None):
        self.use_real_kafka = (
            use_real_kafka if use_real_kafka is not None
            else os.environ.get("USE_REAL_KAFKA", "false").lower() == "true"
        )

        if self.use_real_kafka:
            # --- REAL BACKEND ---
            from kafka import KafkaProducer  # pip install kafka-python
            self._KafkaConsumer = __import__("kafka", fromlist=["KafkaConsumer"]).KafkaConsumer
            self.bootstrap_servers = (
                bootstrap_servers or os.environ.get("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
            )
            self._producer = KafkaProducer(
                bootstrap_servers=self.bootstrap_servers,
                value_serializer=lambda v: json.dumps(v).encode("utf-8"),
            )
            self._consumer_threads = []
        else:
            # One queue per topic, one worker thread per topic that hands
            # events to every subscribed handler in order.
            self._queues = {}
            self._handlers = {}
            self._workers_started = set()

    def subscribe(self, topic: str, handler_fn) -> None:
        if self.use_real_kafka:
            # Give this handler its own consumer group so it independently
            # sees every message on the topic (Chapter 14's requirement).
            group_id = f"adaptivetrust-{topic}-{handler_fn.__qualname__}"
            t = threading.Thread(
                target=self._real_consumer_loop,
                args=(topic, group_id, handler_fn),
                daemon=True,
            )
            t.start()
            self._consumer_threads.append(t)
            return

        self._handlers.setdefault(topic, []).append(handler_fn)
        self._ensure_worker(topic)

    def _real_consumer_loop(self, topic, group_id, handler_fn):
        consumer = self._KafkaConsumer(
            topic,
            bootstrap_servers=self.bootstrap_servers,
            group_id=group_id,
            value_deserializer=lambda v: json.loads(v.decode("utf-8")),
            auto_offset_reset="latest",
        )
        for message in consumer:
            try:
                handler_fn(message.value)
            except Exception as exc:
                print(f"[event_bus/kafka] handler for topic '{topic}' failed: {exc}")

    def publish(self, topic: str, event: dict) -> None:
        if self.use_real_kafka:
            self._producer.send(topic, event)
            self._producer.flush()
            return
        self._ensure_worker(topic)
        self._queues[topic].put(event)

    def _ensure_worker(self, topic: str) -> None:
        if topic not in self._queues:
            self._queues[topic] = queue.Queue()
        if topic not in self._workers_started:
            t = threading.Thread(target=self._worker_loop, args=(topic,), daemon=True)
            t.start()
            self._workers_started.add(topic)

    def _worker_loop(self, topic: str) -> None:
        q = self._queues[topic]
        while True:
            event = q.get()
            for handler_fn in self._handlers.get(topic, []):
                try:
                    handler_fn(event)
                except Exception as exc:
                    # A consumer failing should never crash the bus or the
                    # request path — this mirrors Chapter 14's point that a
                    # slow/broken consumer can't affect the user-facing
                    # response, since the response was already sent.
                    print(f"[event_bus] handler for topic '{topic}' failed: {exc}")
            q.task_done()
