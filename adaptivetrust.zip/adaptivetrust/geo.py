"""
geo.py
--------
Chapter 8, Factor 3: "How FAR the request's apparent location is from the
identity's typical locations." An earlier draft of this only checked
whether the city name matched exactly — that answers "same or different,"
not "how far," which is what the chapter actually asks for.

This does the real calculation: known cities get real coordinates, and the
distance between two points on Earth is computed with the haversine
formula (the standard formula for great-circle distance between two
lat/lon points) — not a placeholder.
"""

import math


# A small reference table of city -> (latitude, longitude). Real production
# systems use a proper geo-IP service (MaxMind, IPinfo, etc.) to resolve an
# IP to coordinates; this demo resolves by city NAME since that's what the
# risk engine's inputs use, but the distance math below is the real thing.
CITY_COORDINATES = {
    "bangalore": (12.9716, 77.5946),
    "london": (51.5072, -0.1276),
    "new york": (40.7128, -74.0060),
    "tokyo": (35.6762, 139.6503),
    "lagos": (6.5244, 3.3792),
    "moscow": (55.7558, 37.6173),
    "paris": (48.8566, 2.3522),
    "seattle": (47.6062, -122.3321),
    "singapore": (1.3521, 103.8198),
    "sydney": (-33.8688, 151.2093),
    "sao paulo": (-23.5558, -46.6396),
    "dubai": (25.2048, 55.2708),
}


def haversine_km(lat1, lon1, lat2, lon2) -> float:
    """Great-circle distance between two points on Earth, in kilometers.
    This is the standard formula — not an approximation invented for this
    project."""
    R = 6371.0  # Earth's mean radius in km
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    d_phi = math.radians(lat2 - lat1)
    d_lambda = math.radians(lon2 - lon1)

    a = (math.sin(d_phi / 2) ** 2
         + math.cos(phi1) * math.cos(phi2) * math.sin(d_lambda / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def distance_between_cities_km(city_a: str, city_b: str):
    """Returns the real distance in km, or None if either city isn't in
    our reference table (caller should fall back to a same/different
    comparison in that case, which is still more useful than crashing)."""
    a = CITY_COORDINATES.get(city_a.strip().lower())
    b = CITY_COORDINATES.get(city_b.strip().lower())
    if a is None or b is None:
        return None
    return haversine_km(a[0], a[1], b[0], b[1])
