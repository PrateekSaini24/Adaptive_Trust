#!/usr/bin/env bash
# go_real.sh
# ------------
# ONE command to flip every USE_REAL_* switch on: real Redis, real Neo4j,
# real Kafka, real PostgreSQL, real OPA, real Prometheus + Grafana.
#
# This MUST be run on YOUR OWN machine, not inside the sandbox this
# project was built in — that sandbox has no internet access and no
# Docker installed, so none of this can run there. On your machine (with
# Docker + internet), this is genuinely one command:
#
#   chmod +x go_real.sh
#   ./go_real.sh
#
# What it does:
#   1. Brings up every real backend via docker-compose (pulls real images
#      the first time — needs internet for that one-time pull).
#   2. Waits for each one to actually pass its healthcheck (not just
#      "container started" — see docker-compose.yml's comments on why
#      that distinction matters).
#   3. Installs the real Python client libraries (redis, neo4j,
#      kafka-python, psycopg2-binary) into your current environment.
#   4. Exports every USE_REAL_* flag and runs the app pointed at all of
#      them at once.
#
# After this, open http://localhost:5000 (AdaptiveTrust), /soc (the SOC
# platform), http://localhost:3000 (Grafana, admin/admin — already wired
# to Prometheus, see grafana/provisioning/), and http://localhost:9090
# (Prometheus itself) to see it all running for real.

set -euo pipefail

echo "== Step 1: starting real backends (Redis, Neo4j, Kafka, Postgres, OPA, Prometheus, Grafana) =="
docker compose up -d redis neo4j zookeeper kafka postgres opa prometheus grafana

echo
echo "== Step 2: waiting for each one to report healthy (not just 'started') =="
for svc in redis neo4j kafka postgres opa; do
  echo -n "  waiting on $svc "
  for i in $(seq 1 30); do
    status=$(docker compose ps -q "$svc" | xargs docker inspect -f '{{.State.Health.Status}}' 2>/dev/null || echo "starting")
    if [[ "$status" == "healthy" ]]; then
      echo "-> healthy"
      break
    fi
    echo -n "."
    sleep 3
    if [[ "$i" == "30" ]]; then echo " -> still not healthy after 90s, continuing anyway"; fi
  done
done

echo
echo "== Step 3: installing real client libraries into this Python environment =="
pip install --break-system-packages redis neo4j kafka-python psycopg2-binary 2>/dev/null \
  || pip install redis neo4j kafka-python psycopg2-binary

echo
echo "== Step 4: launching the app with every USE_REAL_* flag on =="
export APP_ENV=development
export SECRET_KEY="${SECRET_KEY:-dev-placeholder-secret-key}"

export USE_REAL_REDIS=true
export REDIS_URL=redis://localhost:6379

export USE_REAL_NEO4J=true
export NEO4J_URI=bolt://localhost:7687
export NEO4J_USER=neo4j
export NEO4J_PASSWORD=password

export USE_REAL_KAFKA=true
export KAFKA_BOOTSTRAP_SERVERS=localhost:29092   # the HOST-side listener — see docker-compose.yml's note

export USE_REAL_POSTGRES=true
export POSTGRES_DSN="dbname=adaptivetrust user=adaptivetrust password=adaptivetrust host=localhost"

export USE_REAL_OPA=true
export OPA_URL=http://localhost:8181

echo "Everything is real now: Redis, Neo4j, Kafka, PostgreSQL, OPA."
echo "Grafana: http://localhost:3000 (admin/admin)  |  Prometheus: http://localhost:9090"
echo
echo "Starting the app..."
python3 app.py
