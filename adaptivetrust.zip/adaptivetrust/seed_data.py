"""
seed_data.py
--------------
Fake baseline data so the demo has something realistic to react to, based
directly on the "Alice" example running through Chapters 4 and 9 of the
design doc: normally logs in from Bangalore, 9am-5pm, ~50 calls/day
(roughly 2/minute), from her known laptop.

In a real deployment this data would be computed from historical logs, not
hard-coded — see the "Honest note" in Chapter 8 about baselines needing
real history to be meaningful.
"""

from graph_engine import IdentityGraph


USER_BASELINES = {
    "alice": {
        "usual_location": "Bangalore",
        "usual_hours": (9, 17),
        "usual_devices": {"alice-laptop"},
        "device_fingerprints": {"alice-laptop": "fp_alice_macbook_chrome_macos"},
        "avg_calls_per_minute": 2,
        "leaked_credential": False,
    },
    "bob": {
        "usual_location": "London",
        "usual_hours": (8, 16),
        "usual_devices": {"bob-desktop", "bob-phone"},
        "device_fingerprints": {
            "bob-desktop": "fp_bob_dell_edge_windows",
            "bob-phone": "fp_bob_iphone_safari_ios",
        },
        "avg_calls_per_minute": 5,
        "leaked_credential": False,
    },
    "mallory": {
        # Chapter 8's credential-exposure factor, deliberately seeded
        # "dirty" so you can see that factor light up in the demo.
        "usual_location": "New York",
        "usual_hours": (9, 18),
        "usual_devices": {"mallory-laptop"},
        "device_fingerprints": {"mallory-laptop": "fp_mallory_thinkpad_firefox_linux"},
        "avg_calls_per_minute": 3,
        "leaked_credential": True,
    },
}

KNOWN_VPN_IPS = {"10.0.0.5", "10.0.0.6"}
KNOWN_BAD_IPS = {"198.51.100.23"}


def build_seeded_graph() -> IdentityGraph:
    """Creates an IdentityGraph pre-populated with the users above, their
    known devices, and one deliberately 'shared device' relationship so the
    lateral-movement / relationship-anomaly demo (Chapter 3.3, limitation 9)
    has something to find."""
    graph = IdentityGraph()

    for user_id, baseline in USER_BASELINES.items():
        graph.add_node(user_id, "User")
        for device_id in baseline["usual_devices"]:
            graph.add_node(device_id, "Device")
            graph.add_relationship(user_id, "LOGGED_IN_FROM", device_id)

    # A deliberately suspicious relationship for the demo: bob's phone was
    # also once used to log in as mallory. This is exactly the kind of
    # relationship anomaly Chapter 7.1 says a flat access-control list can't
    # see, but a graph query can.
    graph.add_relationship("mallory", "LOGGED_IN_FROM", "bob-phone")

    return graph
