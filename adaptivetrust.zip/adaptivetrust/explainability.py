"""
explainability.py
--------------------
Chapter 7.4: "Every decision the system makes is stored with a structured
explanation of why it was made - not just the final verdict."

This turns a RiskResult (the per-factor breakdown from risk_engine.py) into
a short, readable sentence. It's deliberately separate from the risk engine
itself so the same score can be explained differently for different
audiences later (Chapter 27.2 talks about showing full point values
internally but hiding exact numbers from external logs — this is the one
function you'd change to do that).
"""


def explain(risk_result, outcome: str) -> str:
    """Builds a one-paragraph explanation like:
    'DENY (risk score 87/100). Main contributors: unrecognized device (25 pts),
    new location (Tokyo) (20 pts), 250x normal rate (20 pts).'
    """
    # Sort factors by points, biggest contributor first — this is what an
    # engineer debugging a wrong decision (Chapter 7.4's second reason)
    # actually wants to see first.
    all_factors = list(risk_result.factors)
    if risk_result.graph_signal_points > 0:
        all_factors.append(
            _FakeFactor(risk_result.graph_signal_points, risk_result.graph_signal_reason)
        )

    contributors = sorted(
        [f for f in all_factors if f.points > 0], key=lambda f: f.points, reverse=True
    )

    if not contributors:
        detail = "no individual factor contributed meaningful risk."
    else:
        parts = [f"{f.reason} ({f.points} pts)" for f in contributors[:3]]
        detail = "Main contributors: " + ", ".join(parts) + "."

    return f"{outcome} (risk score {risk_result.total_score}/100). {detail}"


class _FakeFactor:
    """Lets the graph signal slot into the same sort/format logic above
    without needing its own dataclass."""
    def __init__(self, points, reason):
        self.points = points
        self.reason = reason
