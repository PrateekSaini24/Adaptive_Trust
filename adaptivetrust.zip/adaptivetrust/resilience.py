"""
resilience.py
---------------
Chapter 15.2: "Alongside circuit breakers, explicit timeout and retry
configuration prevents any single slow call from tying up resources
indefinitely, and a documented fallback path... ensures the system
degrades gracefully rather than failing outright."

circuit_breaker.py covers Chapter 15.1 (the Closed/Open/Half-Open pattern).
This module covers the other half of Chapter 15.2 that a circuit breaker
alone doesn't give you: a single call that hangs forever, and a single
transient failure that would recover if you just tried again immediately.

Kept deliberately small — these are meant to be easy to read, not a full
resilience framework.
"""

import functools
import signal
import time


class TimeoutError_(Exception):
    """Our own name so it's obvious in a traceback that resilience.py raised
    this, not Python's built-in TimeoutError from somewhere else."""
    pass


def with_timeout(seconds: float):
    """
    Decorator: aborts the wrapped call if it takes longer than `seconds`.

    Uses SIGALRM, which only works on the main thread on Unix — perfectly
    fine for this demo's synchronous request path, but worth knowing if you
    ever call a timed function from a background thread (the event_bus
    consumers, for example, should NOT use this decorator).
    """
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            def _handle_alarm(signum, frame):
                raise TimeoutError_(f"{fn.__name__} took longer than {seconds}s")

            try:
                previous_handler = signal.signal(signal.SIGALRM, _handle_alarm)
            except ValueError:
                # SIGALRM can only be set from the main thread. A
                # production WSGI server (gunicorn with threads, for
                # example) may call this from a worker thread — in that
                # case we deliberately run the call WITHOUT timeout
                # protection rather than crash the request. This is a
                # known limitation of the signal-based approach, called
                # out here rather than hidden: a real deployment would use
                # a thread-safe timeout mechanism (e.g. concurrent.futures
                # with a future.result(timeout=...)) instead.
                return fn(*args, **kwargs)

            signal.setitimer(signal.ITIMER_REAL, seconds)
            try:
                return fn(*args, **kwargs)
            finally:
                signal.setitimer(signal.ITIMER_REAL, 0)
                signal.signal(signal.SIGALRM, previous_handler)
        return wrapper
    return decorator


def retry(max_attempts: int = 3, delay_seconds: float = 0.05):
    """
    Decorator: retries the wrapped call up to `max_attempts` times with a
    short delay between attempts, before finally letting the exception
    propagate (to be caught by a circuit breaker or a caller's fallback).

    Chapter 15.2 is explicit that this is a *prevention* mechanism — it
    stops a single blip from failing a request outright — not a substitute
    for the circuit breaker, which handles the case where the dependency is
    genuinely down for a while.
    """
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return fn(*args, **kwargs)
                except Exception as exc:
                    last_exception = exc
                    if attempt < max_attempts:
                        time.sleep(delay_seconds)
            raise last_exception
        return wrapper
    return decorator
