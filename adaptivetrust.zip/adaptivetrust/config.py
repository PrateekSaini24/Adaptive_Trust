"""
config.py
---------
Central settings for the whole app.

Design doc reference: Chapter 18, "Security Considerations" says secrets must
come from environment variables, never be hard-coded, and the app should
refuse to start in production with a default/placeholder secret. That's the
`check_secret_is_safe()` function below.
"""

import os


class Config:
    # In a real deployment this comes from an environment variable, e.g.:
    #   export SECRET_KEY="some-long-random-value"
    # We give it a placeholder default here ONLY so the demo can run without
    # any setup. See check_secret_is_safe() for the guard rail.
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-placeholder-secret-key")

    # "production" vs "development" — controls the secret-key check below.
    ENV = os.environ.get("APP_ENV", "development")

    # Policy thresholds from Chapter 10 / the worked example in Chapter 9.
    # A risk score (0-100) is compared against these to pick a decision.
    THRESHOLD_VERIFY = 30     # below this -> ALLOW
    THRESHOLD_RESTRICT = 60   # 30-59 -> VERIFY
    THRESHOLD_DENY = 80       # 60-79 -> RESTRICT, 80+ -> DENY

    # Chapter 13: cache TTL for risk scores / policy decisions, in seconds.
    CACHE_TTL_SECONDS = 300  # 5 minutes, matching the design doc's example

    # Chapter 15.1: circuit breaker tuning.
    CIRCUIT_FAILURE_THRESHOLD = 3   # open the breaker after this many failures in a row
    CIRCUIT_COOLDOWN_SECONDS = 30   # how long to stay open before trying again

    # Chapter 15.2: explicit timeout for the graph query on the request path.
    GRAPH_QUERY_TIMEOUT_SECONDS = 2.0

    # Fixed, absolute data directory for anything the app writes to disk
    # (the SQLite audit log fallback, generated compliance PDFs). Anchored
    # to this file's own location rather than the process's current working
    # directory — a relative path like "audit_log.db" would land somewhere
    # different depending on how the app was started (systemd, Docker
    # WORKDIR, supervisor, `python app.py` from a different folder, etc),
    # and Flask's send_file() resolves relative paths against the app's
    # root path while plain file writes resolve against the process cwd —
    # two different things that silently mismatch unless this is pinned.
    DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    os.makedirs(DATA_DIR, exist_ok=True)


def check_secret_is_safe(config: Config) -> None:
    """
    Chapter 18: "the settings module explicitly refuses to start in
    production with a default/placeholder secret."

    Call this once at startup. It only raises in "production" mode, so the
    demo still runs out of the box in development mode.
    """
    if config.ENV == "production" and config.SECRET_KEY == "dev-placeholder-secret-key":
        raise RuntimeError(
            "Refusing to start: SECRET_KEY is still the default placeholder. "
            "Set a real SECRET_KEY environment variable before running in production."
        )
