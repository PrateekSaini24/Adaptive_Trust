"""
soc/real_host_monitor.py
----------------------------
Replaces fabricated "endpoint" data with the REAL state of the machine
this app is actually running on, using psutil — the standard library for
this in Python, used by real monitoring tools.

There's no fleet of servers behind this demo, so "Endpoint Monitoring"
for a fleet it doesn't have would mean inventing hosts. Instead: there IS
one real, honest host to monitor — the one running app.py — so that's
what this reports. Real hostname, real CPU/RAM/disk, real running
processes (with real PIDs, parent PIDs, paths, usernames), real network
connections. If nothing suspicious is actually happening on this machine,
nothing suspicious gets reported — which is the correct behavior for a
monitoring tool, not a gap to fill with invented alerts.
"""

import socket
import platform
import threading
import time

import psutil


# Chapter 12 process-ancestry patterns, re-used here (same shape as
# soc/demo_generator.py's SUSPICIOUS_PROCESS_PATTERNS) but matched against
# REAL process parent/child names from psutil instead of invented ones.
# Configurable, per the brief: "Make the rules configurable."
SUSPICIOUS_PARENT_CHILD_PATTERNS = [
    {"parent_contains": "winword", "child_contains": "powershell", "reason": "Office application spawning a shell interpreter"},
    {"parent_contains": "excel", "child_contains": "cmd", "reason": "Office application spawning a shell interpreter"},
    {"parent_contains": "powershell", "child_contains": "certutil", "reason": "Script interpreter spawning a network-capable utility"},
    {"parent_contains": "bash", "child_contains": "nc", "reason": "Shell spawning a raw network utility (possible reverse shell)"},
    {"parent_contains": "sh", "child_contains": "wget", "reason": "Shell spawning a downloader"},
]

SUSPICIOUS_PATH_FRAGMENTS = ["/tmp/", "\\temp\\", "/dev/shm/"]


def get_real_hostname_info():
    """Real info about THIS machine — no invented fleet."""
    try:
        ip = socket.gethostbyname(socket.gethostname())
    except socket.gaierror:
        ip = "127.0.0.1"
    return {
        "hostname": socket.gethostname(),
        "ip": ip,
        "os": f"{platform.system()} {platform.release()}",
        "platform_detail": platform.platform(),
    }


def get_real_resource_usage():
    """Real CPU/RAM/disk — psutil reads these from the actual OS, not a
    random-number generator."""
    disk = psutil.disk_usage("/")
    return {
        "cpu_percent": psutil.cpu_percent(interval=0.2),
        "ram_percent": psutil.virtual_memory().percent,
        "disk_percent": disk.percent,
    }


def get_real_logged_in_users():
    try:
        return sorted(set(u.name for u in psutil.users()))
    except Exception:
        return []


def _process_matches_suspicious_pattern(proc_name, parent_name):
    proc_l, parent_l = (proc_name or "").lower(), (parent_name or "").lower()
    for pattern in SUSPICIOUS_PARENT_CHILD_PATTERNS:
        if pattern["parent_contains"] in parent_l and pattern["child_contains"] in proc_l:
            return pattern["reason"]
    return None


def get_real_processes(limit: int = 300):
    """
    Real running processes on this machine, via psutil.process_iter().
    Flags suspicious ones using the SAME kind of parent/child-name
    ancestry check the design brief asks for (Office app spawning a
    shell, script interpreter spawning a network tool, unknown executable
    from a temp directory) — but checked against REAL process trees, so
    it correctly finds nothing when nothing suspicious is actually
    running, rather than manufacturing a hit every cycle.
    """
    processes = []
    pid_to_name = {}
    for p in psutil.process_iter(["pid", "name"]):
        try:
            pid_to_name[p.info["pid"]] = p.info["name"]
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    count = 0
    for p in psutil.process_iter(["pid", "ppid", "name", "username", "cpu_percent", "memory_percent", "exe", "create_time"]):
        if count >= limit:
            break
        try:
            info = p.info
            parent_name = pid_to_name.get(info["ppid"], "")
            suspicious_reason = _process_matches_suspicious_pattern(info["name"], parent_name)

            exe_path = info.get("exe") or ""
            if not suspicious_reason and exe_path and any(frag in exe_path.lower() for frag in SUSPICIOUS_PATH_FRAGMENTS):
                suspicious_reason = "Executable running from a temporary/shared-memory directory"

            processes.append({
                "pid": info["pid"], "ppid": info["ppid"], "name": info["name"] or "",
                "username": info.get("username") or "", "cpu": info.get("cpu_percent") or 0.0,
                "memory": info.get("memory_percent") or 0.0, "exe_path": exe_path,
                "start_time": info.get("create_time") or 0,
                "suspicious": bool(suspicious_reason), "suspicious_reason": suspicious_reason or "",
                "parent_name": parent_name,
            })
            count += 1
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    return processes


def get_real_network_connections(limit: int = 200):
    """Real active network connections on this machine (psutil.net_connections).
    May require elevated privileges for some connection details depending
    on the OS/container — falls back to an empty, honestly-labeled list
    rather than fabricating entries if psutil can't read them here."""
    try:
        conns = psutil.net_connections(kind="inet")
    except (psutil.AccessDenied, PermissionError):
        return {"connections": [], "note": "Insufficient OS permissions to read real connections in this environment."}

    result = []
    for c in conns[:limit]:
        if not c.laddr:
            continue
        result.append({
            "local_address": f"{c.laddr.ip}:{c.laddr.port}" if c.laddr else "",
            "remote_address": f"{c.raddr.ip}:{c.raddr.port}" if c.raddr else "",
            "status": c.status, "pid": c.pid,
            "family": "IPv6" if c.family.name == "AF_INET6" else "IPv4",
        })
    return {"connections": result, "note": None}


def get_real_network_io():
    """Real cumulative bytes sent/received by this machine's network
    interfaces since boot — psutil.net_io_counters(), not a simulated
    counter."""
    io = psutil.net_io_counters()
    return {
        "bytes_sent": io.bytes_sent, "bytes_recv": io.bytes_recv,
        "packets_sent": io.packets_sent, "packets_recv": io.packets_recv,
    }


class RealHostMonitor:
    """Periodically refreshes the store's `hosts` and `processes` tables
    with the real state of THIS machine, replacing the fabricated
    multi-host fleet the demo generator used to invent."""

    def __init__(self, store, interval_seconds: float = 5.0):
        self.store = store
        self.interval_seconds = interval_seconds
        self._running = False
        self._thread = None
        self._host_info = get_real_hostname_info()

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        self._refresh_once()  # populate immediately, don't wait for first interval

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            try:
                self._refresh_once()
            except Exception as exc:
                print(f"[real_host_monitor] error (continuing): {exc}")
            time.sleep(self.interval_seconds)

    def _refresh_once(self):
        usage = get_real_resource_usage()
        hostname = self._host_info["hostname"]
        self.store.upsert_host(
            hostname, ip=self._host_info["ip"], os=self._host_info["os"], status="online",
            cpu=usage["cpu_percent"], ram=usage["ram_percent"], disk=usage["disk_percent"],
            logged_in_users=get_real_logged_in_users(),
        )
        self.store.clear_processes_for_host(hostname)
        for proc in get_real_processes(limit=150):
            self.store.add_process(
                host=hostname, pid=proc["pid"], ppid=proc["ppid"], name=proc["name"],
                username=proc["username"], cpu=proc["cpu"], memory=proc["memory"],
                exe_path=proc["exe_path"], suspicious=proc["suspicious"],
                suspicious_reason=proc["suspicious_reason"],
            )
            if proc["suspicious"]:
                existing = self.store.query_alerts(search=str(proc["pid"]), page_size=1)
                self.store.add_alert(
                    detection_rule="Suspicious Process Ancestry (real)", mitre_technique_id="T1059",
                    mitre_technique="Command and Scripting Interpreter", mitre_tactic="Execution",
                    severity="high", host=hostname, username=proc["username"],
                    description=f"Real process {proc['name']} (PID {proc['pid']}, parent {proc['parent_name']}) "
                                f"flagged: {proc['suspicious_reason']}",
                    confidence="medium", detection_engine="real-host-monitor",
                )
