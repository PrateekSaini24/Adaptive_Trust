"""
soc/demo_generator.py
------------------------
"The dashboard MUST work even without real security infrastructure.
Create a realistic Demo Mode... Events should be generated continuously."

A background thread that periodically invents realistic-looking events
across every category the SOC platform tracks: login failures,
brute-force attacks, port scans, malware alerts, suspicious processes,
DNS anomalies, network connections, file modifications, privilege
escalation, and plain normal events. It writes all of them through
soc/store.py, using the exact same tables and shapes a real detection
source would use - the generator is the only thing that's fake here, not
the data model.

Every alert this generator creates is tagged detection_engine="demo-
generator" (see store.py's default) so it's always honestly
distinguishable from something a real detection source produced, per the
brief's "do not claim malware detection unless an actual detection
source/rule produced the event."
"""

import random
import threading
import time
import uuid
from datetime import datetime, timezone

import geo
from soc.store import SocStore


FAKE_HOSTS = [
    {"hostname": "WEB-PROD-01", "ip": "10.20.1.11", "os": "Ubuntu 22.04 LTS"},
    {"hostname": "WEB-PROD-02", "ip": "10.20.1.12", "os": "Ubuntu 22.04 LTS"},
    {"hostname": "DB-PROD-01", "ip": "10.20.2.10", "os": "Ubuntu 22.04 LTS"},
    {"hostname": "FIN-WKS-07", "ip": "10.20.5.44", "os": "Windows 11 Enterprise"},
    {"hostname": "HR-WKS-03", "ip": "10.20.5.21", "os": "Windows 11 Enterprise"},
    {"hostname": "DEV-LAPTOP-14", "ip": "10.20.7.19", "os": "macOS 14 Sonoma"},
    {"hostname": "DC-01", "ip": "10.20.0.2", "os": "Windows Server 2022"},
    {"hostname": "MAIL-GW-01", "ip": "10.20.1.5", "os": "Ubuntu 22.04 LTS"},
]

FAKE_USERS = ["alice", "bob", "mallory", "dprice", "jsmith", "rgupta", "svc_backup", "admin"]

MALWARE_FAMILIES = ["Emotet", "TrickBot", "Cobalt Strike Beacon", "AgentTesla", "QakBot", "RedLine Stealer"]

SUSPICIOUS_PROCESS_PATTERNS = [
    {"parent": "WINWORD.EXE", "child": "powershell.exe",
     "reason": "Office application spawning a shell interpreter"},
    {"parent": "EXCEL.EXE", "child": "cmd.exe",
     "reason": "Office application spawning a shell interpreter"},
    {"parent": "powershell.exe", "child": "certutil.exe",
     "reason": "Script interpreter spawning a network-capable utility"},
    {"parent": "wscript.exe", "child": "powershell.exe",
     "reason": "Script interpreter spawning another script interpreter"},
    {"parent": "explorer.exe", "child": "AC3F91.tmp.exe",
     "reason": "Unknown executable launched from a temporary directory"},
]

NORMAL_PROCESSES = ["chrome.exe", "code.exe", "slack.exe", "outlook.exe", "sshd", "nginx", "postgres", "systemd"]

DETECTION_RULES = [
    ("Suspicious PowerShell Execution", "T1059", "Command and Scripting Interpreter", "Execution", "high"),
    ("Multiple Failed Login Attempts", "T1110", "Brute Force", "Credential Access", "medium"),
    ("Port Scan Detected", "T1595", "Active Scanning", "Reconnaissance", "low"),
    ("Known Malware Signature Match", "T1105", "Ingress Tool Transfer", "Command and Control", "critical"),
    ("Privilege Escalation Attempt", "T1068", "Exploitation for Privilege Escalation", "Privilege Escalation", "high"),
    ("Unusual Outbound Data Volume", "T1041", "Exfiltration Over C2 Channel", "Exfiltration", "high"),
    ("New Scheduled Task Created", "T1053", "Scheduled Task/Job", "Execution", "medium"),
    ("Suspicious DNS Query Pattern", "T1071", "Application Layer Protocol", "Command and Control", "medium"),
    ("Credential Dumping Tool Detected", "T1003", "OS Credential Dumping", "Credential Access", "critical"),
    ("Indicator Removal Detected", "T1070", "Indicator Removal", "Defense Evasion", "medium"),
    ("New Local Account Created", "T1136", "Create Account", "Persistence", "medium"),
    ("Remote Service Login From New Host", "T1021", "Remote Services", "Lateral Movement", "high"),
]

EXTERNAL_IP_POOL = [
    "203.0.113.{}", "198.51.100.{}", "192.0.2.{}", "45.33.{}.{}", "185.220.{}.{}", "103.21.{}.{}",
]

# A fixed "home" location standing in for the organization's own HQ/egress
# point, so the attack map has a consistent destination to draw lines
# toward (external attacker location -> our location), rather than
# fabricating a specific real company's address.
HOME_LOCATION = "new york"


def _random_external_ip():
    template = random.choice(EXTERNAL_IP_POOL)
    parts = template.count("{}")
    return template.format(*[random.randint(1, 254) for _ in range(parts)])


def _random_external_location():
    choices = [c for c in geo.CITY_COORDINATES.keys() if c != HOME_LOCATION]
    return random.choice(choices)


class DemoGenerator:
    def __init__(self, store: SocStore, event_bus=None, interval_seconds: float = 3.0):
        self.store = store
        self.event_bus = event_bus
        self.interval_seconds = interval_seconds
        self._running = False
        self._thread = None
        # Deliberately NOT seeding fake hosts here — that used to happen
        # unconditionally in __init__, which meant 8 invented hosts showed
        # up even when this generator was never start()'d. Fake data
        # should only exist once this is explicitly turned on.

    def _seed_hosts(self):
        for h in FAKE_HOSTS:
            self.store.upsert_host(
                h["hostname"], ip=h["ip"], os=h["os"], status="online",
                cpu=random.uniform(5, 40), ram=random.uniform(20, 60), disk=random.uniform(30, 70),
                logged_in_users=[random.choice(FAKE_USERS)],
                mac_address=":".join(f"{random.randint(0,255):02x}" for _ in range(6)),
            )

    def start(self):
        if self._running:
            return
        self._seed_hosts()  # only invent the fake fleet once actually started
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            try:
                self._generate_one_cycle()
            except Exception as exc:
                print(f"[demo_generator] error during cycle (continuing): {exc}")
            time.sleep(self.interval_seconds)

    def _generate_one_cycle(self):
        roll = random.random()
        if roll < 0.30:
            self._generate_normal_auth_event()
        elif roll < 0.45:
            self._generate_brute_force_burst()
        elif roll < 0.55:
            self._generate_port_scan()
        elif roll < 0.65:
            self._generate_malware_alert()
        elif roll < 0.75:
            self._generate_suspicious_process()
        elif roll < 0.82:
            self._generate_fim_event()
        elif roll < 0.90:
            self._generate_privilege_escalation()
        elif roll < 0.96:
            self._generate_dns_anomaly()
        else:
            self._generate_normal_connection()

        self._generate_normal_connection()
        self._refresh_host_metrics()

    def _refresh_host_metrics(self):
        host = random.choice(FAKE_HOSTS)
        self.store.upsert_host(
            host["hostname"], ip=host["ip"], os=host["os"],
            status=random.choices(["online", "online", "online", "warning", "offline"], weights=[70,10,10,7,3])[0],
            cpu=random.uniform(5, 85), ram=random.uniform(20, 90), disk=random.uniform(30, 80),
            logged_in_users=[random.choice(FAKE_USERS)],
        )

    def _publish_alert_event(self, alert_id):
        if self.event_bus:
            alert = self.store.get_alert(alert_id)
            if alert and alert["severity"] in ("critical", "high"):
                try:
                    self.event_bus({"type": "soc_alert", "alert": alert})
                except Exception:
                    pass

    def _mitre_for_rule(self, rule_tuple):
        name, tech_id, tech_name, tactic, severity = rule_tuple
        return {"detection_rule": name, "mitre_technique_id": tech_id,
                "mitre_technique": tech_name, "mitre_tactic": tactic, "severity": severity}

    def _generate_normal_auth_event(self):
        host = random.choice(FAKE_HOSTS)
        country = random.choice(list(geo.CITY_COORDINATES.keys()))
        self.store.add_auth_event(
            username=random.choice(FAKE_USERS), source_ip=_random_external_ip(),
            success=True, host=host["hostname"], device="corporate-laptop",
            country=country,
        )

    def _generate_brute_force_burst(self):
        target_user = random.choice(FAKE_USERS)
        attacker_ip = _random_external_ip()
        host = random.choice(FAKE_HOSTS)
        attempts = random.randint(6, 12)
        for _ in range(attempts):
            self.store.add_auth_event(
                username=target_user, source_ip=attacker_ip, success=False,
                host=host["hostname"], device="unknown", country=random.choice(list(geo.CITY_COORDINATES.keys())),
            )
        rule = self._mitre_for_rule(DETECTION_RULES[1])
        source_loc = _random_external_location()
        alert_id = self.store.add_alert(
            **rule, description=f"{attempts} failed login attempts for '{target_user}' from {attacker_ip} within a short window.",
            source_ip=attacker_ip, destination_ip=host["ip"], host=host["hostname"], username=target_user,
            protocol="SSH" if random.random() < 0.5 else "RDP", confidence="medium",
            source_country=source_loc, destination_country=HOME_LOCATION,
        )
        self.store.upsert_ioc("ip", attacker_ip, related_alert=alert_id, related_host=host["hostname"],
                               threat_level="medium", confidence="medium", source="demo-generator")
        self._publish_alert_event(alert_id)

    def _generate_port_scan(self):
        attacker_ip = _random_external_ip()
        host = random.choice(FAKE_HOSTS)
        ports = random.sample(range(1, 65535), k=random.randint(15, 40))
        for p in ports[:15]:
            self.store.add_connection(source_ip=attacker_ip, destination_ip=host["ip"],
                                       source_port=random.randint(1024, 65000), destination_port=p,
                                       protocol="TCP", bytes_transferred=random.randint(40, 200),
                                       direction="inbound")
        rule = self._mitre_for_rule(DETECTION_RULES[2])
        source_loc = _random_external_location()
        alert_id = self.store.add_alert(
            **rule, description=f"{len(ports)} distinct ports probed on {host['hostname']} from {attacker_ip}.",
            source_ip=attacker_ip, destination_ip=host["ip"], host=host["hostname"], protocol="TCP",
            confidence="high", source_country=source_loc, destination_country=HOME_LOCATION,
        )
        self.store.upsert_ioc("ip", attacker_ip, related_alert=alert_id, related_host=host["hostname"],
                               threat_level="low", confidence="medium", source="demo-generator")
        self._publish_alert_event(alert_id)

    def _generate_malware_alert(self):
        host = random.choice(FAKE_HOSTS)
        family = random.choice(MALWARE_FAMILIES)
        file_name = random.choice(["invoice.exe", "update.dll", "svchost32.exe", "readme.js", "setup_patch.exe"])
        file_hash = uuid.uuid4().hex + uuid.uuid4().hex[:32]
        rule = self._mitre_for_rule(DETECTION_RULES[3])
        alert_id = self.store.add_alert(
            **rule, description=f"Signature match for {family} in {file_name} on {host['hostname']}.",
            host=host["hostname"], username=random.choice(FAKE_USERS), protocol="",
            confidence="high", indicators=[file_hash],
        )
        self.store.add_malware_alert(
            alert_id=alert_id, malware_family=family, host=host["hostname"], file=file_name,
            hash=file_hash, severity="critical", status="new", detection_source="demo-generator (signature match)",
        )
        self.store.upsert_ioc("hash", file_hash, related_alert=alert_id, related_host=host["hostname"],
                               threat_level="high", confidence="high", malware_family=family,
                               source="demo-generator")
        self.store.add_notification("malware_detected", f"{family} detected on {host['hostname']}", "critical")
        self.store.upsert_host(host["hostname"], ip=host["ip"], os=host["os"], status="compromised",
                                cpu=random.uniform(50,95), ram=random.uniform(60,95), disk=random.uniform(40,90))
        self._publish_alert_event(alert_id)

    def _generate_suspicious_process(self):
        host = random.choice(FAKE_HOSTS)
        pattern = random.choice(SUSPICIOUS_PROCESS_PATTERNS)
        pid = random.randint(1000, 60000)
        self.store.clear_processes_for_host(host["hostname"])
        for _ in range(5):
            self.store.add_process(
                host=host["hostname"], pid=random.randint(1000, 60000), ppid=random.randint(1,999),
                name=random.choice(NORMAL_PROCESSES), username=random.choice(FAKE_USERS),
                cpu=random.uniform(0, 15), memory=random.uniform(0.5, 8),
                exe_path=f"/usr/bin/{random.choice(NORMAL_PROCESSES)}", suspicious=False,
            )
        self.store.add_process(
            host=host["hostname"], pid=pid, ppid=random.randint(1,999), name=pattern["child"],
            username=random.choice(FAKE_USERS), cpu=random.uniform(10, 60), memory=random.uniform(5, 40),
            exe_path=(f"C:\\Windows\\Temp\\{pattern['child']}" if "tmp" in pattern["child"].lower()
                      else f"C:\\Windows\\System32\\{pattern['child']}"),
            suspicious=True, suspicious_reason=pattern["reason"],
        )
        alert_id = self.store.add_alert(
            detection_rule="Suspicious Process Ancestry", mitre_technique_id="T1059",
            mitre_technique="Command and Scripting Interpreter", mitre_tactic="Execution", severity="high",
            description=f"{pattern['parent']} spawned {pattern['child']} on {host['hostname']} - {pattern['reason']}.",
            host=host["hostname"], username=random.choice(FAKE_USERS), confidence="medium",
        )
        self._publish_alert_event(alert_id)

    def _generate_fim_event(self):
        host = random.choice(FAKE_HOSTS)
        event_type = random.choice(["created", "modified", "deleted", "permissions_changed"])
        path = random.choice([
            "/etc/passwd", "/etc/shadow", "/etc/cron.d/backup", "C:\\Windows\\System32\\drivers\\etc\\hosts",
            "/var/www/html/config.php", "C:\\Users\\Public\\startup.bat",
        ])
        self.store.add_fim_event(
            host=host["hostname"], file_path=path, event_type=event_type,
            previous_hash=uuid.uuid4().hex, new_hash=(uuid.uuid4().hex if event_type != "deleted" else ""),
            user=random.choice(FAKE_USERS + ["SYSTEM", "root"]),
        )
        if path in ("/etc/passwd", "/etc/shadow") or "startup" in path.lower():
            alert_id = self.store.add_alert(
                detection_rule="Sensitive File Integrity Change", mitre_technique_id="T1070",
                mitre_technique="Indicator Removal", mitre_tactic="Defense Evasion", severity="high",
                description=f"{event_type} on sensitive path {path} on {host['hostname']}.",
                host=host["hostname"], confidence="medium",
            )
            self._publish_alert_event(alert_id)

    def _generate_privilege_escalation(self):
        host = random.choice(FAKE_HOSTS)
        user = random.choice(FAKE_USERS)
        rule = self._mitre_for_rule(DETECTION_RULES[4])
        alert_id = self.store.add_alert(
            **rule, description=f"'{user}' added to a privileged group on {host['hostname']}.",
            host=host["hostname"], username=user, confidence="high",
        )
        self.store.add_notification("privilege_escalation", f"Privilege escalation for {user} on {host['hostname']}", "high")
        self._publish_alert_event(alert_id)

    def _generate_dns_anomaly(self):
        host = random.choice(FAKE_HOSTS)
        suspicious_domain = f"{uuid.uuid4().hex[:12]}.{'xyz' if random.random()<0.5 else 'top'}"
        rule = self._mitre_for_rule(DETECTION_RULES[7])
        alert_id = self.store.add_alert(
            **rule, description=f"DNS query for {suspicious_domain} from {host['hostname']} - high-entropy subdomain pattern consistent with DGA-style C2.",
            host=host["hostname"], destination_ip=_random_external_ip(), protocol="DNS", confidence="low",
            indicators=[suspicious_domain], source_country=HOME_LOCATION, destination_country=_random_external_location(),
        )
        self.store.upsert_ioc("domain", suspicious_domain, related_alert=alert_id, related_host=host["hostname"],
                               threat_level="medium", confidence="low", source="demo-generator")
        self._publish_alert_event(alert_id)

    def _generate_normal_connection(self):
        host = random.choice(FAKE_HOSTS)
        protocol = random.choices(["HTTPS", "HTTP", "SSH", "DNS", "RDP"], weights=[45, 15, 15, 20, 5])[0]
        port = {"HTTPS": 443, "HTTP": 80, "SSH": 22, "DNS": 53, "RDP": 3389}[protocol]
        self.store.add_connection(
            source_ip=host["ip"], destination_ip=_random_external_ip(),
            source_port=random.randint(1024, 65000), destination_port=port, protocol=protocol,
            bytes_transferred=random.randint(200, 500000), direction=random.choice(["inbound", "outbound"]),
        )
