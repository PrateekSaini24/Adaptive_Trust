"""
soc/detectors.py
-------------------
"Detect suspicious patterns such as: Brute Force, Password Spray,
Impossible Travel... Clearly label these as detections/heuristics rather
than guaranteed malicious activity."

Each function here is a real, working heuristic over real auth_events rows
(whatever's actually in soc/store.py's auth_events table — demo-generated
today, a real log source tomorrow, the detector code doesn't care). None
of them claim certainty; each returns a finding with the pattern that
triggered it, so an analyst can judge for themselves. This mirrors
AdaptiveTrust's own core design principle from Chapter 8 — scoring and
explaining, not silently deciding.
"""

from collections import defaultdict
from datetime import datetime


def _parse_ts(ts_str):
    try:
        return datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def detect_brute_force(auth_events: list, threshold: int = 5, window_minutes: int = 10) -> list:
    """
    Heuristic: N+ failed logins from the SAME source IP against the SAME
    username within a short window. This is a pattern match, not a
    certainty — a shared NAT/proxy could also produce this.
    """
    findings = []
    by_ip_user = defaultdict(list)
    for e in auth_events:
        if not e.get("success"):
            ts = _parse_ts(e["timestamp"])
            if ts:
                by_ip_user[(e["source_ip"], e["username"])].append(ts)

    for (ip, username), timestamps in by_ip_user.items():
        timestamps.sort()
        for i in range(len(timestamps) - threshold + 1):
            window = timestamps[i:i + threshold]
            span_minutes = (window[-1] - window[0]).total_seconds() / 60
            if span_minutes <= window_minutes:
                findings.append({
                    "pattern": "Brute Force (heuristic)",
                    "source_ip": ip, "username": username,
                    "failed_attempts": len(window),
                    "window_minutes": round(span_minutes, 1),
                    "confidence": "heuristic — not a confirmed detection",
                })
                break  # one finding per (ip, username) pair is enough
    return findings


def detect_password_spray(auth_events: list, threshold_users: int = 4, window_minutes: int = 15) -> list:
    """
    Heuristic: ONE source IP failing logins against MANY different
    usernames in a short window — the inverse shape of brute force (many
    passwords against one account vs. one password-guess pattern against
    many accounts).
    """
    findings = []
    by_ip = defaultdict(list)
    for e in auth_events:
        if not e.get("success"):
            ts = _parse_ts(e["timestamp"])
            if ts:
                by_ip[e["source_ip"]].append((ts, e["username"]))

    for ip, events in by_ip.items():
        events.sort(key=lambda x: x[0])
        for i in range(len(events)):
            window_start = events[i][0]
            window_events = [ev for ev in events if 0 <= (ev[0] - window_start).total_seconds() / 60 <= window_minutes]
            distinct_users = {ev[1] for ev in window_events}
            if len(distinct_users) >= threshold_users:
                findings.append({
                    "pattern": "Password Spray (heuristic)",
                    "source_ip": ip,
                    "distinct_usernames_targeted": len(distinct_users),
                    "usernames": sorted(distinct_users)[:10],
                    "window_minutes": window_minutes,
                    "confidence": "heuristic — not a confirmed detection",
                })
                break
    return findings


# Very rough per-country "typical" travel speed ceiling, for the impossible-
# travel heuristic below — commercial flight speed, generously rounded up.
MAX_PLAUSIBLE_KMH = 1000


def detect_impossible_travel(auth_events: list, city_coords: dict) -> list:
    """
    Heuristic: the same username logs in successfully from two DIFFERENT
    locations, close enough in time that traveling between them would
    require an implausible speed. Uses the real haversine distance (same
    geo.py used by the risk engine) — not a guess.
    """
    import geo  # the project's own real-distance module — reused, not duplicated

    findings = []
    by_user = defaultdict(list)
    for e in auth_events:
        if e.get("success"):
            ts = _parse_ts(e["timestamp"])
            country = (e.get("country") or "").strip().lower()
            if ts and country in city_coords:
                by_user[e["username"]].append((ts, e["country"], country))

    for username, events in by_user.items():
        events.sort(key=lambda x: x[0])
        for i in range(len(events) - 1):
            t1, loc1_display, loc1 = events[i]
            t2, loc2_display, loc2 = events[i + 1]
            if loc1 == loc2:
                continue
            hours = (t2 - t1).total_seconds() / 3600
            if hours <= 0:
                continue
            distance_km = geo.distance_between_cities_km(loc1, loc2)
            if distance_km is None:
                continue
            required_kmh = distance_km / hours
            if required_kmh > MAX_PLAUSIBLE_KMH:
                findings.append({
                    "pattern": "Impossible Travel (heuristic)",
                    "username": username,
                    "first_location": loc1_display, "first_time": t1.isoformat(),
                    "second_location": loc2_display, "second_time": t2.isoformat(),
                    "distance_km": round(distance_km),
                    "elapsed_hours": round(hours, 2),
                    "required_speed_kmh": round(required_kmh),
                    "confidence": "heuristic — not a confirmed detection",
                })
    return findings


def run_all_detectors(auth_events: list, city_coords: dict) -> dict:
    return {
        "brute_force": detect_brute_force(auth_events),
        "password_spray": detect_password_spray(auth_events),
        "impossible_travel": detect_impossible_travel(auth_events, city_coords),
    }
