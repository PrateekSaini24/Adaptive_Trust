"""
soc/real_fim.py
------------------
Real File Integrity Monitoring: periodically computes real SHA-256 hashes
of real files under a watched directory and records a real fim_event the
moment a hash actually changes (or a file is actually created/deleted) —
not a simulated event on a schedule.

By default it watches this project's own source directory, which is a
genuinely meaningful thing to watch (if you edit app.py while the demo is
running, that's a real, correct FIM hit) and needs no extra setup. Point
WATCH_DIR at anything else (e.g. /etc on a real Linux host) to watch real
system files instead — same code, real behavior either way.
"""

import os
import hashlib
import threading
import time


DEFAULT_IGNORED_DIRS = {"__pycache__", ".git", "node_modules", "data", "venv", ".venv"}
DEFAULT_IGNORED_EXTENSIONS = {".pyc", ".db", ".log"}


def _sha256_of_file(path: str) -> str:
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except (OSError, PermissionError):
        return ""


def _iter_watched_files(root: str):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in DEFAULT_IGNORED_DIRS]
        for name in filenames:
            if os.path.splitext(name)[1] in DEFAULT_IGNORED_EXTENSIONS:
                continue
            yield os.path.join(dirpath, name)


class RealFileIntegrityMonitor:
    def __init__(self, store, watch_dir: str, interval_seconds: float = 10.0):
        self.store = store
        self.watch_dir = watch_dir
        self.interval_seconds = interval_seconds
        self._running = False
        self._thread = None
        self._known_hashes = {}  # {path: sha256}
        self._baseline_taken = False

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _loop(self):
        # First pass establishes the baseline silently — a freshly-started
        # monitor shouldn't report every existing file as "created".
        self._scan(record_events=False)
        self._baseline_taken = True
        while self._running:
            try:
                self._scan(record_events=True)
            except Exception as exc:
                print(f"[real_fim] error (continuing): {exc}")
            time.sleep(self.interval_seconds)

    def _scan(self, record_events: bool):
        current_files = set()
        for path in _iter_watched_files(self.watch_dir):
            current_files.add(path)
            new_hash = _sha256_of_file(path)
            if not new_hash:
                continue
            old_hash = self._known_hashes.get(path)

            if old_hash is None:
                self._known_hashes[path] = new_hash
                if record_events:
                    self._record(path, "created", "", new_hash)
            elif old_hash != new_hash:
                self._known_hashes[path] = new_hash
                if record_events:
                    self._record(path, "modified", old_hash, new_hash)

        deleted = set(self._known_hashes.keys()) - current_files
        for path in deleted:
            old_hash = self._known_hashes.pop(path)
            if record_events:
                self._record(path, "deleted", old_hash, "")

    def _record(self, path, event_type, old_hash, new_hash):
        rel_path = os.path.relpath(path, self.watch_dir)
        self.store.add_fim_event(
            host="this-host", file_path=rel_path, event_type=event_type,
            previous_hash=old_hash, new_hash=new_hash, user="",
        )
