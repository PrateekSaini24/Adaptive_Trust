"""
soc/real_vuln_scan.py
------------------------
Replaces "sample CVEs on fake hosts" with a real Software Composition
Analysis: scan the packages ACTUALLY installed in this Python environment
(importlib.metadata - real, not requirements.txt wishlist versions) and
check each one against OSV.dev's real, free, keyless vulnerability
database (https://osv.dev, backed by Google - the same open database
pip-audit and GitHub's Dependabot draw from).
"""

import json
import urllib.request
import urllib.error
from importlib import metadata


OSV_BATCH_URL = "https://api.osv.dev/v1/querybatch"
OSV_VULN_URL = "https://api.osv.dev/v1/vulns/{vuln_id}"


def real_installed_packages() -> list:
    packages = []
    for dist in metadata.distributions():
        name = dist.metadata.get("Name")
        version = dist.version
        if name and version:
            packages.append({"name": name, "version": version})
    seen = set()
    unique = []
    for p in packages:
        key = p["name"].lower()
        if key not in seen:
            seen.add(key)
            unique.append(p)
    return unique


def scan_real_packages_for_vulnerabilities(packages: list = None, timeout: float = 8.0):
    packages = packages if packages is not None else real_installed_packages()
    queries = [{"package": {"name": p["name"], "ecosystem": "PyPI"}, "version": p["version"]} for p in packages]

    body = json.dumps({"queries": queries}).encode("utf-8")
    request = urllib.request.Request(
        OSV_BATCH_URL, data=body, headers={"Content-Type": "application/json"}, method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        return None, f"OSV.dev unreachable: {exc}"

    results = []
    for pkg, result in zip(packages, data.get("results", [])):
        vulns = result.get("vulns", [])
        if vulns:
            results.append({
                "package": pkg["name"], "version": pkg["version"],
                "vuln_ids": [v["id"] for v in vulns],
            })
    return results, None


def fetch_vuln_detail(vuln_id: str, timeout: float = 6.0):
    request = urllib.request.Request(OSV_VULN_URL.format(vuln_id=vuln_id),
                                      headers={"User-Agent": "AdaptiveTrust-SOC"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        return None

    cvss_score = None
    for sev in data.get("severity", []):
        if sev.get("type", "").startswith("CVSS"):
            cvss_score = sev.get("score")
    return {
        "id": data.get("id"), "summary": data.get("summary", ""),
        "details": (data.get("details", "") or "")[:500],
        "severity_vector": cvss_score, "published": data.get("published"),
        "references": [r.get("url") for r in data.get("references", [])][:5],
    }
