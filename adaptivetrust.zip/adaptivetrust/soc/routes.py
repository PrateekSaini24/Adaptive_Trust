"""
soc/routes.py
----------------
Every SOC platform endpoint, as a Flask Blueprint so app.py doesn't have
to grow by another 700 lines directly. Registered in app.py with
app.register_blueprint(soc_bp, url_prefix="/soc/api").

Each section below maps directly to one numbered requirement from the
brief (KPI cards, alert feed, alert details, incidents, threat intel, IP
investigation, network monitoring, attack map, auth monitoring, endpoint
monitoring, process monitoring, FIM, malware, vulnerabilities, MITRE
ATT&CK, notifications, audit log, demo mode).
"""

import os
import csv
import io
import time
from collections import deque
from flask import Blueprint, request, jsonify, Response

from soc.store import SocStore
from soc.demo_generator import DemoGenerator
from soc.real_host_monitor import RealHostMonitor
from soc.real_fim import RealFileIntegrityMonitor
from soc.real_vuln_scan import scan_real_packages_for_vulnerabilities, fetch_vuln_detail
from soc.real_malware_check import check_file_bytes
from soc import mitre_data
from soc import ip_lookup
from soc.nvd_lookup import NvdCache
from soc.detectors import run_all_detectors
from soc.auth import issue_soc_token, require_role
import geo


soc_bp = Blueprint("soc", __name__)

store: SocStore = None
generator: DemoGenerator = None           # synthetic load-test tool — OFF by default, see note below
host_monitor: RealHostMonitor = None      # real, always on
fim_monitor: RealFileIntegrityMonitor = None  # real, always on
nvd_cache: NvdCache = None
_recent_latencies = deque(maxlen=200)
_secret_key = None


def _get_secret_key():
    return _secret_key


def init_soc(data_dir: str, secret_key: str, event_bus_publish=None, project_root: str = None):
    """
    By default, every data source this wires up is REAL:
      - host_monitor: the real CPU/RAM/disk/processes of the machine
        actually running this app (soc/real_host_monitor.py)
      - fim_monitor: real file hashes of this project's own source tree,
        watched for real changes (soc/real_fim.py)
      - vulnerabilities: triggered on demand against the REAL installed
        packages via the real OSV.dev database (soc/real_vuln_scan.py) —
        not run automatically at startup since it needs network access
      - malware: real SHA-256 hash checking of uploaded files
        (soc/real_malware_check.py) — zero alerts until something real
        actually matches a real signature

    `generator` (soc/demo_generator.py) still exists but is NEVER started
    automatically. It's available purely as an opt-in synthetic
    load-generation tool (for exercising filters/pagination/UI with
    volume) via POST /demo/start, and every event it creates is tagged
    detection_engine="demo-generator" so it's never confused with
    something a real source produced.
    """
    global store, generator, host_monitor, fim_monitor, nvd_cache, _secret_key
    _secret_key = secret_key
    store = SocStore(os.path.join(data_dir, "soc.db"))
    nvd_cache = NvdCache(os.path.join(data_dir, "nvd_cache.json"))

    generator = DemoGenerator(store, event_bus=event_bus_publish)  # NOT started

    host_monitor = RealHostMonitor(store)
    host_monitor.start()

    watch_dir = project_root or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    fim_monitor = RealFileIntegrityMonitor(store, watch_dir=watch_dir)
    fim_monitor.start()

    return store, generator


def _analyst():
    """The 'logged in analyst' for audit-log purposes. Prefers the
    identity from a verified SOC session token (set by @require_role) —
    that's the real, tamper-proof source. Falls back to whatever the
    caller claims in the request for read-only/unauthenticated demo
    convenience, e.g. quick manual testing without a login step."""
    if hasattr(request, "soc_user"):
        return request.soc_user
    body = request.get_json(silent=True) or {}
    return request.args.get("analyst") or body.get("analyst") or "demo-analyst"


def _client_ip():
    return request.headers.get("X-Forwarded-For", request.remote_addr or "")


# ===========================================================================
# SOC analyst login (separate from AdaptiveTrust's own end-user auth)
# ===========================================================================

@soc_bp.route("/auth/login", methods=["POST"])
def soc_login():
    body = request.get_json(force=True) or {}
    username = (body.get("username") or "").strip()
    role = body.get("role", "viewer")
    if not username:
        return jsonify({"error": "username is required"}), 400
    token = issue_soc_token(username, role, _get_secret_key())
    store.log_action(username, "soc_login", role, _client_ip())
    return jsonify({"token": token, "username": username, "role": role})


@soc_bp.route("/auth/whoami", methods=["GET"])
@require_role("viewer", _get_secret_key)
def soc_whoami():
    return jsonify({"username": request.soc_user, "role": request.soc_role})


@soc_bp.route("/kpis", methods=["GET"])
def kpis():
    alert_counts = store.alert_counts()
    incidents_resolved = store.query_incidents(status="RESOLVED", page_size=1)["total"] + \
        store.query_incidents(status="CLOSED", page_size=1)["total"]
    hosts = store.list_hosts()

    now = time.time()
    recent = [t for t in _recent_latencies if now - t <= 10.0]
    events_per_second = round(len(recent) / 10.0, 2)

    def card(value):
        return {"value": value, "change_pct": None}

    return jsonify({
        "total_alerts": card(alert_counts["total"]),
        "critical_alerts": card(alert_counts["by_severity"].get("critical", 0)),
        "high_alerts": card(alert_counts["by_severity"].get("high", 0)),
        "medium_alerts": card(alert_counts["by_severity"].get("medium", 0)),
        "low_alerts": card(alert_counts["by_severity"].get("low", 0)),
        "active_incidents": card(store.query_incidents(page_size=1)["total"] - incidents_resolved),
        "resolved_incidents": card(incidents_resolved),
        "hosts_monitored": card(len(hosts)),
        "users_monitored": card(len(set(u for h in hosts for u in h.get("logged_in_users", [])))),
        "events_per_second": card(events_per_second),
    })


@soc_bp.route("/kpis/sparkline/<metric>", methods=["GET"])
def kpi_sparkline(metric):
    alerts = store.query_alerts(page_size=500)["items"]
    if not alerts:
        return jsonify([0] * 12)
    buckets = [0] * 12
    now = time.time()
    for a in alerts:
        try:
            from datetime import datetime
            ts = datetime.fromisoformat(a["timestamp"].replace("Z", "+00:00")).timestamp()
        except (ValueError, AttributeError):
            continue
        age_minutes = (now - ts) / 60
        bucket = int(age_minutes // 5)
        if 0 <= bucket < 12:
            buckets[11 - bucket] += 1
    return jsonify(buckets)


@soc_bp.route("/alerts", methods=["GET"])
def list_alerts():
    result = store.query_alerts(
        severity=request.args.get("severity") or None,
        status=request.args.get("status") or None,
        search=request.args.get("search") or None,
        sort_by=request.args.get("sort_by", "timestamp"),
        sort_dir=request.args.get("sort_dir", "desc"),
        page=int(request.args.get("page", 1)),
        page_size=min(int(request.args.get("page_size", 25)), 200),
    )
    return jsonify(result)


@soc_bp.route("/alerts/export.csv", methods=["GET"])
def export_alerts_csv():
    rows = store.query_alerts(page_size=5000)["items"]
    buffer = io.StringIO()
    if rows:
        flat_rows = [{k: v for k, v in r.items() if not isinstance(v, list)} for r in rows]
        writer = csv.DictWriter(buffer, fieldnames=list(flat_rows[0].keys()))
        writer.writeheader()
        writer.writerows(flat_rows)
    return Response(buffer.getvalue().encode("utf-8"), mimetype="text/csv",
                     headers={"Content-Disposition": "attachment; filename=soc_alerts_export.csv"})


@soc_bp.route("/alerts/<alert_id>", methods=["GET"])
def get_alert(alert_id):
    alert = store.get_alert(alert_id)
    if not alert:
        return jsonify({"error": "not found"}), 404
    technique = mitre_data.technique_by_id(alert.get("mitre_technique_id", ""))
    related = []
    if alert.get("host"):
        same_host = store.query_alerts(page_size=10)["items"]
        related = [a["id"] for a in same_host if a["host"] == alert["host"] and a["id"] != alert_id][:5]
    return jsonify({**alert, "mitre_detail": technique, "related_events": related})


@soc_bp.route("/alerts/<alert_id>/assign", methods=["POST"])
@require_role("analyst", _get_secret_key)
def assign_alert(alert_id):
    body = request.get_json(force=True) or {}
    analyst = body.get("analyst", "unassigned")
    ok = store.update_alert(alert_id, assigned_analyst=analyst)
    if ok:
        store.log_action(_analyst(), "alert_assigned", alert_id, _client_ip())
    return jsonify({"status": "ok" if ok else "not found"}), (200 if ok else 404)


@soc_bp.route("/alerts/<alert_id>/severity", methods=["POST"])
@require_role("analyst", _get_secret_key)
def change_alert_severity(alert_id):
    body = request.get_json(force=True) or {}
    ok = store.update_alert(alert_id, severity=body.get("severity"))
    if ok:
        store.log_action(_analyst(), "severity_changed", alert_id, _client_ip())
    return jsonify({"status": "ok" if ok else "not found"}), (200 if ok else 404)


@soc_bp.route("/alerts/<alert_id>/status", methods=["POST"])
@require_role("analyst", _get_secret_key)
def change_alert_status(alert_id):
    body = request.get_json(force=True) or {}
    new_status = body.get("status")
    ok = store.update_alert(alert_id, status=new_status)
    if ok:
        store.log_action(_analyst(), f"status_changed_to_{new_status}", alert_id, _client_ip())
    return jsonify({"status": "ok" if ok else "not found"}), (200 if ok else 404)


@soc_bp.route("/alerts/<alert_id>/notes", methods=["POST"])
@require_role("analyst", _get_secret_key)
def add_alert_note(alert_id):
    body = request.get_json(force=True) or {}
    ok = store.add_alert_note(alert_id, _analyst(), body.get("text", ""))
    if ok:
        store.log_action(_analyst(), "note_added", alert_id, _client_ip())
    return jsonify({"status": "ok" if ok else "not found"}), (200 if ok else 404)


@soc_bp.route("/alerts/<alert_id>/tags", methods=["POST"])
@require_role("analyst", _get_secret_key)
def add_alert_tags(alert_id):
    body = request.get_json(force=True) or {}
    ok = store.add_alert_tags(alert_id, body.get("tags", []))
    if ok:
        store.log_action(_analyst(), "tags_added", alert_id, _client_ip())
    return jsonify({"status": "ok" if ok else "not found"}), (200 if ok else 404)


@soc_bp.route("/alerts/<alert_id>/false-positive", methods=["POST"])
@require_role("analyst", _get_secret_key)
def mark_false_positive(alert_id):
    ok = store.update_alert(alert_id, status="false_positive")
    if ok:
        store.log_action(_analyst(), "marked_false_positive", alert_id, _client_ip())
    return jsonify({"status": "ok" if ok else "not found"}), (200 if ok else 404)


@soc_bp.route("/alerts/<alert_id>/escalate", methods=["POST"])
@require_role("analyst", _get_secret_key)
def escalate_alert(alert_id):
    ok = store.update_alert(alert_id, status="escalated")
    if ok:
        alert = store.get_alert(alert_id)
        store.add_notification("alert_escalated", f"{alert_id} escalated: {alert['detection_rule']}", "high")
        store.log_action(_analyst(), "escalated", alert_id, _client_ip())
    return jsonify({"status": "ok" if ok else "not found"}), (200 if ok else 404)


@soc_bp.route("/alerts/<alert_id>/resolve", methods=["POST"])
@require_role("analyst", _get_secret_key)
def resolve_alert(alert_id):
    ok = store.update_alert(alert_id, status="resolved")
    if ok:
        store.log_action(_analyst(), "resolved", alert_id, _client_ip())
    return jsonify({"status": "ok" if ok else "not found"}), (200 if ok else 404)


@soc_bp.route("/incidents", methods=["GET"])
def list_incidents():
    result = store.query_incidents(
        status=request.args.get("status") or None,
        severity=request.args.get("severity") or None,
        page=int(request.args.get("page", 1)),
        page_size=min(int(request.args.get("page_size", 25)), 200),
    )
    return jsonify(result)


@soc_bp.route("/incidents", methods=["POST"])
@require_role("analyst", _get_secret_key)
def create_incident():
    body = request.get_json(force=True) or {}
    incident_id = store.add_incident(**body)
    store.log_action(_analyst(), "incident_created", incident_id, _client_ip())
    return jsonify({"id": incident_id}), 201


@soc_bp.route("/incidents/<incident_id>", methods=["GET"])
def get_incident(incident_id):
    incident = store.get_incident(incident_id)
    if not incident:
        return jsonify({"error": "not found"}), 404
    return jsonify(incident)


@soc_bp.route("/incidents/<incident_id>/status", methods=["POST"])
@require_role("analyst", _get_secret_key)
def change_incident_status(incident_id):
    body = request.get_json(force=True) or {}
    new_status = body.get("status", "")
    ok = store.update_incident_status(incident_id, new_status, _analyst())
    if ok:
        store.log_action(_analyst(), f"incident_status_{new_status}", incident_id, _client_ip())
        return jsonify({"status": "ok"})
    return jsonify({"error": f"invalid status or incident not found. Valid: {store.INCIDENT_STATUSES}"}), 400


@soc_bp.route("/incidents/<incident_id>/notes", methods=["POST"])
@require_role("analyst", _get_secret_key)
def add_incident_note(incident_id):
    body = request.get_json(force=True) or {}
    ok = store.add_incident_note(incident_id, _analyst(), body.get("text", ""))
    if ok:
        store.log_action(_analyst(), "incident_note_added", incident_id, _client_ip())
    return jsonify({"status": "ok" if ok else "not found"}), (200 if ok else 404)


@soc_bp.route("/incidents/statuses", methods=["GET"])
def incident_statuses():
    return jsonify(store.INCIDENT_STATUSES)


@soc_bp.route("/iocs", methods=["GET"])
def list_iocs():
    result = store.query_iocs(
        ioc_type=request.args.get("type") or None,
        search=request.args.get("search") or None,
        page=int(request.args.get("page", 1)),
        page_size=min(int(request.args.get("page_size", 25)), 200),
    )
    return jsonify(result)


@soc_bp.route("/iocs", methods=["POST"])
@require_role("analyst", _get_secret_key)
def add_ioc():
    body = request.get_json(force=True) or {}
    ioc_id = store.upsert_ioc(
        body.get("ioc_type", "ip"), body.get("value", ""),
        threat_level=body.get("threat_level", "medium"), confidence=body.get("confidence", "medium"),
        source=body.get("source", "manual-analyst-entry"),
        malware_family=body.get("malware_family", ""), threat_actor=body.get("threat_actor", ""),
    )
    store.log_action(_analyst(), "ioc_added", ioc_id, _client_ip())
    return jsonify({"id": ioc_id}), 201


@soc_bp.route("/ip-investigate/<ip>", methods=["GET"])
def investigate_ip(ip):
    reputation_info = ip_lookup.lookup_ip(ip)
    alerts = store.query_alerts(search=ip, page_size=50)["items"]
    related_alert_ids = [a["id"] for a in alerts if a["source_ip"] == ip or a["destination_ip"] == ip]
    connections = store.recent_connections(limit=1000)
    related_connections = [c for c in connections if c["source_ip"] == ip or c["destination_ip"] == ip]
    auth_events_ = [e for e in store.list_auth_events(limit=1000) if e["source_ip"] == ip]
    related_hosts = sorted(set(
        [a["host"] for a in alerts if a.get("host") and (a["source_ip"] == ip or a["destination_ip"] == ip)]
    ))
    timestamps = [c["timestamp"] for c in related_connections] + [a["timestamp"] for a in alerts] + \
                 [e["timestamp"] for e in auth_events_]
    return jsonify({
        "ip": ip, "reputation": reputation_info,
        "related_alerts": related_alert_ids, "related_alert_count": len(related_alert_ids),
        "connection_count": len(related_connections), "related_hosts": related_hosts,
        "first_seen": min(timestamps) if timestamps else None,
        "last_seen": max(timestamps) if timestamps else None,
    })


@soc_bp.route("/network/stats", methods=["GET"])
def network_stats():
    stats = store.network_stats()
    recent_conns = store.recent_connections(500)
    stats["dns_queries"] = sum(1 for c in recent_conns if c["protocol"] == "DNS")
    stats["http_connections"] = sum(1 for c in recent_conns if c["protocol"] == "HTTP")
    stats["https_connections"] = sum(1 for c in recent_conns if c["protocol"] == "HTTPS")
    stats["ssh_connections"] = sum(1 for c in recent_conns if c["protocol"] == "SSH")
    stats["rdp_connections"] = sum(1 for c in recent_conns if c["protocol"] == "RDP")
    return jsonify(stats)


@soc_bp.route("/network/connections", methods=["GET"])
def network_connections():
    return jsonify(store.recent_connections(limit=int(request.args.get("limit", 50))))


@soc_bp.route("/attack-map", methods=["GET"])
def attack_map():
    severity_filter = request.args.get("severity")
    alerts = store.query_alerts(severity=severity_filter, page_size=200)["items"]
    points = []
    for a in alerts:
        src, dst = a.get("source_country"), a.get("destination_country")
        if not src or not dst:
            continue
        src_coord = geo.CITY_COORDINATES.get(src.lower())
        dst_coord = geo.CITY_COORDINATES.get(dst.lower())
        if not src_coord or not dst_coord:
            continue
        points.append({
            "source_location": src, "destination_location": dst,
            "source_lat": src_coord[0], "source_lon": src_coord[1],
            "destination_lat": dst_coord[0], "destination_lon": dst_coord[1],
            "source_ip": a.get("source_ip"), "destination_ip": a.get("destination_ip"),
            "severity": a["severity"], "alert_id": a["id"], "timestamp": a["timestamp"],
        })
    return jsonify({
        "points": points,
        "note": "Locations are resolved to city-level reference coordinates, not precise "
                "geographic positions - see geo.py. Do not read this as pinpoint accuracy.",
    })


@soc_bp.route("/auth/events", methods=["GET"])
def auth_events():
    return jsonify(store.list_auth_events(limit=int(request.args.get("limit", 100))))


@soc_bp.route("/auth/stats", methods=["GET"])
def auth_stats():
    return jsonify(store.auth_stats())


@soc_bp.route("/auth/detections", methods=["GET"])
def auth_detections():
    events = store.list_auth_events(limit=2000)
    findings = run_all_detectors(events, geo.CITY_COORDINATES)
    return jsonify(findings)


@soc_bp.route("/hosts", methods=["GET"])
def list_hosts():
    return jsonify(store.list_hosts())


@soc_bp.route("/hosts/<hostname>", methods=["GET"])
def get_host(hostname):
    host = store.get_host(hostname)
    if not host:
        return jsonify({"error": "not found"}), 404
    host["processes"] = store.list_processes(host=hostname)
    host["recent_alerts"] = [a for a in store.query_alerts(page_size=100)["items"] if a["host"] == hostname][:10]
    host["fim_events"] = store.list_fim_events(host=hostname, limit=20)
    return jsonify(host)


@soc_bp.route("/processes", methods=["GET"])
def list_processes():
    return jsonify(store.list_processes(
        host=request.args.get("host") or None,
        suspicious_only=request.args.get("suspicious_only") == "true",
    ))


@soc_bp.route("/fim", methods=["GET"])
def list_fim():
    return jsonify(store.list_fim_events(
        host=request.args.get("host") or None, limit=int(request.args.get("limit", 100))
    ))


@soc_bp.route("/malware", methods=["GET"])
def list_malware():
    return jsonify(store.list_malware_alerts(limit=int(request.args.get("limit", 100))))


@soc_bp.route("/malware/scan-file", methods=["POST"])
@require_role("analyst", _get_secret_key)
def scan_file_for_malware():
    """
    Real SHA-256 hash check (soc/real_malware_check.py) against an
    uploaded file. Try it with the real EICAR test string
    (https://www.eicar.org/download-anti-malware-testfile/) — the one
    "malware" every antivirus product agrees is safe to use for exactly
    this kind of test. A clean file correctly returns matched=false; this
    only writes a malware_alert/SOC alert when a real hash actually
    matches, never on a schedule.
    """
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded (multipart field name must be 'file')"}), 400
    uploaded = request.files["file"]
    data = uploaded.read()
    if len(data) > 10 * 1024 * 1024:
        return jsonify({"error": "file too large for this demo scanner (10MB limit)"}), 400

    result = check_file_bytes(data, uploaded.filename or "uploaded")
    if result["matched"]:
        alert_id = store.add_alert(
            detection_rule="Real Hash-Based Malware Detection", mitre_technique_id="T1105",
            mitre_technique="Ingress Tool Transfer", mitre_tactic="Command and Control", severity="critical",
            description=f"Uploaded file '{result['filename']}' matched known signature "
                        f"{result['malware_family']}: {result['description']}",
            confidence="high", detection_engine="real-hash-scan", indicators=[result["hash"]],
        )
        store.add_malware_alert(
            alert_id=alert_id, malware_family=result["malware_family"], host="uploaded-file",
            file=result["filename"], hash=result["hash"], severity="critical", status="new",
            detection_source="real SHA-256 signature match",
        )
        store.log_action(_analyst(), "malware_scan_match", result["hash"], _client_ip())
    return jsonify(result)


@soc_bp.route("/vulnerabilities", methods=["GET"])
def list_vulnerabilities():
    return jsonify(store.query_vulnerabilities(
        severity=request.args.get("severity") or None,
        host=request.args.get("host") or None,
        cve=request.args.get("cve") or None,
        page=int(request.args.get("page", 1)),
        page_size=min(int(request.args.get("page_size", 25)), 200),
    ))


@soc_bp.route("/vulnerabilities/scan-real", methods=["POST"])
@require_role("analyst", _get_secret_key)
def scan_real_vulnerabilities():
    """
    Real Software Composition Analysis: checks the packages ACTUALLY
    installed in this Python environment against the real OSV.dev
    database (soc/real_vuln_scan.py). Honest on failure — if OSV.dev is
    unreachable (as in this project's own offline build sandbox), says so
    explicitly rather than silently returning an empty "all clear."
    """
    from soc.real_vuln_scan import real_installed_packages
    packages = real_installed_packages()
    results, error = scan_real_packages_for_vulnerabilities(packages)
    if error:
        return jsonify({"error": error, "scanned": len(packages), "vulnerabilities_found": 0})

    host = "this-host"
    stored = 0
    for r in results:
        for vuln_id in r["vuln_ids"]:
            store.upsert_vulnerability(
                host=host, cve=vuln_id, cvss_score=0,  # OSV doesn't always expose a numeric score; see real_vuln_scan.py
                severity="unknown", affected_software=f"{r['package']} {r['version']}",
                installed_version=r["version"], fixed_version="see advisory",
                source="real-osv-scan",
            )
            stored += 1
    store.log_action(_analyst(), "real_vulnerability_scan", f"{stored} findings", _client_ip())
    return jsonify({"scanned": len(packages), "vulnerabilities_found": stored, "results": results})


@soc_bp.route("/vulnerabilities/cve/<cve_id>", methods=["GET"])
def cve_lookup(cve_id):
    allow_live = request.args.get("live", "true") != "false"
    return jsonify(nvd_cache.get_or_fetch(cve_id, allow_live=allow_live))


@soc_bp.route("/mitre/tactics", methods=["GET"])
def mitre_tactics():
    alerts = store.query_alerts(page_size=1000)["items"]
    counts_by_tactic = {}
    for a in alerts:
        t = a.get("mitre_tactic")
        if t:
            counts_by_tactic[t] = counts_by_tactic.get(t, 0) + 1
    return jsonify([
        {**tactic, "alert_count": counts_by_tactic.get(tactic["name"], 0),
         "technique_count": len(mitre_data.techniques_for_tactic(tactic["name"]))}
        for tactic in mitre_data.TACTICS
    ])


@soc_bp.route("/mitre/technique/<technique_id>", methods=["GET"])
def mitre_technique_detail(technique_id):
    technique = mitre_data.technique_by_id(technique_id)
    if not technique:
        return jsonify({"error": "unknown technique id"}), 404
    alerts = store.query_alerts(page_size=1000)["items"]
    related_alerts = [a for a in alerts if a.get("mitre_technique_id") == technique_id]
    hosts_affected = sorted(set(a["host"] for a in related_alerts if a.get("host")))
    return jsonify({**technique, "related_alerts": [a["id"] for a in related_alerts][:20],
                     "hosts_affected": hosts_affected})


@soc_bp.route("/mitre/top-techniques", methods=["GET"])
def mitre_top_techniques():
    alerts = store.query_alerts(page_size=1000)["items"]
    counts = {}
    for a in alerts:
        tid = a.get("mitre_technique_id")
        if tid:
            counts[tid] = counts.get(tid, 0) + 1
    ranked = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)[:10]
    return jsonify([
        {"technique_id": tid, "name": (mitre_data.technique_by_id(tid) or {}).get("name", tid), "count": c}
        for tid, c in ranked
    ])


@soc_bp.route("/notifications", methods=["GET"])
def list_notifications():
    return jsonify(store.list_notifications(unread_only=request.args.get("unread_only") == "true"))


@soc_bp.route("/notifications/<notif_id>/read", methods=["POST"])
@require_role("analyst", _get_secret_key)
def mark_notification_read(notif_id):
    store.mark_notification_read(notif_id)
    return jsonify({"status": "ok"})


@soc_bp.route("/audit-log", methods=["GET"])
@require_role("admin", _get_secret_key)
def audit_log():
    return jsonify(store.list_audit_log(limit=int(request.args.get("limit", 200))))


@soc_bp.route("/demo/status", methods=["GET"])
def demo_status():
    return jsonify({"running": generator._running, "interval_seconds": generator.interval_seconds})


@soc_bp.route("/demo/start", methods=["POST"])
@require_role("admin", _get_secret_key)
def demo_start():
    generator.start()
    return jsonify({"running": True})


@soc_bp.route("/demo/stop", methods=["POST"])
@require_role("admin", _get_secret_key)
def demo_stop():
    generator.stop()
    return jsonify({"running": False})
