"""
soc/auth.py
-------------
Role-based access for the SOC platform: viewer / analyst / admin.

This is a SEPARATE login from AdaptiveTrust's own /auth/token (which
authenticates end users being risk-scored) — this one authenticates
SOC ANALYSTS using the platform. Two different systems being asked to
authenticate two different kinds of people is normal; conflating them
would be the actual mistake.

Real signed JWTs (same PyJWT approach as the main app's auth.py), so a
role can't be tampered with client-side — the server only trusts the role
inside a verified token's signature, never a role the client merely
claims in a request body.

Roles, least to most privileged:
  viewer   - read-only: can see every dashboard/page, cannot change anything
  analyst  - viewer + can act on alerts/incidents (assign, status, notes,
             escalate, resolve, mark false positive)
  admin    - analyst + can manage threat intel sources, view the full
             audit log, and control demo mode

There's no real user database behind this (it's a demo) — logging in
lets you SELECT a role, but from that point on, the role is baked into a
server-signed token and every write endpoint checks it server-side. The
demo-friendliness is in what happens at login; the enforcement after that
point is real.
"""

import jwt
import time
from functools import wraps
from flask import request, jsonify


ROLE_RANK = {"viewer": 0, "analyst": 1, "admin": 2}


def issue_soc_token(username: str, role: str, secret_key: str, expires_in_seconds: int = 28800) -> str:
    if role not in ROLE_RANK:
        role = "viewer"
    now = int(time.time())
    payload = {"sub": username, "role": role, "iat": now, "exp": now + expires_in_seconds}
    return jwt.encode(payload, secret_key, algorithm="HS256")


def verify_soc_token(token: str, secret_key: str):
    try:
        return jwt.decode(token, secret_key, algorithms=["HS256"])
    except jwt.InvalidTokenError:
        return None


def _extract_token():
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        return auth_header[len("Bearer "):]
    return request.args.get("token") or (request.get_json(silent=True) or {}).get("token")


def require_role(min_role: str, secret_key_getter):
    """
    Decorator factory. secret_key_getter is a zero-arg callable returning
    the app's SECRET_KEY (passed this way so soc/auth.py doesn't need to
    import config.py directly and create a circular import).
    """
    def decorator(view_fn):
        @wraps(view_fn)
        def wrapper(*args, **kwargs):
            token = _extract_token()
            if not token:
                return jsonify({"error": "SOC session required — log in at /soc"}), 401
            payload = verify_soc_token(token, secret_key_getter())
            if not payload:
                return jsonify({"error": "invalid or expired SOC session"}), 401
            role = payload.get("role", "viewer")
            if ROLE_RANK.get(role, 0) < ROLE_RANK.get(min_role, 99):
                return jsonify({"error": f"requires '{min_role}' role or higher; you have '{role}'"}), 403
            request.soc_user = payload.get("sub", "unknown")
            request.soc_role = role
            return view_fn(*args, **kwargs)
        return wrapper
    return decorator
