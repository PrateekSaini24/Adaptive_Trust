"""
soc/ip_lookup.py
-------------------
"Do not depend on paid APIs. If external reputation data is unavailable,
clearly show 'External reputation data unavailable.' Never fabricate
reputation information."

Uses ipapi.co's free tier (HTTPS, no API key required for reasonable
demo/personal volumes) to resolve country/ASN/organization for an IP.
This is a real network call to a real service — it will not work in this
project's own offline build sandbox, and that's fine: the honest-failure
path below IS the correct behavior when reputation data can't be reached,
not a bug to route around.

No "reputation score" is invented here. ipapi.co's free tier gives
geolocation/ASN data, not a malicious/clean verdict — this module reports
exactly that and nothing more. A production system would add a real threat
intel source (e.g. AbuseIPDB, with a free-tier API key the operator
supplies) for an actual reputation verdict; the `reputation` field in the
returned dict stays explicitly "unavailable" until such a source is wired
in, rather than inventing a plausible-looking number.
"""

import json
import urllib.request
import urllib.error


IPAPI_URL = "https://ipapi.co/{ip}/json/"
UNAVAILABLE_MESSAGE = "External reputation data unavailable."


def lookup_ip(ip: str, timeout: float = 4.0) -> dict:
    """
    Returns a dict with whatever real fields could be resolved. Every
    field that couldn't be resolved is explicitly None / the unavailable
    message — never a guess.
    """
    result = {
        "ip": ip,
        "country": None,
        "region": None,
        "city": None,
        "asn": None,
        "organization": None,
        "reputation": UNAVAILABLE_MESSAGE,   # no free, keyless reputation-verdict source exists
        "source": "ipapi.co (free tier)",
        "lookup_succeeded": False,
        "error": None,
    }

    request = urllib.request.Request(
        IPAPI_URL.format(ip=ip), headers={"User-Agent": "AdaptiveTrust-SOC-Demo"}
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        result["error"] = f"{UNAVAILABLE_MESSAGE} ({exc})"
        return result

    if data.get("error"):
        # ipapi.co returns {"error": true, "reason": "..."} for invalid/rate-limited requests
        result["error"] = f"{UNAVAILABLE_MESSAGE} ({data.get('reason', 'lookup failed')})"
        return result

    result.update({
        "country": data.get("country_name"),
        "region": data.get("region"),
        "city": data.get("city"),
        "asn": data.get("asn"),
        "organization": data.get("org"),
        "lookup_succeeded": True,
        "error": None,
    })
    return result
