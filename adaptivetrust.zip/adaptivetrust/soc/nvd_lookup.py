"""
soc/nvd_lookup.py
---------------------
"Use free vulnerability data such as the NVD where practical. Cache
external data locally so the dashboard remains usable if the external
service is unavailable."

Real integration point: NIST's National Vulnerability Database REST API
(https://services.nvd.nist.gov/rest/json/cves/2.0), free, no API key
required for light use (a key raises your rate limit, but isn't
mandatory). fetch_cve() makes that real call and writes a local JSON
cache; get_cve() reads the cache first and only calls out on a miss, so
the Vulnerability Dashboard stays usable even if nvd.nist.gov is
unreachable — exactly what the requirement asks for.

CACHED_SAMPLE_CVES below is a small, honestly-labeled starter set of a
few real, well-known CVEs (correct IDs and CVSS scores, from public
disclosure) so the demo has believable-looking vulnerability data without
requiring a live NVD call on first run. Every entry is tagged
source="cached-sample" so nothing pretends to be a live lookup it isn't.
"""

import json
import os
import time
import urllib.request
import urllib.error


NVD_API_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0?cveId={cve_id}"

# A handful of REAL, publicly disclosed CVEs with their actual CVSS v3
# base scores, used to seed the demo's vulnerability data. Not exhaustive,
# not live-verified in this offline build — clearly labeled as a cached
# sample, not a live NVD response.
CACHED_SAMPLE_CVES = {
    "CVE-2021-44228": {"cvss_score": 10.0, "severity": "critical",
                        "summary": "Apache Log4j2 JNDI features (\"Log4Shell\") allow remote code execution."},
    "CVE-2017-0144": {"cvss_score": 8.1, "severity": "high",
                       "summary": "Windows SMBv1 remote code execution (\"EternalBlue\")."},
    "CVE-2014-0160": {"cvss_score": 7.5, "severity": "high",
                       "summary": "OpenSSL Heartbeat extension out-of-bounds read (\"Heartbleed\")."},
    "CVE-2021-34527": {"cvss_score": 8.8, "severity": "high",
                        "summary": "Windows Print Spooler remote code execution (\"PrintNightmare\")."},
    "CVE-2019-0708": {"cvss_score": 9.8, "severity": "critical",
                       "summary": "Windows Remote Desktop Services remote code execution (\"BlueKeep\")."},
    "CVE-2020-1472": {"cvss_score": 10.0, "severity": "critical",
                       "summary": "Netlogon elevation of privilege (\"Zerologon\")."},
    "CVE-2022-22965": {"cvss_score": 9.8, "severity": "critical",
                        "summary": "Spring Framework remote code execution (\"Spring4Shell\")."},
    "CVE-2018-13379": {"cvss_score": 9.8, "severity": "critical",
                        "summary": "Fortinet FortiOS SSL VPN path traversal allowing credential disclosure."},
}


class NvdCache:
    def __init__(self, cache_path: str):
        self.cache_path = cache_path
        self._cache = self._load()

    def _load(self) -> dict:
        if os.path.exists(self.cache_path):
            try:
                with open(self.cache_path) as f:
                    return json.load(f)
            except (json.JSONDecodeError, OSError):
                pass
        # Seed with the real sample CVEs on first run.
        seeded = {
            cve_id: {**info, "source": "cached-sample", "cached_at": None}
            for cve_id, info in CACHED_SAMPLE_CVES.items()
        }
        self._save_to_disk(seeded)
        return seeded

    def _save_to_disk(self, data=None):
        with open(self.cache_path, "w") as f:
            json.dump(data if data is not None else self._cache, f, indent=2)

    def get(self, cve_id: str):
        return self._cache.get(cve_id)

    def fetch_live(self, cve_id: str, timeout: float = 5.0):
        """
        Real NVD API call. Returns the parsed CVSS score/severity/summary
        on success, or None if the service is unreachable/the CVE isn't
        found — callers should fall back to the cache (or the "unavailable"
        message) rather than crash.
        """
        request = urllib.request.Request(
            NVD_API_URL.format(cve_id=cve_id), headers={"User-Agent": "AdaptiveTrust-SOC-Demo"}
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                data = json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
            return None

        vulnerabilities = data.get("vulnerabilities", [])
        if not vulnerabilities:
            return None

        cve_data = vulnerabilities[0]["cve"]
        metrics = cve_data.get("metrics", {})
        cvss_score, severity = None, None
        for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
            if key in metrics and metrics[key]:
                cvss_data = metrics[key][0]["cvssData"]
                cvss_score = cvss_data.get("baseScore")
                severity = (metrics[key][0].get("baseSeverity") or cvss_data.get("baseSeverity", "")).lower()
                break

        descriptions = cve_data.get("descriptions", [])
        summary = next((d["value"] for d in descriptions if d.get("lang") == "en"), "")

        result = {
            "cvss_score": cvss_score, "severity": severity, "summary": summary,
            "source": "live-nvd", "cached_at": time.time(),
        }
        self._cache[cve_id] = result
        self._save_to_disk()
        return result

    def get_or_fetch(self, cve_id: str, allow_live: bool = True):
        """The main entry point: cache first, live fetch on miss (if
        allowed), and an honest 'unavailable' marker if both fail."""
        cached = self.get(cve_id)
        if cached:
            return cached
        if allow_live:
            live = self.fetch_live(cve_id)
            if live:
                return live
        return {"cvss_score": None, "severity": "unknown",
                "summary": "External vulnerability data unavailable.", "source": "unavailable"}

    def all_cached(self) -> dict:
        return dict(self._cache)
