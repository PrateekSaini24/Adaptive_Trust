"""
soc/store.py
--------------
The data layer for the SOC platform extension. One SQLite database
(soc.db, in Config.DATA_DIR — same pattern as the audit log), one table
per concept the brief asks for: alerts, incidents, hosts, processes, file
integrity events, malware alerts, vulnerabilities, auth events, IOCs,
notifications, and an audit log of analyst actions.

This is intentionally plain: every method is a small, readable SQL
statement, not an ORM. It's meant to be read start to finish, the same
philosophy as the rest of this project.

Everything in here stores REAL structure for DEMO data — the demo
generator (soc/demo_generator.py) is what actually invents the values.
This file doesn't know or care whether a row came from the demo generator
or from a real detection source; it just stores and queries.
"""

import sqlite3
import json
import threading
import uuid
from datetime import datetime, timezone


def _now_iso():
    return datetime.now(timezone.utc).isoformat()


class SocStore:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = threading.Lock()
        self._init_schema()

    def _connect(self):
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self):
        with self._connect() as conn:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS alerts (
                id TEXT PRIMARY KEY,
                timestamp TEXT,
                severity TEXT,
                detection_rule TEXT,
                description TEXT,
                source_ip TEXT,
                destination_ip TEXT,
                source_country TEXT,
                destination_country TEXT,
                host TEXT,
                username TEXT,
                protocol TEXT,
                status TEXT,
                confidence TEXT,
                detection_engine TEXT,
                mitre_tactic TEXT,
                mitre_technique TEXT,
                mitre_technique_id TEXT,
                assigned_analyst TEXT,
                notes TEXT,      -- JSON list of {time, author, text}
                tags TEXT,       -- JSON list of strings
                indicators TEXT  -- JSON list of IOC strings
            );

            CREATE TABLE IF NOT EXISTS incidents (
                id TEXT PRIMARY KEY,
                title TEXT,
                severity TEXT,
                status TEXT,
                created_at TEXT,
                updated_at TEXT,
                assigned_analyst TEXT,
                affected_hosts TEXT,     -- JSON list
                related_alerts TEXT,     -- JSON list of alert ids
                mitre_techniques TEXT,   -- JSON list
                evidence TEXT,           -- JSON list of strings
                notes TEXT,              -- JSON list of {time, author, text}
                timeline TEXT            -- JSON list of {time, text}
            );

            CREATE TABLE IF NOT EXISTS hosts (
                hostname TEXT PRIMARY KEY,
                ip TEXT,
                os TEXT,
                status TEXT,
                cpu REAL,
                ram REAL,
                disk REAL,
                last_seen TEXT,
                logged_in_users TEXT,   -- JSON list
                mac_address TEXT
            );

            CREATE TABLE IF NOT EXISTS processes (
                id TEXT PRIMARY KEY,
                host TEXT,
                pid INTEGER,
                ppid INTEGER,
                name TEXT,
                username TEXT,
                cpu REAL,
                memory REAL,
                exe_path TEXT,
                start_time TEXT,
                network_connections TEXT,  -- JSON list
                suspicious INTEGER,
                suspicious_reason TEXT
            );

            CREATE TABLE IF NOT EXISTS fim_events (
                id TEXT PRIMARY KEY,
                host TEXT,
                file_path TEXT,
                event_type TEXT,
                previous_hash TEXT,
                new_hash TEXT,
                user TEXT,
                timestamp TEXT
            );

            CREATE TABLE IF NOT EXISTS malware_alerts (
                id TEXT PRIMARY KEY,
                alert_id TEXT,
                malware_family TEXT,
                host TEXT,
                file TEXT,
                hash TEXT,
                detection_time TEXT,
                severity TEXT,
                status TEXT,
                detection_source TEXT
            );

            CREATE TABLE IF NOT EXISTS vulnerabilities (
                id TEXT PRIMARY KEY,
                host TEXT,
                cve TEXT,
                cvss_score REAL,
                severity TEXT,
                affected_software TEXT,
                installed_version TEXT,
                fixed_version TEXT,
                first_detected TEXT,
                last_detected TEXT,
                source TEXT
            );

            CREATE TABLE IF NOT EXISTS auth_events (
                id TEXT PRIMARY KEY,
                timestamp TEXT,
                username TEXT,
                source_ip TEXT,
                success INTEGER,
                host TEXT,
                device TEXT,
                country TEXT
            );

            CREATE TABLE IF NOT EXISTS iocs (
                id TEXT PRIMARY KEY,
                ioc_type TEXT,
                value TEXT,
                first_seen TEXT,
                last_seen TEXT,
                threat_level TEXT,
                confidence TEXT,
                related_alerts TEXT,   -- JSON list
                related_hosts TEXT,    -- JSON list
                source TEXT,
                malware_family TEXT,
                threat_actor TEXT
            );

            CREATE TABLE IF NOT EXISTS notifications (
                id TEXT PRIMARY KEY,
                type TEXT,
                message TEXT,
                severity TEXT,
                created_at TEXT,
                read INTEGER
            );

            CREATE TABLE IF NOT EXISTS soc_audit_log (
                id TEXT PRIMARY KEY,
                timestamp TEXT,
                analyst TEXT,
                action TEXT,
                resource TEXT,
                ip TEXT,
                result TEXT
            );

            CREATE TABLE IF NOT EXISTS connections (
                id TEXT PRIMARY KEY,
                timestamp TEXT,
                source_ip TEXT,
                destination_ip TEXT,
                source_port INTEGER,
                destination_port INTEGER,
                protocol TEXT,
                bytes_transferred INTEGER,
                direction TEXT   -- 'inbound' | 'outbound'
            );

            CREATE INDEX IF NOT EXISTS idx_alerts_ts ON alerts(timestamp);
            CREATE INDEX IF NOT EXISTS idx_auth_ts ON auth_events(timestamp);
            CREATE INDEX IF NOT EXISTS idx_conn_ts ON connections(timestamp);
            """)

    # ---- generic helpers ---------------------------------------------------

    def _insert(self, table, row: dict):
        cols = list(row.keys())
        placeholders = ", ".join("?" for _ in cols)
        with self._lock:
            with self._connect() as conn:
                conn.execute(
                    f"INSERT INTO {table} ({', '.join(cols)}) VALUES ({placeholders})",
                    [row[c] for c in cols],
                )

    def _row_to_dict(self, row, json_fields=()):
        d = dict(row)
        for f in json_fields:
            if f in d and d[f]:
                try:
                    d[f] = json.loads(d[f])
                except (json.JSONDecodeError, TypeError):
                    d[f] = []
            elif f in d:
                d[f] = []
        return d

    # ---- alerts --------------------------------------------------------------

    ALERT_JSON_FIELDS = ("notes", "tags", "indicators")

    def add_alert(self, **fields) -> str:
        alert_id = fields.pop("id", None) or f"ALT-{uuid.uuid4().hex[:8].upper()}"
        row = {
            "id": alert_id,
            "timestamp": fields.get("timestamp") or _now_iso(),
            "severity": fields.get("severity", "medium"),
            "detection_rule": fields.get("detection_rule", ""),
            "description": fields.get("description", ""),
            "source_ip": fields.get("source_ip", ""),
            "destination_ip": fields.get("destination_ip", ""),
            "source_country": fields.get("source_country", ""),
            "destination_country": fields.get("destination_country", ""),
            "host": fields.get("host", ""),
            "username": fields.get("username", ""),
            "protocol": fields.get("protocol", ""),
            "status": fields.get("status", "new"),
            "confidence": fields.get("confidence", "medium"),
            "detection_engine": fields.get("detection_engine", "demo-generator"),
            "mitre_tactic": fields.get("mitre_tactic", ""),
            "mitre_technique": fields.get("mitre_technique", ""),
            "mitre_technique_id": fields.get("mitre_technique_id", ""),
            "assigned_analyst": fields.get("assigned_analyst", ""),
            "notes": json.dumps(fields.get("notes", [])),
            "tags": json.dumps(fields.get("tags", [])),
            "indicators": json.dumps(fields.get("indicators", [])),
        }
        self._insert("alerts", row)
        return alert_id

    def get_alert(self, alert_id: str):
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM alerts WHERE id = ?", (alert_id,)).fetchone()
            return self._row_to_dict(row, self.ALERT_JSON_FIELDS) if row else None

    def query_alerts(self, severity=None, status=None, search=None,
                      sort_by="timestamp", sort_dir="desc", page=1, page_size=25):
        where, params = [], []
        if severity:
            where.append("severity = ?"); params.append(severity)
        if status:
            where.append("status = ?"); params.append(status)
        if search:
            where.append("(detection_rule LIKE ? OR source_ip LIKE ? OR destination_ip LIKE ? "
                          "OR host LIKE ? OR username LIKE ? OR id LIKE ?)")
            like = f"%{search}%"
            params += [like] * 6

        where_clause = f"WHERE {' AND '.join(where)}" if where else ""
        sort_col = sort_by if sort_by in (
            "timestamp", "severity", "status", "source_ip", "destination_ip", "host", "username"
        ) else "timestamp"
        sort_dir = "DESC" if sort_dir.lower() != "asc" else "ASC"

        with self._connect() as conn:
            total = conn.execute(f"SELECT COUNT(*) FROM alerts {where_clause}", params).fetchone()[0]
            offset = (max(page, 1) - 1) * page_size
            rows = conn.execute(
                f"SELECT * FROM alerts {where_clause} ORDER BY {sort_col} {sort_dir} LIMIT ? OFFSET ?",
                params + [page_size, offset],
            ).fetchall()
            return {
                "items": [self._row_to_dict(r, self.ALERT_JSON_FIELDS) for r in rows],
                "total": total, "page": page, "page_size": page_size,
            }

    def update_alert(self, alert_id: str, **fields) -> bool:
        allowed = {"status", "severity", "assigned_analyst"}
        set_clauses, params = [], []
        for k, v in fields.items():
            if k in allowed:
                set_clauses.append(f"{k} = ?"); params.append(v)
        if not set_clauses:
            return False
        params.append(alert_id)
        with self._lock:
            with self._connect() as conn:
                cur = conn.execute(f"UPDATE alerts SET {', '.join(set_clauses)} WHERE id = ?", params)
                return cur.rowcount > 0

    def add_alert_note(self, alert_id: str, author: str, text: str) -> bool:
        alert = self.get_alert(alert_id)
        if not alert:
            return False
        notes = alert["notes"] + [{"time": _now_iso(), "author": author, "text": text}]
        with self._lock:
            with self._connect() as conn:
                conn.execute("UPDATE alerts SET notes = ? WHERE id = ?", (json.dumps(notes), alert_id))
        return True

    def add_alert_tags(self, alert_id: str, tags: list) -> bool:
        alert = self.get_alert(alert_id)
        if not alert:
            return False
        merged = sorted(set(alert["tags"]) | set(tags))
        with self._lock:
            with self._connect() as conn:
                conn.execute("UPDATE alerts SET tags = ? WHERE id = ?", (json.dumps(merged), alert_id))
        return True

    def alert_counts(self):
        with self._connect() as conn:
            rows = conn.execute("SELECT severity, COUNT(*) c FROM alerts GROUP BY severity").fetchall()
            by_severity = {r["severity"]: r["c"] for r in rows}
            total = conn.execute("SELECT COUNT(*) FROM alerts").fetchone()[0]
            return {"total": total, "by_severity": by_severity}

    # ---- incidents -------------------------------------------------------------

    INCIDENT_JSON_FIELDS = ("affected_hosts", "related_alerts", "mitre_techniques", "evidence", "notes", "timeline")
    INCIDENT_STATUSES = ["NEW", "TRIAGED", "INVESTIGATING", "CONTAINED", "RESOLVED", "CLOSED"]

    def add_incident(self, **fields) -> str:
        incident_id = fields.pop("id", None) or f"INC-{uuid.uuid4().hex[:8].upper()}"
        now = _now_iso()
        row = {
            "id": incident_id,
            "title": fields.get("title", "Untitled incident"),
            "severity": fields.get("severity", "medium"),
            "status": fields.get("status", "NEW"),
            "created_at": fields.get("created_at") or now,
            "updated_at": now,
            "assigned_analyst": fields.get("assigned_analyst", ""),
            "affected_hosts": json.dumps(fields.get("affected_hosts", [])),
            "related_alerts": json.dumps(fields.get("related_alerts", [])),
            "mitre_techniques": json.dumps(fields.get("mitre_techniques", [])),
            "evidence": json.dumps(fields.get("evidence", [])),
            "notes": json.dumps(fields.get("notes", [])),
            "timeline": json.dumps(fields.get("timeline", [{"time": now, "text": "Incident created"}])),
        }
        self._insert("incidents", row)
        return incident_id

    def get_incident(self, incident_id):
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM incidents WHERE id = ?", (incident_id,)).fetchone()
            return self._row_to_dict(row, self.INCIDENT_JSON_FIELDS) if row else None

    def query_incidents(self, status=None, severity=None, page=1, page_size=25):
        where, params = [], []
        if status:
            where.append("status = ?"); params.append(status)
        if severity:
            where.append("severity = ?"); params.append(severity)
        where_clause = f"WHERE {' AND '.join(where)}" if where else ""
        with self._connect() as conn:
            total = conn.execute(f"SELECT COUNT(*) FROM incidents {where_clause}", params).fetchone()[0]
            offset = (max(page, 1) - 1) * page_size
            rows = conn.execute(
                f"SELECT * FROM incidents {where_clause} ORDER BY updated_at DESC LIMIT ? OFFSET ?",
                params + [page_size, offset],
            ).fetchall()
            return {"items": [self._row_to_dict(r, self.INCIDENT_JSON_FIELDS) for r in rows],
                    "total": total, "page": page, "page_size": page_size}

    def update_incident_status(self, incident_id, new_status, analyst=""):
        if new_status not in self.INCIDENT_STATUSES:
            return False
        incident = self.get_incident(incident_id)
        if not incident:
            return False
        timeline = incident["timeline"] + [{
            "time": _now_iso(),
            "text": f"Status changed to {new_status}" + (f" by {analyst}" if analyst else ""),
        }]
        with self._lock:
            with self._connect() as conn:
                conn.execute(
                    "UPDATE incidents SET status = ?, updated_at = ?, timeline = ? WHERE id = ?",
                    (new_status, _now_iso(), json.dumps(timeline), incident_id),
                )
        return True

    def add_incident_note(self, incident_id, author, text):
        incident = self.get_incident(incident_id)
        if not incident:
            return False
        notes = incident["notes"] + [{"time": _now_iso(), "author": author, "text": text}]
        with self._lock:
            with self._connect() as conn:
                conn.execute("UPDATE incidents SET notes = ?, updated_at = ? WHERE id = ?",
                             (json.dumps(notes), _now_iso(), incident_id))
        return True

    # ---- hosts -------------------------------------------------------------

    def upsert_host(self, hostname, **fields):
        with self._lock:
            with self._connect() as conn:
                existing = conn.execute("SELECT hostname FROM hosts WHERE hostname = ?", (hostname,)).fetchone()
                payload = {
                    "ip": fields.get("ip", ""), "os": fields.get("os", ""),
                    "status": fields.get("status", "online"),
                    "cpu": fields.get("cpu", 0), "ram": fields.get("ram", 0), "disk": fields.get("disk", 0),
                    "last_seen": _now_iso(),
                    "logged_in_users": json.dumps(fields.get("logged_in_users", [])),
                    "mac_address": fields.get("mac_address", ""),
                }
                if existing:
                    conn.execute(
                        "UPDATE hosts SET ip=?, os=?, status=?, cpu=?, ram=?, disk=?, last_seen=?, "
                        "logged_in_users=?, mac_address=? WHERE hostname=?",
                        list(payload.values()) + [hostname],
                    )
                else:
                    conn.execute(
                        "INSERT INTO hosts (hostname, ip, os, status, cpu, ram, disk, last_seen, "
                        "logged_in_users, mac_address) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        [hostname] + list(payload.values()),
                    )

    def list_hosts(self):
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM hosts ORDER BY hostname").fetchall()
            return [self._row_to_dict(r, ("logged_in_users",)) for r in rows]

    def get_host(self, hostname):
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM hosts WHERE hostname = ?", (hostname,)).fetchone()
            return self._row_to_dict(row, ("logged_in_users",)) if row else None

    # ---- processes -------------------------------------------------------------

    def add_process(self, **fields):
        row = {
            "id": f"PROC-{uuid.uuid4().hex[:8]}",
            "host": fields.get("host", ""), "pid": fields.get("pid", 0), "ppid": fields.get("ppid", 0),
            "name": fields.get("name", ""), "username": fields.get("username", ""),
            "cpu": fields.get("cpu", 0), "memory": fields.get("memory", 0),
            "exe_path": fields.get("exe_path", ""), "start_time": fields.get("start_time") or _now_iso(),
            "network_connections": json.dumps(fields.get("network_connections", [])),
            "suspicious": int(bool(fields.get("suspicious", False))),
            "suspicious_reason": fields.get("suspicious_reason", ""),
        }
        self._insert("processes", row)
        return row["id"]

    def list_processes(self, host=None, suspicious_only=False):
        where, params = [], []
        if host:
            where.append("host = ?"); params.append(host)
        if suspicious_only:
            where.append("suspicious = 1")
        where_clause = f"WHERE {' AND '.join(where)}" if where else ""
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM processes {where_clause} ORDER BY start_time DESC LIMIT 200", params
            ).fetchall()
            return [self._row_to_dict(r, ("network_connections",)) for r in rows]

    def clear_processes_for_host(self, host):
        """Demo generator refreshes the process list each cycle rather than
        growing it forever."""
        with self._lock:
            with self._connect() as conn:
                conn.execute("DELETE FROM processes WHERE host = ?", (host,))

    # ---- FIM -------------------------------------------------------------

    def add_fim_event(self, **fields):
        row = {
            "id": f"FIM-{uuid.uuid4().hex[:8]}",
            "host": fields.get("host", ""), "file_path": fields.get("file_path", ""),
            "event_type": fields.get("event_type", "modified"),
            "previous_hash": fields.get("previous_hash", ""), "new_hash": fields.get("new_hash", ""),
            "user": fields.get("user", ""), "timestamp": fields.get("timestamp") or _now_iso(),
        }
        self._insert("fim_events", row)
        return row["id"]

    def list_fim_events(self, host=None, limit=100):
        where, params = "", []
        if host:
            where = "WHERE host = ?"; params.append(host)
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM fim_events {where} ORDER BY timestamp DESC LIMIT ?", params + [limit]
            ).fetchall()
            return [dict(r) for r in rows]

    # ---- malware -------------------------------------------------------------

    def add_malware_alert(self, **fields):
        row = {
            "id": f"MAL-{uuid.uuid4().hex[:8]}", "alert_id": fields.get("alert_id", ""),
            "malware_family": fields.get("malware_family", "Unknown"), "host": fields.get("host", ""),
            "file": fields.get("file", ""), "hash": fields.get("hash", ""),
            "detection_time": fields.get("detection_time") or _now_iso(),
            "severity": fields.get("severity", "high"), "status": fields.get("status", "new"),
            "detection_source": fields.get("detection_source", "demo-generator"),
        }
        self._insert("malware_alerts", row)
        return row["id"]

    def list_malware_alerts(self, limit=100):
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM malware_alerts ORDER BY detection_time DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(r) for r in rows]

    # ---- vulnerabilities -------------------------------------------------------------

    def upsert_vulnerability(self, **fields):
        vid = f"{fields.get('host','')}:{fields.get('cve','')}"
        with self._lock:
            with self._connect() as conn:
                existing = conn.execute("SELECT id FROM vulnerabilities WHERE id = ?", (vid,)).fetchone()
                if existing:
                    conn.execute("UPDATE vulnerabilities SET last_detected = ? WHERE id = ?", (_now_iso(), vid))
                    return vid
                row = {
                    "id": vid, "host": fields.get("host", ""), "cve": fields.get("cve", ""),
                    "cvss_score": fields.get("cvss_score", 0), "severity": fields.get("severity", "medium"),
                    "affected_software": fields.get("affected_software", ""),
                    "installed_version": fields.get("installed_version", ""),
                    "fixed_version": fields.get("fixed_version", ""),
                    "first_detected": _now_iso(), "last_detected": _now_iso(),
                    "source": fields.get("source", "cached-nvd-sample"),
                }
        self._insert("vulnerabilities", row)
        return vid

    def query_vulnerabilities(self, severity=None, host=None, cve=None, page=1, page_size=25):
        where, params = [], []
        if severity: where.append("severity = ?"); params.append(severity)
        if host: where.append("host = ?"); params.append(host)
        if cve: where.append("cve LIKE ?"); params.append(f"%{cve}%")
        where_clause = f"WHERE {' AND '.join(where)}" if where else ""
        with self._connect() as conn:
            total = conn.execute(f"SELECT COUNT(*) FROM vulnerabilities {where_clause}", params).fetchone()[0]
            offset = (max(page, 1) - 1) * page_size
            rows = conn.execute(
                f"SELECT * FROM vulnerabilities {where_clause} ORDER BY cvss_score DESC LIMIT ? OFFSET ?",
                params + [page_size, offset],
            ).fetchall()
            return {"items": [dict(r) for r in rows], "total": total, "page": page, "page_size": page_size}

    # ---- auth events -------------------------------------------------------------

    def add_auth_event(self, **fields):
        row = {
            "id": f"AUTH-{uuid.uuid4().hex[:8]}", "timestamp": fields.get("timestamp") or _now_iso(),
            "username": fields.get("username", ""), "source_ip": fields.get("source_ip", ""),
            "success": int(bool(fields.get("success", False))), "host": fields.get("host", ""),
            "device": fields.get("device", ""), "country": fields.get("country", ""),
        }
        self._insert("auth_events", row)
        return row["id"]

    def list_auth_events(self, limit=500):
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM auth_events ORDER BY timestamp DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(r) for r in rows]

    def auth_stats(self):
        with self._connect() as conn:
            success = conn.execute("SELECT COUNT(*) FROM auth_events WHERE success = 1").fetchone()[0]
            failed = conn.execute("SELECT COUNT(*) FROM auth_events WHERE success = 0").fetchone()[0]
            by_country = conn.execute(
                "SELECT country, COUNT(*) c FROM auth_events GROUP BY country ORDER BY c DESC LIMIT 10"
            ).fetchall()
            by_user = conn.execute(
                "SELECT username, COUNT(*) c FROM auth_events GROUP BY username ORDER BY c DESC LIMIT 10"
            ).fetchall()
            return {
                "successful_logins": success, "failed_logins": failed,
                "by_country": [dict(r) for r in by_country],
                "by_user": [dict(r) for r in by_user],
            }

    # ---- IOCs -------------------------------------------------------------

    def upsert_ioc(self, ioc_type, value, **fields):
        ioc_id = f"{ioc_type}:{value}"
        with self._lock:
            with self._connect() as conn:
                existing = conn.execute("SELECT id, related_alerts, related_hosts FROM iocs WHERE id = ?", (ioc_id,)).fetchone()
                if existing:
                    related_alerts = json.loads(existing["related_alerts"] or "[]")
                    related_hosts = json.loads(existing["related_hosts"] or "[]")
                    if fields.get("related_alert") and fields["related_alert"] not in related_alerts:
                        related_alerts.append(fields["related_alert"])
                    if fields.get("related_host") and fields["related_host"] not in related_hosts:
                        related_hosts.append(fields["related_host"])
                    conn.execute(
                        "UPDATE iocs SET last_seen=?, related_alerts=?, related_hosts=? WHERE id=?",
                        (_now_iso(), json.dumps(related_alerts), json.dumps(related_hosts), ioc_id),
                    )
                    return ioc_id
        row = {
            "id": ioc_id, "ioc_type": ioc_type, "value": value,
            "first_seen": _now_iso(), "last_seen": _now_iso(),
            "threat_level": fields.get("threat_level", "medium"),
            "confidence": fields.get("confidence", "medium"),
            "related_alerts": json.dumps([fields["related_alert"]] if fields.get("related_alert") else []),
            "related_hosts": json.dumps([fields["related_host"]] if fields.get("related_host") else []),
            "source": fields.get("source", "demo-generator"),
            "malware_family": fields.get("malware_family", ""),
            "threat_actor": fields.get("threat_actor", ""),
        }
        self._insert("iocs", row)
        return ioc_id

    def query_iocs(self, ioc_type=None, search=None, page=1, page_size=25):
        where, params = [], []
        if ioc_type: where.append("ioc_type = ?"); params.append(ioc_type)
        if search: where.append("value LIKE ?"); params.append(f"%{search}%")
        where_clause = f"WHERE {' AND '.join(where)}" if where else ""
        with self._connect() as conn:
            total = conn.execute(f"SELECT COUNT(*) FROM iocs {where_clause}", params).fetchone()[0]
            offset = (max(page, 1) - 1) * page_size
            rows = conn.execute(
                f"SELECT * FROM iocs {where_clause} ORDER BY last_seen DESC LIMIT ? OFFSET ?",
                params + [page_size, offset],
            ).fetchall()
            return {"items": [self._row_to_dict(r, ("related_alerts", "related_hosts")) for r in rows],
                    "total": total, "page": page, "page_size": page_size}

    # ---- notifications -------------------------------------------------------------

    def add_notification(self, notif_type, message, severity="medium"):
        row = {
            "id": f"NOTIF-{uuid.uuid4().hex[:8]}", "type": notif_type, "message": message,
            "severity": severity, "created_at": _now_iso(), "read": 0,
        }
        self._insert("notifications", row)
        return row["id"]

    def list_notifications(self, unread_only=False, limit=50):
        where = "WHERE read = 0" if unread_only else ""
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM notifications {where} ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(r) for r in rows]

    def mark_notification_read(self, notif_id):
        with self._lock:
            with self._connect() as conn:
                conn.execute("UPDATE notifications SET read = 1 WHERE id = ?", (notif_id,))

    # ---- SOC audit log -------------------------------------------------------------

    def log_action(self, analyst, action, resource, ip="", result="success"):
        row = {
            "id": f"AUD-{uuid.uuid4().hex[:8]}", "timestamp": _now_iso(), "analyst": analyst,
            "action": action, "resource": resource, "ip": ip, "result": result,
        }
        self._insert("soc_audit_log", row)
        return row["id"]

    def list_audit_log(self, limit=200):
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM soc_audit_log ORDER BY timestamp DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(r) for r in rows]

    # ---- network connections -------------------------------------------------------------

    def add_connection(self, **fields):
        row = {
            "id": f"CONN-{uuid.uuid4().hex[:8]}", "timestamp": fields.get("timestamp") or _now_iso(),
            "source_ip": fields.get("source_ip", ""), "destination_ip": fields.get("destination_ip", ""),
            "source_port": fields.get("source_port", 0), "destination_port": fields.get("destination_port", 0),
            "protocol": fields.get("protocol", "TCP"), "bytes_transferred": fields.get("bytes_transferred", 0),
            "direction": fields.get("direction", "inbound"),
        }
        self._insert("connections", row)

    def network_stats(self):
        with self._connect() as conn:
            total_bytes = conn.execute("SELECT COALESCE(SUM(bytes_transferred),0) FROM connections").fetchone()[0]
            inbound = conn.execute("SELECT COALESCE(SUM(bytes_transferred),0) FROM connections WHERE direction='inbound'").fetchone()[0]
            outbound = conn.execute("SELECT COALESCE(SUM(bytes_transferred),0) FROM connections WHERE direction='outbound'").fetchone()[0]
            conn_count = conn.execute("SELECT COUNT(*) FROM connections").fetchone()[0]
            top_src = conn.execute(
                "SELECT source_ip, COUNT(*) c FROM connections GROUP BY source_ip ORDER BY c DESC LIMIT 10"
            ).fetchall()
            top_dst = conn.execute(
                "SELECT destination_ip, COUNT(*) c FROM connections GROUP BY destination_ip ORDER BY c DESC LIMIT 10"
            ).fetchall()
            top_ports = conn.execute(
                "SELECT destination_port, COUNT(*) c FROM connections GROUP BY destination_port ORDER BY c DESC LIMIT 10"
            ).fetchall()
            by_protocol = conn.execute(
                "SELECT protocol, COUNT(*) c FROM connections GROUP BY protocol ORDER BY c DESC"
            ).fetchall()
            return {
                "total_bytes": total_bytes, "inbound_bytes": inbound, "outbound_bytes": outbound,
                "connection_count": conn_count,
                "top_source_ips": [dict(r) for r in top_src],
                "top_destination_ips": [dict(r) for r in top_dst],
                "top_ports": [dict(r) for r in top_ports],
                "by_protocol": [dict(r) for r in by_protocol],
            }

    def recent_connections(self, limit=50):
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM connections ORDER BY timestamp DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(r) for r in rows]
