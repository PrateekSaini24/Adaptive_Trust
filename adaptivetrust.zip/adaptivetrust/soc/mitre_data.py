"""
soc/mitre_data.py
--------------------
"Use the public MITRE ATT&CK knowledge base."

This is real reference data - the 14 actual MITRE ATT&CK Enterprise
tactics, in their real kill-chain order, and a representative subset of
real techniques under each (correct technique IDs and names, drawn from
the public ATT&CK matrix at https://attack.mitre.org). It is NOT the full
matrix (that's several hundred techniques) - it's enough to power a
realistic MITRE dashboard and to tag demo alerts with genuine technique
IDs instead of invented ones.

If you want the complete, always-current matrix, MITRE publishes it as
STIX/JSON at https://github.com/mitre-attack/attack-stix-data - that's
the real integration point for a production version of this page; this
file is the offline-friendly seed so the demo works without a network
call.
"""

TACTICS = [
    {"id": "TA0043", "name": "Reconnaissance"},
    {"id": "TA0042", "name": "Resource Development"},
    {"id": "TA0001", "name": "Initial Access"},
    {"id": "TA0002", "name": "Execution"},
    {"id": "TA0003", "name": "Persistence"},
    {"id": "TA0004", "name": "Privilege Escalation"},
    {"id": "TA0005", "name": "Defense Evasion"},
    {"id": "TA0006", "name": "Credential Access"},
    {"id": "TA0007", "name": "Discovery"},
    {"id": "TA0008", "name": "Lateral Movement"},
    {"id": "TA0009", "name": "Collection"},
    {"id": "TA0011", "name": "Command and Control"},
    {"id": "TA0010", "name": "Exfiltration"},
    {"id": "TA0040", "name": "Impact"},
]

TECHNIQUES = [
    {"id": "T1595", "name": "Active Scanning", "tactic": "Reconnaissance",
     "description": "Adversaries scan victim infrastructure to gather information for targeting."},
    {"id": "T1590", "name": "Gather Victim Network Information", "tactic": "Reconnaissance",
     "description": "Adversaries gather information about the victim's networks before attacking."},
    {"id": "T1583", "name": "Acquire Infrastructure", "tactic": "Resource Development",
     "description": "Adversaries buy, lease, or rent infrastructure for use in operations."},
    {"id": "T1566", "name": "Phishing", "tactic": "Initial Access",
     "description": "Adversaries send phishing messages to gain access to victim systems."},
    {"id": "T1190", "name": "Exploit Public-Facing Application", "tactic": "Initial Access",
     "description": "Adversaries exploit a weakness in an internet-facing host or application."},
    {"id": "T1078", "name": "Valid Accounts", "tactic": "Initial Access",
     "description": "Adversaries obtain and abuse credentials of existing accounts."},
    {"id": "T1059", "name": "Command and Scripting Interpreter", "tactic": "Execution",
     "description": "Adversaries abuse command and script interpreters to execute commands."},
    {"id": "T1053", "name": "Scheduled Task/Job", "tactic": "Execution",
     "description": "Adversaries abuse task scheduling to execute code at a set time."},
    {"id": "T1547", "name": "Boot or Logon Autostart Execution", "tactic": "Persistence",
     "description": "Adversaries configure system settings to run a program during boot/logon."},
    {"id": "T1136", "name": "Create Account", "tactic": "Persistence",
     "description": "Adversaries create an account to maintain access."},
    {"id": "T1068", "name": "Exploitation for Privilege Escalation", "tactic": "Privilege Escalation",
     "description": "Adversaries exploit software vulnerabilities to elevate privileges."},
    {"id": "T1055", "name": "Process Injection", "tactic": "Defense Evasion",
     "description": "Adversaries inject code into processes to evade defenses."},
    {"id": "T1070", "name": "Indicator Removal", "tactic": "Defense Evasion",
     "description": "Adversaries delete or alter artifacts to remove evidence."},
    {"id": "T1027", "name": "Obfuscated Files or Information", "tactic": "Defense Evasion",
     "description": "Adversaries obfuscate content to make it harder to discover or analyze."},
    {"id": "T1110", "name": "Brute Force", "tactic": "Credential Access",
     "description": "Adversaries use brute force techniques to gain access to accounts.",
     "sub_techniques": [
         {"id": "T1110.001", "name": "Password Guessing"},
         {"id": "T1110.003", "name": "Password Spraying"},
     ]},
    {"id": "T1003", "name": "OS Credential Dumping", "tactic": "Credential Access",
     "description": "Adversaries dump credentials to obtain account login information."},
    {"id": "T1087", "name": "Account Discovery", "tactic": "Discovery",
     "description": "Adversaries enumerate accounts on a system or in a domain."},
    {"id": "T1018", "name": "Remote System Discovery", "tactic": "Discovery",
     "description": "Adversaries get a listing of other systems by IP, hostname, or other identifier."},
    {"id": "T1021", "name": "Remote Services", "tactic": "Lateral Movement",
     "description": "Adversaries use valid accounts to log into a service for lateral movement."},
    {"id": "T1560", "name": "Archive Collected Data", "tactic": "Collection",
     "description": "Adversaries compress and/or encrypt data prior to exfiltration."},
    {"id": "T1071", "name": "Application Layer Protocol", "tactic": "Command and Control",
     "description": "Adversaries use common application layer protocols to blend in with normal traffic."},
    {"id": "T1105", "name": "Ingress Tool Transfer", "tactic": "Command and Control",
     "description": "Adversaries transfer tools from an external system into a compromised environment."},
    {"id": "T1041", "name": "Exfiltration Over C2 Channel", "tactic": "Exfiltration",
     "description": "Adversaries steal data over an existing command and control channel."},
    {"id": "T1486", "name": "Data Encrypted for Impact", "tactic": "Impact",
     "description": "Adversaries encrypt data to interrupt availability (ransomware)."},
    {"id": "T1489", "name": "Service Stop", "tactic": "Impact",
     "description": "Adversaries stop or disable services to render them unavailable."},
]


def technique_by_id(technique_id: str):
    for t in TECHNIQUES:
        if t["id"] == technique_id:
            return t
        for sub in t.get("sub_techniques", []):
            if sub["id"] == technique_id:
                merged = dict(t)
                merged.update(sub)
                merged["parent_technique_id"] = t["id"]
                return merged
    return None


def techniques_for_tactic(tactic_name: str):
    return [t for t in TECHNIQUES if t["tactic"] == tactic_name]
