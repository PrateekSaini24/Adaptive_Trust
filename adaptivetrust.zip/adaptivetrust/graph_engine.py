"""
graph_engine.py
----------------
Chapter 7.1: "A graph database like Neo4j stores data natively as nodes
(User, Device, Service) and relationships between them (LOGGED_IN_FROM,
ACCESSED, OWNED_BY)."

Two fully working backends, chosen by an environment variable:

  USE_REAL_NEO4J=false (default) -> an in-memory graph, zero setup
  USE_REAL_NEO4J=true            -> a real Neo4j server over the official
                                     neo4j Python driver, running real
                                     Cypher queries

To actually use real Neo4j:
    pip install neo4j
    docker compose up neo4j
    export USE_REAL_NEO4J=true
    export NEO4J_URI=bolt://localhost:7687
    export NEO4J_USER=neo4j
    export NEO4J_PASSWORD=password     # matches docker-compose.yml
    python app.py

Every method has both an in-memory implementation and, right next to it,
the real Cypher query that does the same job — read them side by side and
the mapping from "toy graph" to "real graph database" is exactly one
query each.
"""

import os
import threading


class IdentityGraph:
    def __init__(self, use_real_neo4j: bool = None, uri: str = None,
                 user: str = None, password: str = None):
        self.use_real_neo4j = (
            use_real_neo4j if use_real_neo4j is not None
            else os.environ.get("USE_REAL_NEO4J", "false").lower() == "true"
        )
        self._lock = threading.RLock()

        if self.use_real_neo4j:
            # --- REAL BACKEND ---
            from neo4j import GraphDatabase  # pip install neo4j
            uri = uri or os.environ.get("NEO4J_URI", "bolt://localhost:7687")
            user = user or os.environ.get("NEO4J_USER", "neo4j")
            password = password or os.environ.get("NEO4J_PASSWORD", "password")
            self._driver = GraphDatabase.driver(uri, auth=(user, password))
            self._driver.verify_connectivity()  # fail fast if unreachable
            self._init_constraints()
        else:
            # nodes: {node_id: {"type": "User"|"Device"|"Service", **properties}}
            self._nodes = {}
            # relationships: list of (from_id, relationship_type, to_id)
            self._relationships = []

    def _init_constraints(self):
        """Real Neo4j setup: make sure node IDs are unique, same as you'd
        run once when standing up the real database."""
        with self._driver.session() as session:
            session.run(
                "CREATE CONSTRAINT node_id_unique IF NOT EXISTS "
                "FOR (n:Entity) REQUIRE n.id IS UNIQUE"
            )

    def close(self):
        if self.use_real_neo4j:
            self._driver.close()

    # ---- writing to the graph -------------------------------------------------

    def add_node(self, node_id: str, node_type: str, **properties) -> None:
        if self.use_real_neo4j:
            with self._driver.session() as session:
                session.run(
                    # Every node gets a generic :Entity label (for the
                    # uniqueness constraint above) plus its specific type
                    # label, e.g. :User or :Device.
                    f"MERGE (n:Entity:{node_type} {{id: $id}}) SET n += $props",
                    id=node_id, props=properties,
                )
            return
        with self._lock:
            self._nodes[node_id] = {"type": node_type, **properties}

    def add_relationship(self, from_id: str, relationship: str, to_id: str) -> None:
        if self.use_real_neo4j:
            with self._driver.session() as session:
                session.run(
                    "MATCH (a:Entity {id: $from_id}), (b:Entity {id: $to_id}) "
                    f"MERGE (a)-[:{relationship}]->(b)",
                    from_id=from_id, to_id=to_id,
                )
            return
        with self._lock:
            self._relationships.append((from_id, relationship, to_id))

    def flag_account_compromised(self, user_id: str) -> None:
        """Marks a node the way Chapter 7.1's example describes: 'an account
        that was later flagged as compromised'."""
        if self.use_real_neo4j:
            with self._driver.session() as session:
                session.run(
                    "MATCH (u:Entity {id: $user_id}) SET u.compromised = true",
                    user_id=user_id,
                )
            return
        with self._lock:
            if user_id in self._nodes:
                self._nodes[user_id]["compromised"] = True

    # ---- reading from the graph -------------------------------------------------

    def device_used_by(self, device_id: str):
        """All user_ids this device has ever logged in as."""
        if self.use_real_neo4j:
            with self._driver.session() as session:
                result = session.run(
                    "MATCH (u:Entity)-[:LOGGED_IN_FROM]->(d:Entity {id: $device_id}) "
                    "RETURN u.id AS user_id",
                    device_id=device_id,
                )
                return [record["user_id"] for record in result]
        with self._lock:
            return [
                frm for (frm, rel, to) in self._relationships
                if rel == "LOGGED_IN_FROM" and to == device_id
            ]

    def relationship_risk_signal(self, user_id: str, device_id: str) -> tuple:
        """
        Chapter 7.1's example query: "has this device ever been used by an
        account that was later flagged as compromised." Also implements the
        lateral-movement idea from Chapter 3.3 (limitation 9): if this
        device has EVER logged in as a *different* user, that's a
        relationship anomaly worth risk points.

        Returns (points, reason) — this becomes the 9th risk factor.
        """
        if self.use_real_neo4j:
            with self._driver.session() as session:
                # Real Cypher: find every user who has logged in from this
                # device, and whether the current user or a compromised
                # account is among them.
                result = session.run(
                    "MATCH (u:Entity)-[:LOGGED_IN_FROM]->(d:Entity {id: $device_id}) "
                    "RETURN u.id AS user_id, coalesce(u.compromised, false) AS compromised",
                    device_id=device_id,
                )
                rows = [(r["user_id"], r["compromised"]) for r in result]

            known_users = [u for (u, _) in rows]
            if not known_users:
                return 5, "device has no history in the identity graph"
            if user_id in known_users:
                this_user_compromised = any(u == user_id and c for (u, c) in rows)
                if this_user_compromised:
                    return 8, f"identity '{user_id}' has a compromise flag on record"
                return 0, "known device/identity pair with clean history"
            return 5, (
                f"device previously associated with different identities "
                f"({', '.join(known_users)}), not '{user_id}'"
            )

        with self._lock:
            known_users_of_device = self.device_used_by(device_id)

            if not known_users_of_device:
                return 5, "device has no history in the identity graph"

            if user_id in known_users_of_device:
                if self._nodes.get(user_id, {}).get("compromised"):
                    return 8, f"identity '{user_id}' has a compromise flag on record"
                return 0, "known device/identity pair with clean history"

            return 5, (
                f"device previously associated with different identities "
                f"({', '.join(known_users_of_device)}), not '{user_id}'"
            )

    def find_lateral_movement_paths(self, user_id: str, max_hops: int = 2):
        """
        Chapter 3.3 limitation 9 / Chapter 20.3's animated graph reveal:
        walk outward from a user through relationships and report anything
        within `max_hops`.
        """
        if self.use_real_neo4j:
            with self._driver.session() as session:
                # Real Cypher variable-length path query — this is exactly
                # the kind of query Chapter 7.1 says is "naturally fast and
                # simple to express" in a graph database vs. repeated SQL
                # joins.
                result = session.run(
                    f"MATCH path = (start:Entity {{id: $user_id}})-[*1..{max_hops}]-(other:Entity) "
                    "RETURN [n IN nodes(path) | n.id] AS node_ids, "
                    "       [r IN relationships(path) | type(r)] AS rel_types",
                    user_id=user_id,
                )
                paths = []
                for record in result:
                    node_ids = record["node_ids"]
                    rel_types = record["rel_types"]
                    paths.append({
                        "path": node_ids,
                        "via": rel_types[-1] if rel_types else "UNKNOWN",
                    })
                return paths

        with self._lock:
            visited = {user_id}
            frontier = [(user_id, [user_id])]
            paths = []

            for _ in range(max_hops):
                next_frontier = []
                for node_id, path_so_far in frontier:
                    for (frm, rel, to) in self._relationships:
                        neighbor = None
                        if frm == node_id:
                            neighbor = to
                        elif to == node_id:
                            neighbor = frm
                        if neighbor and neighbor not in visited:
                            visited.add(neighbor)
                            new_path = path_so_far + [neighbor]
                            paths.append({"path": new_path, "via": rel})
                            next_frontier.append((neighbor, new_path))
                frontier = next_frontier

            return paths

    def clear_all(self) -> None:
        """Used by the chaos-test demo endpoint to simulate the graph
        database being wiped/unreachable."""
        if self.use_real_neo4j:
            with self._driver.session() as session:
                session.run("MATCH (n) DETACH DELETE n")
            return
        with self._lock:
            self._nodes.clear()
            self._relationships.clear()
