"""
models.py
---------
Plain, boring data classes. No behavior, just clearly-named fields, so it's
obvious what data flows between the Auth -> Risk -> Policy -> Decision steps
described in Chapter 11.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class AccessRequest:
    """One incoming request to /access/decide. This is 'the input' described
    throughout Chapters 8-11."""
    user_id: str
    device_id: str
    location: str
    resource: str
    api_calls_last_minute: float = 0.0
    hour_of_day: int = 12
    token_valid: bool = True
    network_ip: str = "0.0.0.0"

    # Chapter 8, Factor 1 (Identity Confidence) needs more than "is the
    # token valid" — the design doc names "token age" and "presence of a
    # valid second factor" specifically. Defaults match a normal, secure
    # login (freshly issued token, MFA already done) so the Chapter 4/9
    # worked-example numbers don't change unless a caller deliberately
    # sets these — which the new /login simulate screen lets you do.
    mfa_verified: bool = True
    token_age_minutes: float = 0.0

    # Chapter 8, Factor 7 (Session Anomaly): which resource this request is
    # for, used to detect a resource-access pattern that suddenly changes
    # partway through a session. See session_tracker.py.
    session_id: str = ""

    # Chapter 8, Factor 2: "matches known device fingerprints" — not just
    # whether the device ID has been seen before, but whether ITS
    # fingerprint (a hash of browser/OS/hardware characteristics) matches
    # what we've seen for that device ID in the past. Optional — if not
    # provided, device trust falls back to ID-only matching.
    device_fingerprint: str = ""

    # Chapter 8, Factor 8: a client-side SHA-1 hash of the password (see
    # credential_check.py for why it's a hash, not the plaintext) to check
    # against the real Have I Been Pwned k-anonymity API. Optional — if not
    # provided, credential exposure falls back to the seeded baseline flag.
    password_hash_sha1: str = ""

    # Filled in automatically, not by the caller.
    request_id: str = field(default="")
    received_at: str = field(default="")

    def __post_init__(self):
        if not self.received_at:
            self.received_at = datetime.now(timezone.utc).isoformat()
        if not self.session_id:
            # Simplified "session" for this stateless demo API: same
            # user+device is treated as one continuing session. A real
            # deployment would use an actual session/cookie identifier.
            self.session_id = f"{self.user_id}:{self.device_id}"


@dataclass
class FactorScore:
    """One line of the Chapter 9 worked-example table: a single risk factor,
    its point value, and a short human-readable reason."""
    name: str
    points: int
    max_points: int
    reason: str


@dataclass
class RiskResult:
    """Chapter 8/9: the full risk score plus the per-factor breakdown that
    the explainability layer (Chapter 7.4) reads from."""
    total_score: int
    factors: list  # list[FactorScore]
    graph_signal_points: int
    graph_signal_reason: str


@dataclass
class Decision:
    """Chapter 10: the final outcome of a request."""
    outcome: str  # "ALLOW" | "VERIFY" | "RESTRICT" | "DENY"
    risk_score: int
    explanation: str
    request: AccessRequest = None
    from_cache: bool = False
