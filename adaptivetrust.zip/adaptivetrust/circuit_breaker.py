"""
circuit_breaker.py
--------------------
Chapter 15.1: a circuit breaker wraps a call to an external dependency and
tracks its recent success/failure rate. Three states:

  Closed     -> normal operation, calls pass straight through
  Open       -> too many recent failures; stop calling, use a fallback instead
  Half-Open  -> after a cooldown, let a few test calls through to see if
                the dependency has recovered

This is used by app.py to wrap the Neo4j graph lookup and the Redis cache
lookup, so a dependency going down (as demonstrated live in the Chapter
20.4 "signature moment") degrades the system gracefully instead of hanging
or crashing.
"""

import time


class CircuitOpenError(Exception):
    """Raised when the breaker is open and refuses to call the dependency."""
    pass


class CircuitBreaker:
    def __init__(self, name: str, failure_threshold: int, cooldown_seconds: int):
        self.name = name
        self.failure_threshold = failure_threshold
        self.cooldown_seconds = cooldown_seconds

        self.state = "closed"       # "closed" | "open" | "half_open"
        self.failure_count = 0
        self.opened_at = None

    def _maybe_recover(self):
        """If we're open and the cooldown has passed, try a half-open test."""
        if self.state == "open" and self.opened_at is not None:
            if time.time() - self.opened_at >= self.cooldown_seconds:
                self.state = "half_open"

    def call(self, dependency_fn, fallback_fn):
        """
        Calls dependency_fn(). If the breaker is open, skips straight to
        fallback_fn() instead (this is the "return a fallback response, such
        as a cached value" behavior from Chapter 15.1).
        """
        self._maybe_recover()

        if self.state == "open":
            return fallback_fn()

        try:
            result = dependency_fn()
        except Exception:
            self._record_failure()
            return fallback_fn()
        else:
            self._record_success()
            return result

    def _record_failure(self):
        self.failure_count += 1
        if self.state == "half_open":
            # The test call during recovery failed — reopen immediately.
            self.state = "open"
            self.opened_at = time.time()
        elif self.failure_count >= self.failure_threshold:
            self.state = "open"
            self.opened_at = time.time()

    def _record_success(self):
        self.failure_count = 0
        self.state = "closed"
        self.opened_at = None

    def force_open(self):
        """Used by the demo's /demo/chaos endpoint to simulate a dependency
        dying, without waiting for real failures to accumulate."""
        self.state = "open"
        self.opened_at = time.time()
        self.failure_count = self.failure_threshold

    def force_closed(self):
        """Used by the demo's /demo/recover endpoint."""
        self.state = "closed"
        self.opened_at = None
        self.failure_count = 0

    def status(self) -> dict:
        return {
            "name": self.name,
            "state": self.state,
            "failure_count": self.failure_count,
        }
