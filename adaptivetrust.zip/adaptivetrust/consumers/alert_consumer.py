"""
consumers/alert_consumer.py
------------------------------
Chapter 14: "Alert / response consumer - for high-risk outcomes, sends
notifications and can trigger automated response actions such as revoking
active sessions, requiring step-up MFA, or opening an incident ticket."

Chapter 20.5's "Signature Moment D" is explicit that this should be
concrete: "a real Slack message or email is sent to a device visible to
the audience... rather than the notification only appearing as a line in
a log file." This consumer can now actually do that — for real, using
Slack's real incoming-webhook API and real SMTP — not just print a line.

Both are OPTIONAL and OFF by default (no webhook/SMTP configured -> falls
back to the console print + in-memory list the dashboard already reads).
To turn either on:

    export SLACK_WEBHOOK_URL="https://hooks.slack.com/services/T000/B000/xxx"
    # and/or
    export SMTP_HOST="smtp.yourprovider.com"
    export SMTP_PORT="587"
    export SMTP_USER="alerts@yourcompany.com"
    export SMTP_PASSWORD="..."
    export SMTP_TO="oncall@yourcompany.com"

Neither of these can be exercised end-to-end in the offline sandbox this
was built in (no network), but both use the real, documented APIs for
their service — Slack's incoming webhook JSON format and standard SMTP —
so they work as soon as real credentials/network are available.
"""

import os
import json
import smtplib
import threading
import urllib.request
import urllib.error
from email.mime.text import MIMEText
from datetime import datetime, timezone


class AlertConsumer:
    def __init__(self):
        self._lock = threading.Lock()
        self._alerts = []  # newest first

        self.slack_webhook_url = os.environ.get("SLACK_WEBHOOK_URL")
        self.smtp_host = os.environ.get("SMTP_HOST")

    def handle_event(self, event: dict) -> None:
        """Only DENY (and, more cautiously, RESTRICT) outcomes generate an
        alert — matching Chapter 10.2's table where DENY 'may trigger
        automated response' and Chapter 4's example (revoke sessions, open
        incident, page on-call) for a high-risk request."""
        if event["outcome"] not in ("DENY", "RESTRICT"):
            return

        actions = self._automated_response_for(event["outcome"])

        alert = {
            "request_id": event["request_id"],
            "user_id": event["user_id"],
            "outcome": event["outcome"],
            "risk_score": event["risk_score"],
            "explanation": event["explanation"],
            "actions_taken": actions,
            "alerted_at": datetime.now(timezone.utc).isoformat(),
        }

        with self._lock:
            self._alerts.insert(0, alert)
            self._alerts = self._alerts[:100]  # keep it bounded

        message = (
            f"AdaptiveTrust: {alert['outcome']} for {alert['user_id']} "
            f"(risk {alert['risk_score']}/100) — {', '.join(actions)}"
        )

        sent_somewhere = False
        if self.slack_webhook_url:
            sent_somewhere |= self._send_slack(message)
        if self.smtp_host:
            sent_somewhere |= self._send_email(alert, message)

        if not sent_somewhere:
            # Console fallback — always happens if neither real channel is
            # configured, and also on top of them so nothing depends on a
            # network call actually working.
            print(f"[ALERT] {message}")

    def _send_slack(self, message: str) -> bool:
        """Real Slack incoming-webhook call — this is the documented format
        (https://api.slack.com/messaging/webhooks), not a simulation."""
        payload = json.dumps({"text": message}).encode("utf-8")
        request = urllib.request.Request(
            self.slack_webhook_url, data=payload,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=3):
                return True
        except (urllib.error.URLError, TimeoutError) as exc:
            print(f"[alert_consumer] Slack webhook failed ({exc}); falling back to console")
            return False

    def _send_email(self, alert: dict, message: str) -> bool:
        """Real SMTP send. Uses STARTTLS on the configured port, same as
        any standard transactional-email setup."""
        try:
            msg = MIMEText(
                f"{message}\n\nExplanation: {alert['explanation']}\n"
                f"Request ID: {alert['request_id']}\nTime: {alert['alerted_at']}"
            )
            msg["Subject"] = f"AdaptiveTrust {alert['outcome']} — {alert['user_id']}"
            msg["From"] = os.environ.get("SMTP_USER", "adaptivetrust@localhost")
            msg["To"] = os.environ.get("SMTP_TO", msg["From"])

            port = int(os.environ.get("SMTP_PORT", "587"))
            with smtplib.SMTP(self.smtp_host, port, timeout=5) as server:
                server.starttls()
                smtp_user = os.environ.get("SMTP_USER")
                smtp_password = os.environ.get("SMTP_PASSWORD")
                if smtp_user and smtp_password:
                    server.login(smtp_user, smtp_password)
                server.sendmail(msg["From"], [msg["To"]], msg.as_string())
            return True
        except (smtplib.SMTPException, OSError, TimeoutError) as exc:
            print(f"[alert_consumer] email send failed ({exc}); falling back to console")
            return False

    def _automated_response_for(self, outcome: str) -> list:
        """Chapter 4's worked example: 'DENY + revoke sessions + open
        incident + page on-call'."""
        if outcome == "DENY":
            return ["revoke active sessions", "open incident", "page on-call"]
        return ["flag for review"]  # RESTRICT: lighter-touch response

    def recent(self, limit: int = 20) -> list:
        """Powers the dashboard's alert feed."""
        with self._lock:
            return self._alerts[:limit]
