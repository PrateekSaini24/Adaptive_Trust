"""
consumers/analytics_consumer.py
----------------------------------
Chapter 14: "Analytics / ML consumer - collects data that can later be used
to train a machine-learning risk model, once enough real data exists."

This build stops before Chapter 25 (the actual ML model), so this consumer
does the one thing Chapter 14 asks of it at this stage: collect data. It
just counts events and keeps a rolling tally per factor, so you can see
what a future feature-store table (Chapter 25.3) would be built from.
"""

import threading
from collections import Counter


class AnalyticsConsumer:
    def __init__(self):
        self._lock = threading.Lock()
        self.total_events = 0
        self.outcome_counts = Counter()
        self.factor_trigger_counts = Counter()  # how often each factor contributed points

    def handle_event(self, event: dict) -> None:
        with self._lock:
            self.total_events += 1
            self.outcome_counts[event["outcome"]] += 1
            for factor_name in event.get("nonzero_factors", []):
                self.factor_trigger_counts[factor_name] += 1

    def snapshot(self) -> dict:
        """Powers a small stats panel on the dashboard, and is the kind of
        summary Chapter 25.1 says you'd eventually feed into an unsupervised
        anomaly model once there's enough of it."""
        with self._lock:
            return {
                "total_events": self.total_events,
                "outcome_counts": dict(self.outcome_counts),
                "factor_trigger_counts": dict(self.factor_trigger_counts),
            }
