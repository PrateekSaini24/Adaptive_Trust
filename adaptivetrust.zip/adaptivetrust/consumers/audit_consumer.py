"""
consumers/audit_consumer.py
------------------------------
Chapter 14: "Audit consumer - writes a permanent, queryable record to
PostgreSQL. This is the system of record for compliance and later
investigation."

Chapter 18: "Audit immutability: audit records in PostgreSQL are meant to
be append-only from the application's perspective - the application writes
new records but should not have a code path that updates or deletes past
audit entries."

Two fully working backends:

  USE_REAL_POSTGRES=false (default) -> a local SQLite file, zero setup
  USE_REAL_POSTGRES=true            -> a real PostgreSQL server via psycopg2

To actually use real PostgreSQL:
    pip install psycopg2-binary
    docker compose up postgres
    export USE_REAL_POSTGRES=true
    export POSTGRES_DSN="dbname=adaptivetrust user=adaptivetrust password=adaptivetrust host=localhost"
    python app.py

Append-only is enforced the same way in both backends: request_id is a
PRIMARY KEY, every write is a plain INSERT (never UPDATE/REPLACE), and
there is deliberately no update_record()/delete_record() method anywhere
in this class — Chapter 18 is explicit that the *application* should have
no code path that can rewrite history, so we simply don't write one.
"""

import sqlite3
import os
import threading


class AuditConsumer:
    def __init__(self, db_path: str = "audit_log.db", use_real_postgres: bool = None):
        self.use_real_postgres = (
            use_real_postgres if use_real_postgres is not None
            else os.environ.get("USE_REAL_POSTGRES", "false").lower() == "true"
        )
        self._lock = threading.Lock()

        if self.use_real_postgres:
            # --- REAL BACKEND ---
            import psycopg2  # pip install psycopg2-binary
            self._psycopg2 = psycopg2
            self.dsn = os.environ.get(
                "POSTGRES_DSN",
                "dbname=adaptivetrust user=adaptivetrust password=adaptivetrust host=localhost",
            )
            self._init_table_postgres()
        else:
            self.db_path = db_path
            self._init_table_sqlite()

    # ---- setup --------------------------------------------------------------

    def _init_table_sqlite(self):
        with self._connect_sqlite() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS audit_log (
                    request_id TEXT PRIMARY KEY,
                    user_id TEXT,
                    device_id TEXT,
                    location TEXT,
                    resource TEXT,
                    risk_score INTEGER,
                    outcome TEXT,
                    explanation TEXT,
                    received_at TEXT
                )
            """)

    def _init_table_postgres(self):
        with self._connect_postgres() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS audit_log (
                        request_id TEXT PRIMARY KEY,
                        user_id TEXT,
                        device_id TEXT,
                        location TEXT,
                        resource TEXT,
                        risk_score INTEGER,
                        outcome TEXT,
                        explanation TEXT,
                        received_at TEXT
                    )
                """)
            conn.commit()

    def _connect_sqlite(self):
        return sqlite3.connect(self.db_path)

    def _connect_postgres(self):
        return self._psycopg2.connect(self.dsn)

    # ---- writing (append-only: INSERT only, never UPDATE/DELETE) -----------

    def handle_event(self, event: dict) -> None:
        """This is the handler_fn passed to event_bus.subscribe(). One
        `event` = one finalized decision, published by app.py right after
        Step 7 of the request flow (Chapter 11)."""
        row = (
            event["request_id"], event["user_id"], event["device_id"],
            event["location"], event["resource"], event["risk_score"],
            event["outcome"], event["explanation"], event["received_at"],
        )

        with self._lock:
            if self.use_real_postgres:
                with self._connect_postgres() as conn:
                    with conn.cursor() as cur:
                        try:
                            cur.execute(
                                """INSERT INTO audit_log
                                   (request_id, user_id, device_id, location, resource,
                                    risk_score, outcome, explanation, received_at)
                                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                                row,
                            )
                            conn.commit()
                        except self._psycopg2.errors.UniqueViolation:
                            # Same request_id seen twice (e.g. a retried
                            # publish) — append-only means we skip it rather
                            # than overwrite the original record.
                            conn.rollback()
            else:
                with self._connect_sqlite() as conn:
                    try:
                        conn.execute(
                            """INSERT INTO audit_log
                               (request_id, user_id, device_id, location, resource,
                                risk_score, outcome, explanation, received_at)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                            row,
                        )
                    except sqlite3.IntegrityError:
                        pass  # duplicate request_id -> skip, don't overwrite history

    # ---- reading -------------------------------------------------------------

    def recent(self, limit: int = 50) -> list:
        """Powers the dashboard's live request feed (Chapter 20.1)."""
        if self.use_real_postgres:
            with self._connect_postgres() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT request_id, user_id, device_id, location, resource, "
                        "risk_score, outcome, explanation, received_at "
                        "FROM audit_log ORDER BY received_at DESC LIMIT %s", (limit,)
                    )
                    cols = [d[0] for d in cur.description]
                    return [dict(zip(cols, row)) for row in cur.fetchall()]

        with self._connect_sqlite() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM audit_log ORDER BY received_at DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(row) for row in rows]

    def summary_counts(self) -> dict:
        """Powers Chapter 20.8's 'auto-generated compliance report' idea:
        N requests evaluated, M denied, etc."""
        if self.use_real_postgres:
            with self._connect_postgres() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT COUNT(*) FROM audit_log")
                    total = cur.fetchone()[0]
                    cur.execute("SELECT outcome, COUNT(*) FROM audit_log GROUP BY outcome")
                    by_outcome = {row[0]: row[1] for row in cur.fetchall()}
            return {"total": total, "by_outcome": by_outcome}

        with self._connect_sqlite() as conn:
            total = conn.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0]
            by_outcome = {}
            for row in conn.execute("SELECT outcome, COUNT(*) FROM audit_log GROUP BY outcome"):
                by_outcome[row[0]] = row[1]
            return {"total": total, "by_outcome": by_outcome}
