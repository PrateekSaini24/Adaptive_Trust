"""
compliance_report.py
-----------------------
Chapter 20.8: "the dashboard includes a button that generates a PDF summary
directly from the audit log - for example, 'last 30 days: N requests
evaluated, M denied, K incidents created.' ... its value is in showing
that the audit trail... is a genuinely usable artifact for compliance
reporting, not simply rows sitting in a database that nobody can act on."

This generates a real PDF (using reportlab) straight from the audit log
table in consumers/audit_consumer.py — not a mock-up.
"""

from datetime import datetime, timezone
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle


def generate_compliance_pdf(audit_consumer, alert_consumer, output_path: str) -> str:
    """Builds a PDF at output_path summarizing recent access decisions and
    incidents, and returns that path."""
    doc = SimpleDocTemplate(output_path, pagesize=letter,
                             topMargin=0.6 * inch, bottomMargin=0.6 * inch)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleCustom", parent=styles["Title"], fontSize=18)
    story = []

    story.append(Paragraph("AdaptiveTrust — Compliance Report", title_style))
    story.append(Paragraph(
        f"Generated {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
        styles["Normal"],
    ))
    story.append(Spacer(1, 0.25 * inch))

    # --- Summary section --------------------------------------------------
    summary = audit_consumer.summary_counts()
    story.append(Paragraph("Summary", styles["Heading2"]))
    summary_rows = [["Metric", "Value"], ["Total requests evaluated", str(summary["total"])]]
    for outcome, count in summary["by_outcome"].items():
        summary_rows.append([f"  {outcome}", str(count)])

    summary_table = Table(summary_rows, colWidths=[3.5 * inch, 2 * inch])
    summary_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#223047")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f4f6fa")]),
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 0.3 * inch))

    # --- Incidents section (Chapter 14: alert/response consumer output) ---
    story.append(Paragraph("Incidents (DENY / RESTRICT outcomes)", styles["Heading2"]))
    alerts = alert_consumer.recent(limit=50)
    if not alerts:
        story.append(Paragraph("No incidents recorded in this session.", styles["Normal"]))
    else:
        incident_rows = [["User", "Outcome", "Risk", "Automated response"]]
        for a in alerts:
            incident_rows.append([
                a["user_id"], a["outcome"], str(a["risk_score"]), ", ".join(a["actions_taken"])
            ])
        incident_table = Table(incident_rows, colWidths=[1.3 * inch, 1 * inch, 0.7 * inch, 2.5 * inch])
        incident_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#223047")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f4f6fa")]),
        ]))
        story.append(incident_table)

    story.append(Spacer(1, 0.3 * inch))

    # --- Recent decisions (raw audit trail excerpt) -------------------------
    story.append(Paragraph("Recent decisions (most recent 20)", styles["Heading2"]))
    recent = audit_consumer.recent(limit=20)
    if not recent:
        story.append(Paragraph("No decisions recorded in this session.", styles["Normal"]))
    else:
        decision_rows = [["Time (UTC)", "User", "Resource", "Score", "Outcome"]]
        for r in recent:
            decision_rows.append([
                (r["received_at"] or "")[:19].replace("T", " "),
                r["user_id"], r["resource"], str(r["risk_score"]), r["outcome"],
            ])
        decision_table = Table(decision_rows, colWidths=[1.6 * inch, 1 * inch, 1.6 * inch, 0.6 * inch, 0.9 * inch])
        decision_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#223047")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f4f6fa")]),
        ]))
        story.append(decision_table)

    story.append(Spacer(1, 0.35 * inch))
    story.append(Paragraph(
        "Generated by a reference build of the AdaptiveTrust design document. "
        "Not a production compliance artifact.",
        ParagraphStyle("footnote", parent=styles["Normal"], fontSize=7, textColor=colors.grey),
    ))

    doc.build(story)
    return output_path
