"""
supply_chain/sign_artifact.py
--------------------------------
Chapter 7.5: "image signing (using a tool such as cosign) cryptographically
proves that a container image was built by the expected pipeline and has
not been altered since."

Real cosign signs a container image using public-key cryptography (it
generates a keypair, signs the image digest, and pushes the signature to
the registry alongside the image). Reproducing real cosign here would mean
re-implementing container registry protocols, which is out of scope for a
demo.

What this script demonstrates instead is the actual *concept* end to end,
on a file instead of an image: generate a keypair once, sign a file's
hash with the private key, and verify that signature with the public key.
Anyone tampering with the file after signing will fail verification —
which is the property Chapter 7.5 actually cares about. Swapping this for
real cosign later is an infrastructure change (sign a container digest
instead of a file), not a conceptual one.

Usage:
    python supply_chain/sign_artifact.py generate-keys
    python supply_chain/sign_artifact.py sign <file>
    python supply_chain/sign_artifact.py verify <file> <signature_file>
"""

import hashlib
import sys
import os

from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.exceptions import InvalidSignature


KEY_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "keys")
PRIVATE_KEY_PATH = os.path.join(KEY_DIR, "signing_key.pem")
PUBLIC_KEY_PATH = os.path.join(KEY_DIR, "signing_key.pub")


def generate_keys() -> None:
    os.makedirs(KEY_DIR, exist_ok=True)
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    with open(PRIVATE_KEY_PATH, "wb") as f:
        f.write(private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        ))

    with open(PUBLIC_KEY_PATH, "wb") as f:
        f.write(private_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ))

    print(f"Generated keypair:\n  private: {PRIVATE_KEY_PATH}\n  public:  {PUBLIC_KEY_PATH}")
    print("In a real pipeline, the private key never leaves the CI signer.")


def sign_file(file_path: str) -> str:
    with open(PRIVATE_KEY_PATH, "rb") as f:
        private_key = serialization.load_pem_private_key(f.read(), password=None)

    digest = hashlib.sha256(open(file_path, "rb").read()).digest()
    signature = private_key.sign(
        digest,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
        hashes.SHA256(),
    )

    sig_path = file_path + ".sig"
    with open(sig_path, "wb") as f:
        f.write(signature)

    print(f"Signed {file_path} -> {sig_path}")
    return sig_path


def verify_file(file_path: str, sig_path: str) -> bool:
    with open(PUBLIC_KEY_PATH, "rb") as f:
        public_key = serialization.load_pem_public_key(f.read())

    digest = hashlib.sha256(open(file_path, "rb").read()).digest()
    signature = open(sig_path, "rb").read()

    try:
        public_key.verify(
            signature,
            digest,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256(),
        )
        print(f"VALID: {file_path} matches signature {sig_path} — not tampered with.")
        return True
    except InvalidSignature:
        print(f"INVALID: {file_path} does NOT match signature {sig_path} — "
              f"file was modified after signing, or wrong key.")
        return False


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    command = sys.argv[1]
    if command == "generate-keys":
        generate_keys()
    elif command == "sign":
        sign_file(sys.argv[2])
    elif command == "verify":
        verify_file(sys.argv[2], sys.argv[3])
    else:
        print(__doc__)
        sys.exit(1)
