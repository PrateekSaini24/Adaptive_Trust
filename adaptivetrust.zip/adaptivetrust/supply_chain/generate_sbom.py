"""
supply_chain/generate_sbom.py
--------------------------------
Chapter 7.5: "a Software Bill of Materials (SBOM) (generated with a tool
such as syft) lists every package and library in the final image, so that
if a vulnerability is disclosed in some dependency, it is immediately
clear whether the system is affected."

Real deployments run `syft` against the built container image. This script
does the same job for this Python project specifically: it reads
requirements.txt and the currently-installed package versions, and writes
out a JSON SBOM in a CycloneDX-like shape (the same shape syft itself
produces), so "is my system affected by CVE-XYZ in package X" becomes a
grep instead of a manual audit.

Run it with:  python supply_chain/generate_sbom.py
"""

import json
import os
import sys
from datetime import datetime, timezone
from importlib import metadata


def read_requirements(requirements_path: str) -> list:
    packages = []
    with open(requirements_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            packages.append(line)
    return packages


def resolve_installed_version(requirement_line: str) -> str:
    """requirement_line looks like 'Flask==3.0.3' — we report the version
    actually installed right now, not just the pinned one, since that's
    the whole point of an SBOM: what's *really* in the running system."""
    package_name = requirement_line.split("==")[0].strip()
    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        return "NOT INSTALLED"


def generate_sbom(requirements_path: str, output_path: str) -> dict:
    components = []
    for line in read_requirements(requirements_path):
        name = line.split("==")[0].strip()
        installed_version = resolve_installed_version(line)
        components.append({
            "type": "library",
            "name": name,
            "version": installed_version,
            "pinned_in_requirements": line,
        })

    sbom = {
        "bomFormat": "AdaptiveTrust-SBOM",  # a real tool would say "CycloneDX"
        "specVersion": "1.0-simplified",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "component_count": len(components),
        "components": components,
    }

    with open(output_path, "w") as f:
        json.dump(sbom, f, indent=2)

    return sbom


if __name__ == "__main__":
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    requirements_path = os.path.join(here, "requirements.txt")
    output_path = os.path.join(here, "sbom.json")

    sbom = generate_sbom(requirements_path, output_path)
    print(f"Wrote SBOM with {sbom['component_count']} components to {output_path}")
    for component in sbom["components"]:
        print(f"  - {component['name']} {component['version']}")
