"""
risk_engine.py
---------------
Chapter 8: "The risk engine is the heart of AdaptiveTrust. Instead of a
single yes/no check, it combines eight signals into one 0-100 score."

Each `score_*` method below is one factor. They're all written the same
simple shape on purpose: look at the request, look at what we know about
this user's normal behavior (their "baseline"), return (points, reason).

The point values and thresholds match the worked example in Chapter 9 —
this is explicitly called out in the design doc as "a starting point... to
illustrate the mechanism, not final, validated values." Feel free to tune
them once you have real traffic data, exactly as Chapter 9 suggests.

score_factors_only() and combine_with_graph() are split apart (rather than
one big score() method) specifically so app.py can time the 8-factor
scoring and the Neo4j graph query as two SEPARATE stages — Chapter 20.6's
"subway map" names them as distinct stations (Auth -> Risk Engine -> Neo4j
-> Policy Engine -> Decision), so the timing needs to actually separate
them, not just report one merged number. score() below is kept as a
convenience wrapper that does both, for callers (like the tests) that
don't care about the distinction.
"""

from models import FactorScore, RiskResult
from graph_engine import IdentityGraph
from session_tracker import SessionTracker
import geo
import credential_check


# Max points per factor, from the Chapter 9 table.
MAX_POINTS = {
    "identity_confidence": 10,
    "device_trust": 25,
    "location_anomaly": 20,
    "behavior_velocity": 20,
    "time_of_day": 10,
    "network_reputation": 10,
    "session_anomaly": 10,
    "credential_exposure": 10,
}


class RiskEngine:
    def __init__(self, graph: IdentityGraph, user_baselines: dict, session_tracker: SessionTracker = None,
                 known_vpn_ips: set = None, known_bad_ips: set = None):
        """
        user_baselines looks like:
            {
                "alice": {
                    "usual_location": "Bangalore",
                    "usual_hours": (9, 17),           # 9am-5pm
                    "usual_devices": {"alice-laptop"},
                    "device_fingerprints": {"alice-laptop": "fp_abc123"},
                    "avg_calls_per_minute": 2,
                    "leaked_credential": False,
                }
            }
        This is the "typical location/hours/velocity" data Chapter 8 assumes
        exists for every factor. In a real deployment this would be computed
        from historical logs, not hard-coded.

        known_vpn_ips / known_bad_ips feed the Network Reputation factor
        (Chapter 27.7's 3-tier mitigation). These are stored on the engine
        at construction time — an earlier version of score_network_reputation
        accepted them as optional PER-CALL arguments, but nothing actually
        passed them at the call site, so every request silently fell back
        to the empty-set defaults and the VPN/known-bad tiers never
        actually fired. Fixed by wiring them in once, here.
        """
        self.graph = graph
        self.user_baselines = user_baselines
        self.session_tracker = session_tracker or SessionTracker()
        self.known_vpn_ips = known_vpn_ips or set()
        self.known_bad_ips = known_bad_ips or set()

    def _baseline_for(self, user_id: str) -> dict:
        # Chapter 24.1 item 2: cold start — a brand-new user has no baseline.
        # We return a clearly-marked "unknown" baseline instead of crashing,
        # and the individual factor methods treat "unknown" as elevated risk.
        return self.user_baselines.get(user_id, {"unknown_user": True})

    # ---- the 8 factors ----------------------------------------------------

    def score_identity_confidence(self, request) -> FactorScore:
        """
        Chapter 8, Factor 1: "How strongly the request's claimed identity is
        verified (e.g. JWT validity, token age, presence of a valid second
        factor)."
        """
        max_pts = MAX_POINTS["identity_confidence"]
        if not request.token_valid:
            # In practice an invalid token would be rejected before this
            # point (Chapter 18: "a request with an invalid token never
            # reaches the risk engine"), but scoring it defensively is cheap.
            return FactorScore("identity_confidence", max_pts, max_pts, "token failed validation")

        points = 0
        reasons = []

        # Token age: a token that's still valid but was issued a long time
        # ago is a slightly weaker signal than one issued moments ago — a
        # long-lived token sitting in a replayed request is exactly the
        # "session hijacked after a successful login" scenario Chapter 2
        # warns about.
        if request.token_age_minutes > 30:
            points += 6
            reasons.append(f"token issued {request.token_age_minutes:.0f} min ago")
        elif request.token_age_minutes > 5:
            points += 2
            reasons.append(f"token is {request.token_age_minutes:.0f} min old")

        # Second factor: no MFA on record is a real gap in identity
        # confidence, independent of whether the token itself is valid.
        if not request.mfa_verified:
            points += 4
            reasons.append("no second factor (MFA) confirmed for this session")

        points = min(points, max_pts)
        reason = "; ".join(reasons) if reasons else "valid token, fresh, MFA confirmed"
        return FactorScore("identity_confidence", points, max_pts, reason)

    def score_device_trust(self, request) -> FactorScore:
        """
        Chapter 8, Factor 2: "Whether the device has been seen before for
        this identity, AND whether it matches known device fingerprints."
        Two separate checks — an earlier draft only did the first one.
        """
        max_pts = MAX_POINTS["device_trust"]
        baseline = self._baseline_for(request.user_id)

        if baseline.get("unknown_user"):
            # Chapter 24.1 item 2's Cold Start Policy: unknown identity gets
            # a fixed moderate penalty, not a free pass.
            return FactorScore("device_trust", 15, max_pts, "unknown identity — cold start penalty")

        known_devices = baseline.get("usual_devices", set())
        if request.device_id not in known_devices:
            return FactorScore("device_trust", max_pts, max_pts, "unrecognized device")

        # Device ID is known — now check the fingerprint, if either side
        # provided one. A device ID claiming to be a known device but
        # presenting a DIFFERENT fingerprint than we've seen for it before
        # is a real signal (device ID spoofing, or a different physical
        # device somehow reusing an old identifier) — worse than an
        # honestly-unrecognized device, because it's actively misleading.
        known_fingerprints = baseline.get("device_fingerprints", {})
        expected_fingerprint = known_fingerprints.get(request.device_id)

        if not request.device_fingerprint or not expected_fingerprint:
            return FactorScore("device_trust", 0, max_pts, "known device (fingerprint not checked)")

        if request.device_fingerprint == expected_fingerprint:
            return FactorScore("device_trust", 0, max_pts, "known device, fingerprint matches")

        # Fingerprint mismatch on a "known" device ID — treat as worse than
        # a plain unrecognized device.
        return FactorScore("device_trust", max_pts, max_pts,
                            "device ID recognized but its fingerprint does NOT match "
                            "what we've seen before — possible spoofed device ID")

    def score_location_anomaly(self, request) -> FactorScore:
        """
        Chapter 8, Factor 3: "How FAR the request's apparent location is
        from the identity's typical locations." Uses real geographic
        distance (geo.py) when both cities are in our reference table,
        scaled into bands; falls back to a same/different check for
        unrecognized city names instead of crashing.
        """
        max_pts = MAX_POINTS["location_anomaly"]
        baseline = self._baseline_for(request.user_id)

        usual_location = baseline.get("usual_location")
        if usual_location is None:
            return FactorScore("location_anomaly", 10, max_pts, "no location history yet")

        if request.location.strip().lower() == usual_location.strip().lower():
            return FactorScore("location_anomaly", 0, max_pts, "usual location")

        distance_km = geo.distance_between_cities_km(request.location, usual_location)

        if distance_km is None:
            # City not in our small reference table — fall back to the
            # simple different-city check rather than pretending we know
            # the distance.
            return FactorScore("location_anomaly", max_pts, max_pts,
                                f"new location ({request.location}) — distance unknown, treated as anomalous")

        # Real distance bands. A ~50km move (different part of the same
        # metro area) is barely worth flagging; an intercontinental jump is
        # maximally anomalous. These thresholds are illustrative starting
        # points, exactly like Chapter 9's own weights.
        if distance_km < 80:
            points = 3
        elif distance_km < 1500:
            points = 12
        else:
            points = max_pts

        return FactorScore("location_anomaly", points, max_pts,
                            f"{distance_km:.0f} km from usual location ({usual_location})")

    def score_behavior_velocity(self, request) -> FactorScore:
        max_pts = MAX_POINTS["behavior_velocity"]
        baseline = self._baseline_for(request.user_id)
        avg = baseline.get("avg_calls_per_minute", 2)

        if avg <= 0:
            avg = 2  # avoid divide-by-zero; treat as the generic default baseline

        ratio = request.api_calls_last_minute / avg

        if ratio <= 2:
            return FactorScore("behavior_velocity", 1, max_pts, "near-baseline request rate")
        if ratio <= 10:
            points = int(max_pts * 0.5)
            return FactorScore("behavior_velocity", points, max_pts, f"{ratio:.0f}x normal rate")
        # Way outside baseline — matches Chapter 4's "500 calls/minute" example.
        return FactorScore("behavior_velocity", max_pts, max_pts, f"{ratio:.0f}x normal rate")

    def score_time_of_day(self, request) -> FactorScore:
        max_pts = MAX_POINTS["time_of_day"]
        baseline = self._baseline_for(request.user_id)
        usual_hours = baseline.get("usual_hours")

        if usual_hours is None:
            return FactorScore("time_of_day", 4, max_pts, "no time-of-day history yet")

        start, end = usual_hours
        if start <= request.hour_of_day < end:
            return FactorScore("time_of_day", 0, max_pts, "within usual hours")
        return FactorScore("time_of_day", 8, max_pts, f"outside usual hours ({request.hour_of_day}:00)")

    def score_network_reputation(self, request) -> FactorScore:
        """
        3-tier version of Chapter 27.7's mitigation: known corporate VPN =
        no penalty, unfamiliar network = small penalty, known-bad network =
        large penalty. Reads the VPN/bad-IP sets given to this engine at
        construction time (see __init__) rather than per-call arguments.
        """
        max_pts = MAX_POINTS["network_reputation"]

        if request.network_ip in self.known_bad_ips:
            return FactorScore("network_reputation", max_pts, max_pts, "IP on known-bad list")
        if request.network_ip in self.known_vpn_ips:
            return FactorScore("network_reputation", 0, max_pts, "known corporate network")
        return FactorScore("network_reputation", 4, max_pts, "unfamiliar (but not known-bad) network")

    def score_session_anomaly(self, request) -> FactorScore:
        """
        Chapter 8, Factor 7: "Signals within the current session itself -
        for example, a sudden change in behavior partway through an
        otherwise-normal session." Backed by session_tracker.py's real
        per-session resource history instead of just checking whether the
        identity is brand-new.

        Note: this only SCORES against history — it does not record the
        current request. Recording happens once, after the full score is
        final (see combine_with_graph() below), so a factor can't see its
        own current request as if it were already history.
        """
        max_pts = MAX_POINTS["session_anomaly"]
        points, reason = self.session_tracker.anomaly_score(
            request.session_id, request.resource, max_pts
        )
        return FactorScore("session_anomaly", points, max_pts, reason)

    def score_credential_exposure(self, request) -> FactorScore:
        """
        Chapter 8, Factor 8: "Whether the credentials involved appear in
        known leaked-credential datasets." If the caller sent a real
        client-hashed password (see credential_check.py), this does a real
        Have I Been Pwned k-anonymity lookup. Otherwise it falls back to
        the seeded demo baseline flag (used by the worked-example users who
        don't go through the /login form's real password field).
        """
        max_pts = MAX_POINTS["credential_exposure"]

        if request.password_hash_sha1:
            try:
                is_pwned, breach_count = credential_check.check_pwned_by_hash(request.password_hash_sha1)
            except credential_check.CredentialCheckUnavailable as exc:
                # A network failure is NOT the same as "checked and clean" —
                # say so explicitly rather than silently scoring 0.
                return FactorScore("credential_exposure", 0, max_pts,
                                    f"could not reach breach-check API ({exc}); not scored")
            if is_pwned:
                return FactorScore("credential_exposure", max_pts, max_pts,
                                    f"password found in {breach_count:,} known breach records (HIBP)")
            return FactorScore("credential_exposure", 0, max_pts, "not found in HIBP's known-breach dataset")

        baseline = self._baseline_for(request.user_id)
        if baseline.get("leaked_credential"):
            return FactorScore("credential_exposure", max_pts, max_pts, "credential found in a known leak")
        return FactorScore("credential_exposure", 0, max_pts, "not found in known leaks")

    # ---- putting it all together -------------------------------------------

    def score_factors_only(self, request) -> list:
        """
        Chapter 11, Step 3: "The Risk Engine computes the 8-factor score."
        Deliberately does NOT touch the graph — see combine_with_graph()
        for Step 4, kept as a separate call so app.py can time them
        separately for the Chapter 20.6 subway map.
        """
        return [
            self.score_identity_confidence(request),
            self.score_device_trust(request),
            self.score_location_anomaly(request),
            self.score_behavior_velocity(request),
            self.score_time_of_day(request),
            self.score_network_reputation(request),
            self.score_session_anomaly(request),
            self.score_credential_exposure(request),
        ]

    def combine_with_graph(self, factors: list, graph_points: int, graph_reason: str, request) -> RiskResult:
        """
        Combines the 8-factor result (Step 3) with the graph signal (Step
        4, Chapter 7.1) into the final RiskResult, and records this
        request into the session's history for next time.
        """
        total = sum(f.points for f in factors) + graph_points
        total = min(total, 100)  # Chapter 9: "Total (capped at 100)"

        # Record this request into the session's history AFTER scoring —
        # otherwise score_session_anomaly() would be comparing the current
        # request against itself.
        self.session_tracker.record(request.session_id, request.resource)

        return RiskResult(
            total_score=total,
            factors=factors,
            graph_signal_points=graph_points,
            graph_signal_reason=graph_reason,
        )

    def score(self, request) -> RiskResult:
        """Convenience wrapper: runs Step 3 and Step 4 back to back and
        combines them. Used by tests and anything that doesn't need the
        two stages timed separately."""
        factors = self.score_factors_only(request)
        graph_points, graph_reason = self.graph.relationship_risk_signal(
            request.user_id, request.device_id
        )
        return self.combine_with_graph(factors, graph_points, graph_reason, request)
