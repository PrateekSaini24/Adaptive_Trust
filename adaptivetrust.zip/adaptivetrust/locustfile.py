"""
locustfile.py
---------------
Chapter 16.3: "Locust is used to simulate many concurrent users and
measure the system's real throughput and latency under load. This is the
only source of truth for the performance numbers discussed in Chapter 15
- they are not assumed or estimated in advance."

Chapter 17's targets (10,000+ req/sec, P99 < 200ms) are explicitly marked
"target, not yet validated" in the design doc — this is Step 29 of the
roadmap, the thing that would actually validate them.

This file isn't run as part of the normal demo (Locust is a separate tool
you run against a running instance of the app). To use it:

    pip install locust
    python app.py                        # in one terminal
    locust -f locustfile.py --host http://localhost:5000   # in another

Then open http://localhost:8089 to set concurrent-user count and watch
real throughput/latency numbers accumulate — exactly what Chapter 16.3
and Chapter 17 call for.
"""

import random
from locust import HttpUser, task, between


# A realistic-ish mix of normal and anomalous traffic, so the load test
# also exercises every branch of the risk engine, not just the cheap
# ALLOW path.
NORMAL_REQUESTS = [
    {"user_id": "alice", "device_id": "alice-laptop", "location": "Bangalore",
     "resource": "internal-dashboard", "api_calls_last_minute": 2, "hour_of_day": 10},
    {"user_id": "bob", "device_id": "bob-desktop", "location": "London",
     "resource": "internal-dashboard", "api_calls_last_minute": 4, "hour_of_day": 11},
]

ANOMALOUS_REQUESTS = [
    {"user_id": "alice", "device_id": "unknown-device", "location": "Tokyo",
     "resource": "pii-database", "api_calls_last_minute": 500, "hour_of_day": 3},
    {"user_id": "mallory", "device_id": "mallory-laptop", "location": "New York",
     "resource": "pii-database", "api_calls_last_minute": 20, "hour_of_day": 14},
]


class AdaptiveTrustUser(HttpUser):
    # Chapter 4's "typical" user isn't hammering the endpoint nonstop —
    # a short wait between requests makes the load profile more realistic.
    wait_time = between(0.1, 1.0)

    @task(8)
    def normal_request(self):
        payload = random.choice(NORMAL_REQUESTS)
        self.client.post("/access/decide", json=payload, name="/access/decide [normal]")

    @task(2)
    def anomalous_request(self):
        payload = random.choice(ANOMALOUS_REQUESTS)
        self.client.post("/access/decide", json=payload, name="/access/decide [anomalous]")

    @task(1)
    def health_check(self):
        self.client.get("/health")
