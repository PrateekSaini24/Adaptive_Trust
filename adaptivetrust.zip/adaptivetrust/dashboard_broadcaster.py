"""
dashboard_broadcaster.py
---------------------------
Chapter 20.1 asks for a "live" dashboard, but the original build just
polled every 2 seconds — that's "frequently refreshed," not actually live.
This gives the dashboard real push: Server-Sent Events (SSE), so a new
decision appears the instant it happens instead of up to 2 seconds late.

This is also, not coincidentally, exactly the problem Chapter 28.4
describes: "The Chapter 20 dashboard needs a live, push-based feed of
decisions as they happen... With multiple replicas, a dashboard client
connected to one pod has no way to see an event processed by a different
pod." That chapter's own proposed fix is: "Use the existing Redis layer as
a pub/sub channel: any pod publishes a decision event to a shared channel
the moment it is made, and every dashboard-serving pod subscribes and
forwards to its connected clients." That's implemented for real here,
not just described — when USE_REAL_REDIS is on, this literally uses
Redis pub/sub; otherwise it falls back to in-memory fan-out, which is
correct for a single-process demo and wrong (by design, honestly labeled)
for multiple replicas, exactly as Chapter 28.4 says.
"""

import os
import json
import queue
import threading


DASHBOARD_CHANNEL = "adaptivetrust:dashboard"


class DashboardBroadcaster:
    def __init__(self, cache=None):
        # Reuse the app's existing Cache wrapper's real-vs-fallback
        # decision (Chapter 28.4: "the existing Redis layer") instead of
        # inventing a separate connection.
        self._use_real_redis = bool(cache and getattr(cache, "use_real_redis", False))
        self._lock = threading.Lock()
        self._subscriber_queues = []  # in-memory fallback: one queue per connected browser

        if self._use_real_redis:
            self._redis = cache._redis  # the same real redis-py client cache.py already opened

    def publish(self, event: dict) -> None:
        payload = json.dumps(event)
        if self._use_real_redis:
            self._redis.publish(DASHBOARD_CHANNEL, payload)
            return
        with self._lock:
            for q in self._subscriber_queues:
                q.put(payload)

    def subscribe_stream(self):
        """
        A generator yielding SSE-formatted strings. app.py wraps this in a
        Flask Response with mimetype text/event-stream. One generator
        instance per connected browser tab.
        """
        if self._use_real_redis:
            pubsub = self._redis.pubsub()
            pubsub.subscribe(DASHBOARD_CHANNEL)
            try:
                for message in pubsub.listen():
                    if message["type"] != "message":
                        continue
                    yield f"data: {message['data']}\n\n"
            finally:
                pubsub.close()
            return

        q = queue.Queue()
        with self._lock:
            self._subscriber_queues.append(q)
        try:
            while True:
                payload = q.get()
                yield f"data: {payload}\n\n"
        finally:
            with self._lock:
                if q in self._subscriber_queues:
                    self._subscriber_queues.remove(q)

    def subscriber_count(self) -> int:
        """Real count for in-memory mode; Redis pub/sub doesn't expose
        subscriber count the same way, so this is best-effort."""
        if self._use_real_redis:
            return -1  # not tracked in real mode — see docstring above
        with self._lock:
            return len(self._subscriber_queues)
