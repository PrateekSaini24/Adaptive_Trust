"""
tests/test_integration.py
----------------------------
Chapter 16.2: "The full request flow (auth to risk to policy to decision)
is tested... verifying that the pieces work correctly together."

Uses Flask's test client, so no real server needs to be running. Requests
go through the REAL JWT flow (Chapter 18) via /auth/token, except where a
test explicitly uses the skip_auth testing bypass to check a specific
edge case.
"""

import sys
import os
import importlib
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest


@pytest.fixture
def client(tmp_path, monkeypatch):
    """
    Gives each test its own throwaway audit database AND a fully fresh
    app (cache, graph, session tracker, everything) — not just a chdir
    trick. Config.DATA_DIR is a fixed, cwd-independent absolute path (see
    config.py's comment on why), which is correct for the real running
    app but means the OLD "just chdir before import" isolation trick no
    longer isolates anything, since the path no longer depends on cwd.
    Patching DATA_DIR itself, then reloading app.py so it re-reads that
    patched value at module-level, is what actually isolates each test.
    """
    import config as config_module
    monkeypatch.setattr(config_module.Config, "DATA_DIR", str(tmp_path))

    import app as app_module
    importlib.reload(app_module)
    app_module.app.testing = True
    return app_module.app.test_client()


def get_token(client, user_id):
    res = client.post("/auth/token", json={"user_id": user_id})
    return res.get_json()["token"]


def test_health_endpoint(client):
    res = client.get("/health")
    assert res.status_code == 200
    assert res.get_json()["status"] == "ok"


def test_metrics_endpoint_returns_prometheus_text(client):
    res = client.get("/metrics")
    assert res.status_code == 200
    assert "adaptivetrust_requests_total" in res.get_data(as_text=True)


def test_request_without_token_is_rejected(client):
    res = client.post("/access/decide", json={
        "device_id": "x", "location": "x", "resource": "x",
    })
    assert res.status_code == 401


def test_normal_request_is_allowed_with_real_token(client):
    token = get_token(client, "alice")
    res = client.post("/access/decide", json={
        "token": token, "device_id": "alice-laptop", "location": "Bangalore",
        "resource": "internal-dashboard", "api_calls_last_minute": 2, "hour_of_day": 10,
    })
    data = res.get_json()
    assert res.status_code == 200
    assert data["outcome"] == "ALLOW"
    assert data["user_id"] == "alice"  # came from the verified token, not the body


def test_anomalous_request_is_denied(client):
    token = get_token(client, "alice")
    res = client.post("/access/decide", json={
        "token": token, "device_id": "brand-new-device", "location": "Tokyo",
        "resource": "pii-database", "api_calls_last_minute": 500, "hour_of_day": 3,
    })
    data = res.get_json()
    assert data["outcome"] == "DENY"
    assert data["risk_score"] >= 80


def test_tampered_token_is_rejected(client):
    token = get_token(client, "alice")
    tampered = token[:-3] + "xyz"  # corrupt the signature
    res = client.post("/access/decide", json={
        "token": tampered, "device_id": "alice-laptop", "location": "Bangalore", "resource": "x",
    })
    assert res.status_code == 401


def test_skip_auth_bypass_works_for_manual_testing(client):
    res = client.post("/access/decide", json={
        "user_id": "alice", "skip_auth": True, "device_id": "alice-laptop",
        "location": "Bangalore", "resource": "x", "api_calls_last_minute": 2, "hour_of_day": 10,
    })
    assert res.status_code == 200


def test_repeated_identical_request_is_served_from_cache(client):
    token = get_token(client, "bob")
    payload = {
        "token": token, "device_id": "bob-desktop", "location": "London",
        "resource": "x", "api_calls_last_minute": 5, "hour_of_day": 11,
    }
    first = client.post("/access/decide", json=payload).get_json()
    second = client.post("/access/decide", json=payload).get_json()
    assert first["from_cache"] is False
    assert second["from_cache"] is True
    assert first["outcome"] == second["outcome"]


def test_response_includes_factor_breakdown_and_stage_timings(client):
    """Chapter 20.1's per-request chart and Chapter 20.6's subway map both
    read these fields directly from the response. The subway map names 5
    specific stations (Auth -> Risk Engine -> Neo4j -> Policy Engine ->
    Decision) — verify they're tracked as separate stages, not merged."""
    token = get_token(client, "alice")
    res = client.post("/access/decide", json={
        "token": token, "device_id": "alice-laptop", "location": "Bangalore",
        "resource": "x", "api_calls_last_minute": 2, "hour_of_day": 10,
    })
    data = res.get_json()
    assert "factors" in data and len(data["factors"]) == 9  # 8 factors + graph signal
    timings = data["stage_timings_ms"]
    assert "2_auth" in timings
    assert "4_risk_engine" in timings
    assert "5_neo4j_graph" in timings
    assert "6_policy_engine" in timings
    assert "7_decision_finalized" in timings


def test_mfa_and_token_age_affect_identity_confidence(client):
    """Chapter 8, Factor 1 needs to actually look at MFA status and token
    age, not just token validity — exercised via the /login simulate
    fields."""
    token = get_token(client, "alice")
    res = client.post("/access/decide", json={
        "token": token, "device_id": "alice-laptop", "location": "Bangalore",
        "resource": "internal-dashboard", "api_calls_last_minute": 2, "hour_of_day": 10,
        "mfa_verified": False, "simulate_token_age_minutes": 45,
    })
    data = res.get_json()
    factor = next(f for f in data["factors"] if f["name"] == "identity_confidence")
    assert factor["points"] >= 10  # both penalties should stack, capped at max_points


def test_session_anomaly_reacts_to_resource_switch(client):
    """Chapter 8, Factor 7 needs real session behavior, not just cold-start
    detection — a session that's been consistent and then suddenly asks
    for a new resource should score higher than a fully consistent one."""
    token = get_token(client, "erin")
    base_payload = {"token": token, "device_id": "erin-laptop", "location": "Paris",
                     "api_calls_last_minute": 2, "hour_of_day": 10}
    for _ in range(4):
        client.post("/access/decide", json={**base_payload, "resource": "internal-dashboard"})
    res = client.post("/access/decide", json={**base_payload, "resource": "pii-database"})
    factor = next(f for f in res.get_json()["factors"] if f["name"] == "session_anomaly")
    assert factor["points"] > 0


def test_login_page_serves(client):
    res = client.get("/login")
    assert res.status_code == 200
    assert b"Try it yourself" in res.data


def test_device_fingerprint_mismatch_flags_spoofing_end_to_end(client):
    token = get_token(client, "alice")
    res = client.post("/access/decide", json={
        "token": token, "device_id": "alice-laptop", "device_fingerprint": "fp_not_the_real_one",
        "location": "Bangalore", "resource": "x", "api_calls_last_minute": 2, "hour_of_day": 10,
    })
    factor = next(f for f in res.get_json()["factors"] if f["name"] == "device_trust")
    assert factor["points"] == 25
    assert "spoofed" in factor["reason"].lower()


def test_location_anomaly_reports_real_distance_end_to_end(client):
    token = get_token(client, "alice")
    res = client.post("/access/decide", json={
        "token": token, "device_id": "alice-laptop", "location": "Tokyo",
        "resource": "x", "api_calls_last_minute": 2, "hour_of_day": 10,
    })
    factor = next(f for f in res.get_json()["factors"] if f["name"] == "location_anomaly")
    assert "km from usual location" in factor["reason"]


def test_chaos_endpoint_opens_and_recovers_the_breaker(client):
    res = client.post("/demo/chaos/graph")
    assert res.get_json()["state"] == "open"

    token = get_token(client, "alice")
    res2 = client.post("/access/decide", json={
        "token": token, "device_id": "alice-laptop", "location": "Bangalore",
        "resource": "x", "api_calls_last_minute": 2, "hour_of_day": 10,
    })
    assert res2.status_code == 200  # still answers while the breaker is open

    res3 = client.post("/demo/recover/graph")
    assert res3.get_json()["state"] == "closed"


def test_force_password_reset_invalidates_cache(client):
    """Chapter 13's cache-invalidation-on-known-state-change, exercised
    end to end."""
    token = get_token(client, "bob")
    payload = {
        "token": token, "device_id": "bob-desktop", "location": "London",
        "resource": "x", "api_calls_last_minute": 5, "hour_of_day": 11,
    }
    client.post("/access/decide", json=payload)  # populates the cache
    reset_res = client.post("/demo/force-password-reset/bob")
    assert reset_res.get_json()["cache_entries_invalidated"] >= 1

    # Next identical request should be a fresh computation, not a cache hit.
    second = client.post("/access/decide", json=payload).get_json()
    assert second["from_cache"] is False


def test_compliance_report_returns_a_pdf(client):
    token = get_token(client, "alice")
    client.post("/access/decide", json={
        "token": token, "device_id": "alice-laptop", "location": "Bangalore",
        "resource": "x", "api_calls_last_minute": 2, "hour_of_day": 10,
    })
    res = client.get("/demo/compliance-report")
    assert res.status_code == 200
    assert res.get_data()[:4] == b"%PDF"


def test_audience_submit_runs_through_real_pipeline(client):
    res = client.post("/audience/submit", json={"display_name": "Guest1", "location": "Seattle"})
    data = res.get_json()
    assert res.status_code == 200
    assert data["outcome"] in ("ALLOW", "VERIFY", "RESTRICT", "DENY")
    assert data["user_id"] == "Guest1"


def test_cities_endpoint_matches_geo_module(client):
    """The dashboard's geo activity map reads this — verify it's the real
    table from geo.py, not a separate hand-copied list that could drift."""
    import geo
    res = client.get("/demo/cities")
    data = res.get_json()
    assert "bangalore" in data
    assert data["bangalore"]["lat"] == geo.CITY_COORDINATES["bangalore"][0]


def test_csv_export_contains_recorded_decisions(client):
    token = get_token(client, "alice")
    client.post("/access/decide", json={
        "token": token, "device_id": "alice-laptop", "location": "Bangalore",
        "resource": "csv-export-marker", "api_calls_last_minute": 2, "hour_of_day": 10,
    })
    res = client.get("/demo/export.csv")
    assert res.status_code == 200
    assert res.mimetype == "text/csv"
    assert b"csv-export-marker" in res.data


def test_identity_can_be_added_and_used_immediately(client):
    """Chapter 3.3 limitation 1 (Identity Sprawl): an identity added
    through the management endpoint should be usable by the risk engine
    on the very next request, with no restart."""
    res = client.post("/demo/identities", json={
        "user_id": "zed", "usual_location": "Berlin", "usual_devices": ["zed-laptop"],
        "usual_hours": [9, 17], "avg_calls_per_minute": 2,
    })
    assert res.status_code == 201

    token = get_token(client, "zed")
    res = client.post("/access/decide", json={
        "token": token, "device_id": "zed-laptop", "location": "Berlin",
        "resource": "x", "api_calls_last_minute": 2, "hour_of_day": 10,
    })
    data = res.get_json()
    assert data["outcome"] == "ALLOW"
    device_factor = next(f for f in data["factors"] if f["name"] == "device_trust")
    assert device_factor["points"] == 0  # recognized immediately, not cold-start


def test_identity_can_be_removed(client):
    client.post("/demo/identities", json={"user_id": "temp_user", "usual_location": "Oslo"})
    res = client.delete("/demo/identities/temp_user")
    assert res.status_code == 200
    res = client.get("/demo/identities")
    assert not any(i["user_id"] == "temp_user" for i in res.get_json())


def test_duplicate_identity_is_rejected(client):
    res = client.post("/demo/identities", json={"user_id": "alice", "usual_location": "Nowhere"})
    assert res.status_code == 409
