"""
tests/test_soc.py
--------------------
Tests for the SOC platform extension (soc/): the data store, the
brute-force/password-spray/impossible-travel detectors, MITRE reference
data, and the RBAC layer end to end through the Flask app.
"""

import sys
import os
import importlib
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest


@pytest.fixture
def client(tmp_path, monkeypatch):
    import config as config_module
    monkeypatch.setattr(config_module.Config, "DATA_DIR", str(tmp_path))
    import app as app_module
    importlib.reload(app_module)
    app_module.app.testing = True
    return app_module.app.test_client()


def soc_login(client, username="tester", role="analyst"):
    res = client.post("/soc/api/auth/login", json={"username": username, "role": role})
    return res.get_json()["token"]


def test_soc_store_alert_crud(tmp_path):
    from soc.store import SocStore
    store = SocStore(str(tmp_path / "test_soc.db"))

    alert_id = store.add_alert(severity="high", detection_rule="Test Rule", host="H1")
    alert = store.get_alert(alert_id)
    assert alert["severity"] == "high"
    assert alert["status"] == "new"

    assert store.update_alert(alert_id, status="resolved") is True
    assert store.get_alert(alert_id)["status"] == "resolved"

    assert store.add_alert_note(alert_id, "analyst1", "investigated") is True
    assert store.get_alert(alert_id)["notes"][0]["text"] == "investigated"


def test_soc_store_incident_status_workflow(tmp_path):
    from soc.store import SocStore
    store = SocStore(str(tmp_path / "test_soc2.db"))
    incident_id = store.add_incident(title="Test incident", severity="high")
    assert store.get_incident(incident_id)["status"] == "NEW"
    assert store.update_incident_status(incident_id, "TRIAGED", "analyst1") is True
    assert store.get_incident(incident_id)["status"] == "TRIAGED"
    assert store.update_incident_status(incident_id, "NOT_A_REAL_STATUS") is False


def test_soc_store_vulnerability_upsert_deduplicates(tmp_path):
    from soc.store import SocStore
    store = SocStore(str(tmp_path / "test_soc3.db"))
    store.upsert_vulnerability(host="H1", cve="CVE-2021-44228", cvss_score=10.0, severity="critical")
    store.upsert_vulnerability(host="H1", cve="CVE-2021-44228", cvss_score=10.0, severity="critical")
    result = store.query_vulnerabilities(host="H1")
    assert result["total"] == 1


def test_mitre_has_all_14_real_tactics():
    from soc import mitre_data
    assert len(mitre_data.TACTICS) == 14
    names = {t["name"] for t in mitre_data.TACTICS}
    assert "Initial Access" in names and "Impact" in names and "Reconnaissance" in names


def test_mitre_technique_lookup_and_subtechnique():
    from soc import mitre_data
    t = mitre_data.technique_by_id("T1110")
    assert t["name"] == "Brute Force"
    sub = mitre_data.technique_by_id("T1110.003")
    assert sub["name"] == "Password Spraying"
    assert sub["parent_technique_id"] == "T1110"


def test_detect_brute_force_finds_burst():
    from soc.detectors import detect_brute_force
    from datetime import datetime, timedelta, timezone
    base = datetime.now(timezone.utc)
    events = [
        {"success": False, "source_ip": "1.2.3.4", "username": "alice",
         "timestamp": (base + timedelta(seconds=i * 10)).isoformat()}
        for i in range(8)
    ]
    findings = detect_brute_force(events, threshold=5, window_minutes=10)
    assert len(findings) == 1
    assert findings[0]["source_ip"] == "1.2.3.4"


def test_detect_brute_force_ignores_sparse_failures():
    from soc.detectors import detect_brute_force
    from datetime import datetime, timezone
    events = [{"success": False, "source_ip": "1.2.3.4", "username": "alice",
               "timestamp": datetime.now(timezone.utc).isoformat()}]
    assert detect_brute_force(events, threshold=5) == []


def test_detect_impossible_travel_flags_implausible_speed():
    from soc.detectors import detect_impossible_travel
    import geo
    from datetime import datetime, timedelta, timezone
    t1 = datetime.now(timezone.utc)
    t2 = t1 + timedelta(minutes=10)
    events = [
        {"success": True, "username": "alice", "country": "Bangalore", "timestamp": t1.isoformat()},
        {"success": True, "username": "alice", "country": "Tokyo", "timestamp": t2.isoformat()},
    ]
    findings = detect_impossible_travel(events, geo.CITY_COORDINATES)
    assert len(findings) == 1
    assert findings[0]["username"] == "alice"


def test_soc_page_serves(client):
    res = client.get("/soc")
    assert res.status_code == 200


def test_soc_unauthenticated_write_is_blocked(client):
    res = client.post("/soc/api/demo/stop")
    assert res.status_code == 401


def test_soc_viewer_cannot_write(client):
    token = soc_login(client, role="viewer")
    res = client.get("/soc/api/alerts")
    items = res.get_json()["items"]
    if items:
        r = client.post(f"/soc/api/alerts/{items[0]['id']}/resolve",
                         headers={"Authorization": f"Bearer {token}"})
        assert r.status_code == 403


def test_soc_analyst_can_write_but_not_see_audit_log(client):
    token = soc_login(client, role="analyst")
    headers = {"Authorization": f"Bearer {token}"}
    res = client.get("/soc/api/audit-log", headers=headers)
    assert res.status_code == 403


def test_soc_admin_can_see_audit_log(client):
    token = soc_login(client, role="admin")
    headers = {"Authorization": f"Bearer {token}"}
    res = client.get("/soc/api/audit-log", headers=headers)
    assert res.status_code == 200


def test_soc_kpis_endpoint(client):
    res = client.get("/soc/api/kpis")
    data = res.get_json()
    assert "total_alerts" in data
    assert "value" in data["total_alerts"]


def test_soc_mitre_tactics_endpoint(client):
    res = client.get("/soc/api/mitre/tactics")
    assert len(res.get_json()) == 14


def test_soc_ip_investigate_never_fabricates_reputation(client):
    res = client.get("/soc/api/ip-investigate/8.8.8.8")
    data = res.get_json()
    assert data["reputation"]["reputation"] == "External reputation data unavailable."


def test_soc_vulnerabilities_seeded_with_real_cached_cves(client):
    res = client.get("/soc/api/vulnerabilities?cve=CVE-2021-44228")
    data = res.get_json()
    assert data["total"] > 0
    assert data["items"][0]["cvss_score"] == 10.0


def test_soc_cve_lookup_cache_hit_needs_no_network(client):
    res = client.get("/soc/api/vulnerabilities/cve/CVE-2021-44228?live=false")
    data = res.get_json()
    assert data["cvss_score"] == 10.0
    assert data["source"] in ("cached-sample", "live-nvd")
