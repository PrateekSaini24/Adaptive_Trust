"""
tests/test_risk_engine.py
----------------------------
Chapter 16.1: "Individual functions - risk-factor calculations... are
tested in isolation using pytest, independent of the network, database, or
any other external service."

These reproduce Alice's two logins from Chapter 4 / Chapter 9 as concrete,
checkable assertions instead of just a worked example in a document.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models import AccessRequest
from graph_engine import IdentityGraph
from risk_engine import RiskEngine
from seed_data import USER_BASELINES


def make_engine():
    graph = IdentityGraph()
    graph.add_node("alice", "User")
    graph.add_node("alice-laptop", "Device")
    graph.add_relationship("alice", "LOGGED_IN_FROM", "alice-laptop")
    return RiskEngine(graph, USER_BASELINES)


def test_normal_request_scores_low():
    """Chapter 4: Alice, Monday 10am, Bangalore, known device, ~2 calls/min
    should score low and land in ALLOW territory (< 30)."""
    engine = make_engine()
    req = AccessRequest(
        user_id="alice", device_id="alice-laptop", location="Bangalore",
        resource="internal-dashboard", api_calls_last_minute=2, hour_of_day=10,
    )
    result = engine.score(req)
    assert result.total_score < 30


def test_anomalous_request_scores_high():
    """Chapter 4: Alice, 3am, Tokyo, unrecognized device, 500 calls/min
    should score high and land in DENY territory (>= 80)."""
    engine = make_engine()
    req = AccessRequest(
        user_id="alice", device_id="unrecognized-device", location="Tokyo",
        resource="pii-database", api_calls_last_minute=500, hour_of_day=3,
    )
    result = engine.score(req)
    assert result.total_score >= 80


def test_device_trust_factor_recognizes_known_device():
    engine = make_engine()
    req = AccessRequest(
        user_id="alice", device_id="alice-laptop", location="Bangalore",
        resource="x",
    )
    factor = engine.score_device_trust(req)
    assert factor.points == 0


def test_device_trust_factor_flags_unknown_device():
    engine = make_engine()
    req = AccessRequest(
        user_id="alice", device_id="never-seen-device", location="Bangalore",
        resource="x",
    )
    factor = engine.score_device_trust(req)
    assert factor.points == 25  # max points, Chapter 9's table


def test_unknown_user_gets_cold_start_penalty():
    """Chapter 24.1 item 2: an unknown identity should get a moderate
    penalty, not zero and not the maximum."""
    engine = make_engine()
    req = AccessRequest(
        user_id="brand-new-user", device_id="some-device", location="Nowhere",
        resource="x",
    )
    factor = engine.score_device_trust(req)
    assert 0 < factor.points < 25


def test_score_never_exceeds_100():
    engine = make_engine()
    req = AccessRequest(
        user_id="brand-new-user", device_id="never-seen", location="Nowhere",
        resource="x", api_calls_last_minute=10000, hour_of_day=3, token_valid=False,
    )
    result = engine.score(req)
    assert result.total_score <= 100


def test_network_reputation_recognizes_corporate_vpn_and_known_bad_ips():
    """This factor used to be dead code — score_network_reputation()
    accepted known_vpn_ips/known_bad_ips as arguments, but nothing at any
    call site actually passed them, so every IP fell into the generic
    'unfamiliar' bucket regardless. Fixed by wiring the sets into the
    engine's constructor instead."""
    graph = IdentityGraph()
    engine = RiskEngine(graph, {}, known_vpn_ips={"10.0.0.5"}, known_bad_ips={"198.51.100.23"})

    vpn_req = AccessRequest(user_id="x", device_id="d", location="l", resource="r", network_ip="10.0.0.5")
    bad_req = AccessRequest(user_id="x", device_id="d", location="l", resource="r", network_ip="198.51.100.23")
    unfamiliar_req = AccessRequest(user_id="x", device_id="d", location="l", resource="r", network_ip="203.0.113.9")

    assert engine.score_network_reputation(vpn_req).points == 0
    assert engine.score_network_reputation(bad_req).points == 10
    assert engine.score_network_reputation(unfamiliar_req).points == 4


def test_risk_engine_has_no_policy_mutation_capability():
    """Chapter 18: 'each internal component should only have the access it
    needs - for example, the Risk Engine reads policy data but should not
    be able to modify policy rules.' Verified structurally: risk_engine.py
    doesn't import policy_engine at all, so there's no code path from
    scoring a request to changing a policy threshold — the separation is
    enforced by the module boundary itself, not by convention."""
    import inspect
    import risk_engine as risk_engine_module
    source = inspect.getsource(risk_engine_module)
    assert "policy_engine" not in source
    assert "import policy" not in source


def test_device_fingerprint_match_scores_zero():
    """Chapter 8, Factor 2: a known device ID with a MATCHING fingerprint
    should score 0, not just "known device ID" alone."""
    engine = make_engine()
    from seed_data import USER_BASELINES
    baselines = {"alice": {**USER_BASELINES["alice"]}}
    engine = RiskEngine(engine.graph, baselines)
    req = AccessRequest(
        user_id="alice", device_id="alice-laptop",
        device_fingerprint="fp_alice_macbook_chrome_macos", location="Bangalore", resource="x",
    )
    factor = engine.score_device_trust(req)
    assert factor.points == 0


def test_device_fingerprint_mismatch_flags_spoofing():
    """A known device ID with a fingerprint that does NOT match what's on
    file should score the max — worse than an honestly-new device, since
    it's actively misleading."""
    from seed_data import USER_BASELINES
    graph = IdentityGraph()
    engine = RiskEngine(graph, {"alice": {**USER_BASELINES["alice"]}})
    req = AccessRequest(
        user_id="alice", device_id="alice-laptop",
        device_fingerprint="fp_completely_different", location="Bangalore", resource="x",
    )
    factor = engine.score_device_trust(req)
    assert factor.points == 25
    assert "spoofed" in factor.reason.lower()


def test_location_anomaly_uses_real_distance():
    """Chapter 8, Factor 3 asks 'how far' — verify it's a real computed
    distance, not just a same/different flag."""
    engine = make_engine()
    req = AccessRequest(user_id="alice", device_id="alice-laptop", location="Paris", resource="x")
    factor = engine.score_location_anomaly(req)
    assert "km from usual location" in factor.reason
    # Bangalore -> Paris is roughly 7,800 km — sanity-check it's in a
    # believable range, not some arbitrary placeholder number.
    distance_str = factor.reason.split(" km")[0]
    assert 6000 < float(distance_str) < 9000


def test_location_anomaly_short_distance_scores_less_than_long_distance():
    """A nearby city should score lower than a far one — the whole point
    of using real distance instead of a binary same/different check."""
    import geo
    graph = IdentityGraph()
    baselines = {"alice": {
        "usual_location": "London", "usual_hours": (9, 17),
        "usual_devices": {"alice-laptop"}, "avg_calls_per_minute": 2, "leaked_credential": False,
    }}
    engine = RiskEngine(graph, baselines)

    near = engine.score_location_anomaly(
        AccessRequest(user_id="alice", device_id="alice-laptop", location="Paris", resource="x")
    )
    far = engine.score_location_anomaly(
        AccessRequest(user_id="alice", device_id="alice-laptop", location="Tokyo", resource="x")
    )
    assert near.points < far.points
