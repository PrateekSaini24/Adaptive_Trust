"""
tests/test_policy_engine.py
------------------------------
Chapter 10.2's threshold table, checked directly: ALLOW < 30, VERIFY 30-59,
RESTRICT 60-79, DENY 80+.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import Config
from policy_engine import evaluate


def test_low_score_allows():
    assert evaluate(0, Config()) == "ALLOW"
    assert evaluate(29, Config()) == "ALLOW"


def test_moderate_score_verifies():
    assert evaluate(30, Config()) == "VERIFY"
    assert evaluate(59, Config()) == "VERIFY"


def test_elevated_score_restricts():
    assert evaluate(60, Config()) == "RESTRICT"
    assert evaluate(79, Config()) == "RESTRICT"


def test_high_score_denies():
    assert evaluate(80, Config()) == "DENY"
    assert evaluate(100, Config()) == "DENY"
