"""
metrics.py
------------
Chapter 12: "Prometheus / Grafana - Monitoring and dashboards - The de
facto open-source standard for metrics collection and visualization."

Chapter 20.1 asks the dashboard for "a live system-metrics panel (latency,
cache hit rate, requests/second) driven by real measurements, not
placeholder numbers" — this module is where those real measurements are
recorded.

A real deployment would use the `prometheus_client` library. This module
hand-writes the same idea (counters + a latency histogram) in pure Python
and exposes them in the real Prometheus text exposition format at /metrics,
so a real Prometheus server could scrape this endpoint unmodified if you
pointed one at it — the wire format is the actual standard, only the
in-process bookkeeping is simplified.
"""

import threading
import time
from collections import deque


class Metrics:
    def __init__(self, latency_window: int = 200):
        self._lock = threading.Lock()

        self.requests_total = 0
        self.outcome_counts = {"ALLOW": 0, "VERIFY": 0, "RESTRICT": 0, "DENY": 0}
        self.cache_hits = 0
        self.cache_misses = 0

        # Rolling window of the last N request latencies, in milliseconds —
        # enough to compute a live P50/P99 without keeping unbounded history.
        self._latencies_ms = deque(maxlen=latency_window)

        # Timestamps of recent requests, used to compute a real
        # requests-per-second figure over a short trailing window.
        self._recent_request_times = deque(maxlen=1000)

    def record_request(self, latency_ms: float, outcome: str) -> None:
        with self._lock:
            self.requests_total += 1
            self.outcome_counts[outcome] = self.outcome_counts.get(outcome, 0) + 1
            self._latencies_ms.append(latency_ms)
            self._recent_request_times.append(time.time())

    def record_cache_hit(self) -> None:
        with self._lock:
            self.cache_hits += 1

    def record_cache_miss(self) -> None:
        with self._lock:
            self.cache_misses += 1

    def _percentile(self, values, pct: float) -> float:
        if not values:
            return 0.0
        ordered = sorted(values)
        idx = min(int(len(ordered) * pct), len(ordered) - 1)
        return ordered[idx]

    def snapshot(self) -> dict:
        """Powers the dashboard's metrics panel (Chapter 20.1) and /demo/stats."""
        with self._lock:
            now = time.time()
            recent = [t for t in self._recent_request_times if now - t <= 5.0]
            requests_per_second = round(len(recent) / 5.0, 2)

            cache_total = self.cache_hits + self.cache_misses
            hit_rate = round(self.cache_hits / cache_total, 3) if cache_total else 0.0

            latencies = list(self._latencies_ms)
            return {
                "requests_total": self.requests_total,
                "outcome_counts": dict(self.outcome_counts),
                "requests_per_second": requests_per_second,
                "cache_hit_rate": hit_rate,
                "cache_hits": self.cache_hits,
                "cache_misses": self.cache_misses,
                "latency_ms_p50": round(self._percentile(latencies, 0.50), 2),
                "latency_ms_p99": round(self._percentile(latencies, 0.99), 2),
                "latency_ms_avg": round(sum(latencies) / len(latencies), 2) if latencies else 0.0,
            }

    def as_prometheus_text(self) -> str:
        """
        Real Prometheus text exposition format — this is what a real
        Prometheus server scrapes over HTTP. See
        https://prometheus.io/docs/instrumenting/exposition_formats/
        """
        snap = self.snapshot()
        lines = [
            "# HELP adaptivetrust_requests_total Total access decisions made",
            "# TYPE adaptivetrust_requests_total counter",
            f"adaptivetrust_requests_total {snap['requests_total']}",
            "",
            "# HELP adaptivetrust_requests_by_outcome_total Decisions by outcome",
            "# TYPE adaptivetrust_requests_by_outcome_total counter",
        ]
        for outcome, count in snap["outcome_counts"].items():
            lines.append(f'adaptivetrust_requests_by_outcome_total{{outcome="{outcome}"}} {count}')
        lines += [
            "",
            "# HELP adaptivetrust_cache_hit_rate Fraction of decisions served from cache",
            "# TYPE adaptivetrust_cache_hit_rate gauge",
            f"adaptivetrust_cache_hit_rate {snap['cache_hit_rate']}",
            "",
            "# HELP adaptivetrust_requests_per_second Trailing 5s request rate",
            "# TYPE adaptivetrust_requests_per_second gauge",
            f"adaptivetrust_requests_per_second {snap['requests_per_second']}",
            "",
            "# HELP adaptivetrust_latency_ms Request latency in milliseconds",
            "# TYPE adaptivetrust_latency_ms summary",
            f'adaptivetrust_latency_ms{{quantile="0.5"}} {snap["latency_ms_p50"]}',
            f'adaptivetrust_latency_ms{{quantile="0.99"}} {snap["latency_ms_p99"]}',
        ]
        return "\n".join(lines) + "\n"
