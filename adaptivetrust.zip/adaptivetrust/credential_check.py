"""
credential_check.py
----------------------
Chapter 8, Factor 8: "Whether the credentials involved appear in known
leaked-credential datasets." An earlier draft of this only read a
hard-coded True/False flag from a fake baseline — this does the real
check, against a real "known leaked-credential dataset": Have I Been
Pwned's Pwned Passwords API.

This uses the k-anonymity model HIBP is specifically designed around, so
no real password (or even a full hash of one) is ever sent over the
network:

  1. The password is hashed with SHA-1 — ideally on the CLIENT (see
     dashboard/login.html, which does this with the browser's own
     crypto.subtle so the plaintext password never leaves the browser).
  2. Only the first 5 hex characters of that hash (the "prefix") are sent
     to HIBP's /range/{prefix} endpoint.
  3. HIBP returns every hash SUFFIX in its database that starts with that
     prefix, each with a breach count — typically several hundred to a
     few thousand lines.
  4. We check locally whether our own hash's suffix is anywhere in that
     list. If it is, the password has appeared in a known breach.

This is the exact integration pattern HIBP's own documentation recommends
and that real products (Firefox Monitor, 1Password, etc.) use.
"""

import hashlib
import os
import urllib.request
import urllib.error


HIBP_RANGE_URL = "https://api.pwnedpasswords.com/range/{prefix}"


class CredentialCheckUnavailable(Exception):
    """Raised when the real HIBP API can't be reached — callers should
    treat this as 'unknown', not 'safe'."""
    pass


def sha1_hash(password: str) -> str:
    """Only used server-side as a fallback if the caller sent a plaintext
    password instead of a pre-hashed one (e.g. the skip_auth testing path).
    The real /login screen hashes client-side and never sends this."""
    return hashlib.sha1(password.encode("utf-8")).hexdigest().upper()


def check_pwned_by_hash(sha1_hash_hex: str, timeout: float = 3.0) -> tuple:
    """
    Real HIBP k-anonymity lookup. Takes a full SHA-1 hash (as the client
    computed it), sends only the 5-character prefix over the network, and
    checks the suffix locally.

    Returns (is_pwned: bool, breach_count: int).
    Raises CredentialCheckUnavailable if the API can't be reached — this
    is deliberately a different outcome from "checked, and it's clean",
    so a network hiccup can't silently look like a safe password.
    """
    sha1_hash_hex = sha1_hash_hex.upper()
    prefix, suffix = sha1_hash_hex[:5], sha1_hash_hex[5:]

    url = HIBP_RANGE_URL.format(prefix=prefix)
    request = urllib.request.Request(url, headers={"User-Agent": "AdaptiveTrust-Demo"})

    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = response.read().decode("utf-8")
    except (urllib.error.URLError, TimeoutError) as exc:
        raise CredentialCheckUnavailable(f"HIBP API unreachable: {exc}")

    for line in body.splitlines():
        line_suffix, _, count_str = line.partition(":")
        if line_suffix.strip() == suffix:
            return True, int(count_str.strip())

    return False, 0


def check_pwned_by_password(password: str, timeout: float = 3.0) -> tuple:
    """Convenience wrapper for the fallback (non-client-hashed) path."""
    return check_pwned_by_hash(sha1_hash(password), timeout=timeout)
