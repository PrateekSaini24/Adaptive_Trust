"""
session_tracker.py
---------------------
Chapter 8, Factor 7 (Session Anomaly): "Signals within the current session
itself - for example, a sudden change in behavior partway through an
otherwise-normal session."

Earlier drafts of this build scored this factor purely from "is this a
brand-new identity" (cold start), which isn't actually looking at session
behavior at all. This module gives it something real to look at: it
remembers which resources each session has touched recently, and flags it
when a session that's been requesting one kind of thing suddenly asks for
something it's never touched before — e.g. a session that's spent the last
five requests on `internal-dashboard` suddenly requesting `pii-database`.

Kept in-memory here (like the in-memory fallbacks elsewhere in this
project) — in a real deployment this would live in the same cache layer
(Redis, short TTL) that already holds risk scores, since session history
is exactly the kind of short-lived state that fits there.
"""

import threading
from collections import deque, Counter


class SessionTracker:
    def __init__(self, history_length: int = 8):
        self._lock = threading.Lock()
        self._history_length = history_length
        # {session_id: deque([resource, resource, ...], maxlen=history_length)}
        self._sessions = {}

    def anomaly_score(self, session_id: str, resource: str, max_points: int) -> tuple:
        """
        Call this BEFORE recording the current request (record() below),
        so "the session's history" means everything before this request.

        Returns (points, reason).
        """
        with self._lock:
            history = self._sessions.get(session_id)

            if history is None or len(history) == 0:
                # Brand-new session — matches the original "no session
                # history yet" caution, just phrased around session state
                # instead of identity state.
                return min(5, max_points), "no session history yet — first request this session"

            if resource in history:
                # Consistent with what this session has been doing.
                return 0, "consistent with this session's recent activity"

            # The session has history, but never for THIS resource before.
            # How much of a departure this is scales with how established
            # the session's existing pattern is — a session with 6
            # consistent requests suddenly asking for something new is a
            # bigger signal than a session with only 1 prior request.
            established = len(history) >= 3
            if established:
                most_common_resource, count = Counter(history).most_common(1)[0]
                points = min(8, max_points)
                return points, (
                    f"sudden change mid-session — this session has mostly been "
                    f"accessing '{most_common_resource}' ({count}/{len(history)} recent "
                    f"requests), now requesting '{resource}' for the first time"
                )
            points = min(3, max_points)
            return points, f"new resource ('{resource}') for a still-forming session"

    def record(self, session_id: str, resource: str) -> None:
        """Adds this request to the session's history, AFTER scoring it."""
        with self._lock:
            if session_id not in self._sessions:
                self._sessions[session_id] = deque(maxlen=self._history_length)
            self._sessions[session_id].append(resource)

    def clear_session(self, session_id: str) -> None:
        with self._lock:
            self._sessions.pop(session_id, None)

    def session_count(self) -> int:
        with self._lock:
            return len(self._sessions)
